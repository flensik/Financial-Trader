import React, { useState, useEffect, useRef } from 'react';
import { Player, MiningFarm, SupportTicket } from '../types';
import { GameService, hashString, GAME_ASSETS } from '../services/gameDb';
import { formatCurrency } from './Formatters';
import { ShieldAlert, Search, User, Trash2, Save, Ban, Briefcase, Server, FileText, Download, Key, Network, MessageSquare, Send, CheckSquare, XSquare, Music, Radio, Edit, Image, PlusCircle, Link, X, Eye, EyeOff, ShoppingBag, Check } from 'lucide-react';
import { TRACK_URLS } from '../App';
import { getAvatarSrc } from '../utils/avatars';

interface Props {
  currentPlayer: Player;
  onRefresh: () => void;
}

const AdminPanel: React.FC<Props> = ({ currentPlayer, onRefresh }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'businesses' | 'mining' | 'assets' | 'logs' | 'security' | 'ban' | 'music'>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [foundPlayer, setFoundPlayer] = useState<Player | null>(null);
  
  // Local Edit States
  const [editBalance, setEditBalance] = useState('');
  const [newPlayerId, setNewPlayerId] = useState('');
  const [newAvatarUrl, setNewAvatarUrl] = useState('');
  
  // Ban State
  const [banDuration, setBanDuration] = useState('');
  const [banReason, setBanReason] = useState('');
  const [isPermaBan, setIsPermaBan] = useState(false);

  // Security State
  const [newPassword, setNewPassword] = useState('');

  // Promo State
  const [promoCode, setPromoCode] = useState('');
  const [promoReward, setPromoReward] = useState('');
  const [promoMax, setPromoMax] = useState('');
  const [promoDate, setPromoDate] = useState('');

  // Support State
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [adminChatMsg, setAdminChatMsg] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [showSupport, setShowSupport] = useState(false);

  // Music State
  const [globalConfig, setGlobalConfig] = useState(GameService.loadDatabase().config);
  const [newTrackName, setNewTrackName] = useState('');
  const [newTrackUrl, setNewTrackUrl] = useState('');

  // Polling for global config updates (to sync with other tabs/admin actions)
  useEffect(() => {
      const interval = setInterval(() => {
          const dbConfig = GameService.loadDatabase().config;
          // Simple check to avoid re-renders if nothing changed, 
          // but for Admin panel reliability we can just update
          if (JSON.stringify(dbConfig) !== JSON.stringify(globalConfig)) {
              setGlobalConfig(dbConfig);
          }
      }, 2000);
      return () => clearInterval(interval);
  }, [globalConfig]);

  // Sync edit fields when player is found or updated
  useEffect(() => {
      if (foundPlayer) {
          setEditBalance(foundPlayer.balance.toString());
          setNewPlayerId(foundPlayer.id);
          setNewAvatarUrl('');
      }
  }, [foundPlayer]);

  // Support Ticket Polling and Loading
  useEffect(() => {
      if (showSupport) {
          loadTickets();
          const interval = setInterval(loadTickets, 3000);
          return () => clearInterval(interval);
      }
  }, [showSupport]);

  useEffect(() => {
      if (selectedTicket) {
          chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }
  }, [selectedTicket?.messages]);

  const loadTickets = () => {
      const allTickets = GameService.getTickets(); // Gets all
      setTickets(allTickets);
      // Update selected ticket data in real time
      if (selectedTicket) {
          const updated = allTickets.find(t => t.id === selectedTicket.id);
          if (updated) setSelectedTicket(updated);
          else setSelectedTicket(null); // Deselect if deleted
      }
  };

  const handleAdminSendMessage = () => {
      if (!selectedTicket || !adminChatMsg.trim()) return;
      GameService.addMessageToTicket(selectedTicket.id, 'admin', adminChatMsg.trim());
      // Auto update status to investigating if pending
      if (selectedTicket.status === 'pending') {
          GameService.updateTicketStatus(selectedTicket.id, 'investigating');
      }
      setAdminChatMsg('');
      loadTickets();
  };

  const handleChangeTicketStatus = (status: 'resolved' | 'closed' | 'investigating') => {
      if (!selectedTicket) return;
      GameService.updateTicketStatus(selectedTicket.id, status);
      loadTickets();
  };

  const handleDeleteTicket = () => {
      if (!selectedTicket) return;
      if (confirm('Вы уверены, что хотите удалить этот тикет?')) {
          GameService.deleteTicket(selectedTicket.id);
          setSelectedTicket(null);
          loadTickets();
      }
  };


  const handleSearch = () => {
      const p = GameService.findPlayerByUsername(searchQuery);
      if (p) {
          setFoundPlayer(p);
      } else {
          setFoundPlayer(null);
          alert('Игрок не найден');
      }
  };

  const forceRefresh = (updatedPlayer: Player) => {
      setFoundPlayer(updatedPlayer);
      // If the admin is editing themselves, we must force the App to reload the state
      if (currentPlayer.id === updatedPlayer.id) {
          onRefresh();
      }
  };

  const handleSaveBalance = () => {
      if (!foundPlayer) return;
      const val = parseFloat(editBalance);
      if (!isNaN(val)) {
          // Allow negative values (no check for < 0)
          
          GameService.updatePlayerBalance(foundPlayer.id, val);
          
          // Re-fetch to ensure sync
          const updated = GameService.getPlayer(foundPlayer.id);
          if (updated) {
              forceRefresh(updated);
              alert('Баланс успешно изменен!');
          }
      } else {
          alert('Некорректное число');
      }
  };

  const handleUpdateId = () => {
      if (!foundPlayer) return;
      if (newPlayerId === foundPlayer.id) return;
      
      const res = GameService.changePlayerId(foundPlayer.id, newPlayerId);
      if (res.success) {
          alert(res.msg);
          const updated = GameService.getPlayer(newPlayerId);
          if (updated) forceRefresh(updated);
      } else {
          alert(res.msg);
      }
  };

  const handleUpdateAvatar = () => {
      if (!foundPlayer || !newAvatarUrl.trim()) return;
      const res = GameService.changePlayerAvatar(foundPlayer.id, newAvatarUrl.trim());
      if (res.success) {
          alert(res.msg);
          const updated = GameService.getPlayer(foundPlayer.id);
          if (updated) forceRefresh(updated);
          setNewAvatarUrl('');
      } else {
          alert(res.msg);
      }
  };

  // --- BUSINESS LOGIC ---
  const handleUpdateBusiness = (busId: string, newLevel: number, newName: string) => {
      if (!foundPlayer) return;
      
      // Pull fresh data first
      const currentDbPlayer = GameService.getPlayer(foundPlayer.id) || foundPlayer;

      const updatedBusinesses = currentDbPlayer.businesses.map(b => {
          if (b.id === busId) {
              return { 
                  ...b, 
                  level: Math.max(0, newLevel), 
                  customName: newName.trim() || undefined 
              };
          }
          return b;
      });

      const updatedPlayer = { ...currentDbPlayer, businesses: updatedBusinesses };
      GameService.updatePlayer(updatedPlayer);
      forceRefresh(updatedPlayer);
      alert('Бизнес обновлен');
  };

  const handleDeleteBusiness = (busId: string) => {
      if (!foundPlayer || !window.confirm('Удалить этот бизнес у игрока?')) return;
      
      const currentDbPlayer = GameService.getPlayer(foundPlayer.id) || foundPlayer;
      
      const updatedBusinesses = currentDbPlayer.businesses.map(b => {
          if (b.id === busId) {
              return { ...b, owned: false, level: 0, customName: undefined };
          }
          return b;
      });
      const updatedPlayer = { ...currentDbPlayer, businesses: updatedBusinesses };
      
      GameService.updatePlayer(updatedPlayer);
      forceRefresh(updatedPlayer);
  };

  // --- ASSETS LOGIC ---
  const handleToggleAsset = (assetId: string) => {
      if (!foundPlayer) return;
      const currentDbPlayer = GameService.getPlayer(foundPlayer.id) || foundPlayer;
      let newAssets = [...currentDbPlayer.ownedAssetIds];
      
      if (newAssets.includes(assetId)) {
          newAssets = newAssets.filter(id => id !== assetId);
          // If active title was removed, reset active title
          if (currentDbPlayer.activeTitleId === assetId) {
              currentDbPlayer.activeTitleId = undefined;
          }
      } else {
          newAssets.push(assetId);
      }
      
      const updatedPlayer = { ...currentDbPlayer, ownedAssetIds: newAssets };
      GameService.updatePlayer(updatedPlayer);
      forceRefresh(updatedPlayer);
  };

  // --- MINING LOGIC ---
  const handleUpdateMining = (field: keyof MiningFarm, value: string) => {
      if (!foundPlayer) return;
      const numVal = parseFloat(value);
      if (isNaN(numVal)) return; // Allow 0 or negatives if needed

      const currentDbPlayer = GameService.getPlayer(foundPlayer.id) || foundPlayer;
      const updatedFarm = { ...currentDbPlayer.miningFarm, [field]: numVal };
      
      // Constraints
      if (field === 'maxSlots' && numVal > 50) updatedFarm.maxSlots = 50; 
      if (field === 'gpuCount' && numVal > updatedFarm.maxSlots) updatedFarm.gpuCount = updatedFarm.maxSlots;

      const updatedPlayer = { ...currentDbPlayer, miningFarm: updatedFarm };
      GameService.updatePlayer(updatedPlayer);
      forceRefresh(updatedPlayer);
  };

  // --- BAN LOGIC ---
  const handleBan = () => {
      if (!foundPlayer) return;
      
      const duration = isPermaBan ? null : (parseInt(banDuration) || 0);
      GameService.banUser(foundPlayer.id, duration, banReason);
      alert('Пользователь забанен');
      
      const updated = GameService.getPlayer(foundPlayer.id);
      if(updated) forceRefresh(updated);
  };

  const handleUnban = () => {
      if (!foundPlayer) return;
      GameService.unbanUser(foundPlayer.id);
      alert('Пользователь разбанен');
      const updated = GameService.getPlayer(foundPlayer.id);
      if(updated) forceRefresh(updated);
  };

  // --- IP LOGIC ---
  const handleBanIp = () => {
      if (!foundPlayer) return;
      if (foundPlayer.isAdmin) {
          alert("Нельзя забанить IP администратора");
          return;
      }
      // CRITICAL: We ban the Registration IP as that acts as the "Hardware ID"
      const ipToBan = foundPlayer.registrationIp;

      if (confirm(`Забанить REAL IP (Device): ${ipToBan}? Это заблокирует ВСЕ аккаунты, созданные с этого устройства, и предотвратит создание новых.`)) {
          GameService.banIp(ipToBan);
          alert(`IP ${ipToBan} Забанен.`);
          const updated = GameService.getPlayer(foundPlayer.id);
          if(updated) forceRefresh(updated);
      }
  };

  const handleSearchAlts = () => {
      if (!foundPlayer) return;
      // Use the new robust search
      const alts = GameService.findRelatedPlayers(foundPlayer.id);
      
      if (alts.length === 0) {
          alert("Аккаунты не найдены");
          return;
      }

      const names = alts.map(p => {
          let str = `${p.username} (Reg: ${p.registrationIp})`;
          if (p.bannedUntil) str += ' [BAN]';
          if (p.id === foundPlayer.id) str += ' (CURRENT)';
          return str;
      }).join('\n');
      
      alert(`Связанные аккаунты (по IP):\n\n${names}`);
  };

  // --- SECURITY LOGIC ---
  const handleChangePassword = () => {
      if (!foundPlayer || !newPassword.trim()) return;
      const hash = hashString(newPassword.trim());
      GameService.changePassword(foundPlayer.id, hash);
      alert('Пароль успешно изменен');
      setNewPassword('');
  };
  
  // --- LOGS ---
  const downloadLogs = () => {
      if (!foundPlayer) return;
      const content = foundPlayer.logs.join('\n');
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `logs_${foundPlayer.username}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  // --- PROMO ---
  const handleCreatePromo = () => {
      if(!promoCode || !promoReward || !promoMax) return;
      const expiresAt = promoDate ? new Date(promoDate).getTime() : null;
      GameService.createPromoCode(promoCode, parseFloat(promoReward), parseInt(promoMax), expiresAt);
      setPromoCode('');
      setPromoReward('');
      setPromoMax('');
      setPromoDate('');
      alert('Промокод создан');
      // Trigger a re-render by updating state slightly or rely on parent
      setGlobalConfig(GameService.loadDatabase().config); 
  };

  const handleDeletePromo = (id: string) => {
      if (confirm('Удалить промокод?')) {
          GameService.deletePromoCode(id);
          setGlobalConfig(GameService.loadDatabase().config); // Force UI update
      }
  };

  // --- MUSIC ---
  const handleMusicUpdate = (key: string, value: any) => {
      GameService.updateSystemConfig({ [key]: value });
      setGlobalConfig(GameService.loadDatabase().config);
  };

  const handleAddTrack = () => {
      if (!newTrackName || !newTrackUrl) return;
      const updatedConfig = GameService.addCustomTrack(newTrackName, newTrackUrl);
      setNewTrackName('');
      setNewTrackUrl('');
      setGlobalConfig(updatedConfig);
  };

  const handleDeleteTrack = (id: string, e: React.MouseEvent) => {
      e.stopPropagation(); // Prevents click from bubbling up to row click
      if (!window.confirm('Вы точно хотите удалить этот трек?')) return;
      
      const updatedConfig = GameService.deleteCustomTrack(id);
      setGlobalConfig(updatedConfig);
  };

  const handleToggleVisibility = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      const updatedConfig = GameService.toggleTrackVisibility(id);
      setGlobalConfig(updatedConfig);
  };

  const db = GameService.loadDatabase();

  // If we are in support tab, show full width view differently
  if (showSupport) {
      return (
          <div className="flex flex-col h-full bg-slate-50 p-4 text-slate-800 overflow-hidden animate-fade-in relative">
              <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-200">
                  <button onClick={() => setShowSupport(false)} className="text-sm text-blue-600 font-bold">← Назад</button>
                  <h2 className="text-xl font-bold flex items-center gap-2"><MessageSquare size={20}/> Поддержка</h2>
              </div>

              <div className="flex h-full gap-4 overflow-hidden">
                  {/* List */}
                  <div className={`w-full md:w-1/3 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden ${selectedTicket ? 'hidden md:flex' : 'flex'}`}>
                      <div className="p-3 bg-slate-100 border-b border-slate-200 font-bold text-xs text-slate-500 uppercase">
                          Обращения ({tickets.length})
                      </div>
                      <div className="flex-1 overflow-y-auto">
                          {tickets.map(t => (
                              <div 
                                key={t.id} 
                                onClick={() => setSelectedTicket(t)}
                                className={`p-3 border-b border-slate-100 cursor-pointer hover:bg-slate-50 ${selectedTicket?.id === t.id ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''}`}
                              >
                                  <div className="flex justify-between mb-1">
                                      <span className="font-bold text-sm text-slate-800">{t.playerUsername}</span>
                                      <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-bold ${
                                           t.status === 'resolved' ? 'bg-green-100 text-green-700' :
                                           t.status === 'closed' ? 'bg-slate-200 text-slate-500' :
                                           t.status === 'investigating' ? 'bg-orange-100 text-orange-700' :
                                           'bg-blue-100 text-blue-700'
                                      }`}>
                                          {t.status}
                                      </span>
                                  </div>
                                  <div className="text-xs font-bold text-slate-600 truncate">{t.title}</div>
                                  <div className="text-[10px] text-slate-400 mt-1">{new Date(t.updatedAt).toLocaleString()}</div>
                              </div>
                          ))}
                      </div>
                  </div>

                  {/* Detail */}
                  <div className={`w-full md:w-2/3 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden ${!selectedTicket ? 'hidden md:flex' : 'flex'}`}>
                      {selectedTicket ? (
                          <>
                              <div className="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center">
                                  <div>
                                      <div className="flex items-center gap-2">
                                          <button onClick={() => setSelectedTicket(null)} className="md:hidden text-slate-500 mr-2">←</button>
                                          <h3 className="font-bold text-slate-800">{selectedTicket.title}</h3>
                                      </div>
                                      <p className="text-xs text-slate-500">
                                          User: <b className="cursor-pointer hover:text-blue-600" onClick={() => { setSearchQuery(selectedTicket.playerUsername); setShowSupport(false); handleSearch(); }}>{selectedTicket.playerUsername}</b> • ID: {selectedTicket.playerId}
                                      </p>
                                  </div>
                                  <div className="flex gap-2">
                                      {selectedTicket.status !== 'closed' && (
                                          <button onClick={() => handleChangeTicketStatus('resolved')} title="Решено" className="p-2 bg-green-100 text-green-600 rounded hover:bg-green-200"><CheckSquare size={16}/></button>
                                      )}
                                      <button onClick={() => handleChangeTicketStatus(selectedTicket.status === 'closed' ? 'investigating' : 'closed')} title={selectedTicket.status === 'closed' ? "Открыть" : "Закрыть"} className="p-2 bg-slate-200 text-slate-600 rounded hover:bg-slate-300">
                                          {selectedTicket.status === 'closed' ? 'Открыть' : <XSquare size={16}/>}
                                      </button>
                                      <button onClick={handleDeleteTicket} title="Удалить навсегда" className="p-2 bg-red-100 text-red-600 rounded hover:bg-red-200">
                                          <Trash2 size={16}/>
                                      </button>
                                  </div>
                              </div>
                              
                              <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-4">
                                  <div className="bg-yellow-50 border border-yellow-100 p-3 rounded-lg text-sm text-slate-800">
                                      <b className="block text-xs text-yellow-600 uppercase mb-1">Описание проблемы:</b>
                                      {selectedTicket.description}
                                  </div>

                                  {selectedTicket.messages.map(m => (
                                      <div key={m.id} className={`flex flex-col ${m.sender === 'admin' ? 'items-end' : 'items-start'}`}>
                                          <div className={`max-w-[80%] p-3 rounded-xl text-sm ${
                                              m.sender === 'admin' 
                                              ? 'bg-slate-800 text-white rounded-br-none' 
                                              : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none shadow-sm'
                                          }`}>
                                              {m.text}
                                          </div>
                                          <span className="text-[10px] text-slate-400 mt-1">
                                              {m.sender === 'admin' ? 'Admin' : selectedTicket.playerUsername} • {new Date(m.timestamp).toLocaleTimeString()}
                                          </span>
                                      </div>
                                  ))}
                                  <div ref={chatEndRef} />
                              </div>

                              {selectedTicket.status !== 'closed' && (
                                  <div className="p-3 border-t border-slate-200 bg-white flex gap-2">
                                      <input 
                                          className="flex-1 bg-slate-100 border-none rounded-lg px-4 py-2 text-sm outline-none"
                                          placeholder="Ответ администратора..."
                                          value={adminChatMsg}
                                          onChange={e => setAdminChatMsg(e.target.value)}
                                          onKeyDown={e => e.key === 'Enter' && handleAdminSendMessage()}
                                      />
                                      <button onClick={handleAdminSendMessage} className="bg-slate-800 text-white p-2 rounded-lg hover:bg-slate-700"><Send size={18}/></button>
                                  </div>
                              )}
                          </>
                      ) : (
                          <div className="flex items-center justify-center h-full text-slate-400 text-sm">Выберите тикет для просмотра</div>
                      )}
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 p-4 text-slate-800 overflow-hidden animate-fade-in">
      <div className="flex items-center gap-2 mb-6 text-red-600 border-b border-red-200 pb-4">
        <ShieldAlert size={32}/>
        <h2 className="text-2xl font-bold">Admin Control</h2>
      </div>

      <div className="flex-1 overflow-y-auto pb-20">
      {/* --- SEARCH SECTION --- */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6">
          <label className="text-xs font-bold text-slate-400 uppercase mb-2 block">Поиск Игрока</label>
          <div className="flex gap-2">
              <input 
                type="text" 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Введите логин..."
                className="flex-1 bg-white border border-slate-300 rounded-lg p-3 text-sm outline-none text-slate-900 focus:border-blue-500"
              />
              <button onClick={handleSearch} className="bg-slate-800 text-white px-4 rounded-lg hover:bg-slate-700"><Search size={20}/></button>
          </div>
      </div>
      
      {/* Global Tabs */}
      <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
          <button onClick={() => setShowSupport(true)} className="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg font-bold text-sm whitespace-nowrap flex items-center gap-2 shadow-sm border border-purple-200">
              <MessageSquare size={16}/> Поддержка
          </button>
      </div>

      {foundPlayer ? (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-8">
              <div className="bg-slate-100 p-4 border-b border-slate-200 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-slate-300 rounded-full overflow-hidden border border-slate-200" onContextMenu={(e) => e.preventDefault()}>
                          <img src={getAvatarSrc(foundPlayer.avatarId)} alt="" className="w-full h-full object-cover pointer-events-none select-none" />
                      </div>
                      <div>
                          <h3 className="font-bold text-slate-800">{foundPlayer.username}</h3>
                          <p className="text-xs text-slate-500">
                             ID: {foundPlayer.id}
                          </p>
                      </div>
                  </div>
                  {foundPlayer.bannedUntil && (
                      <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">BANNED</span>
                  )}
              </div>

              {/* TABS */}
              <div className="flex border-b border-slate-200 overflow-x-auto no-scrollbar">
                  <button onClick={() => setActiveTab('overview')} className={`flex-1 py-3 px-4 text-sm font-bold whitespace-nowrap ${activeTab === 'overview' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}>Обзор</button>
                  <button onClick={() => setActiveTab('businesses')} className={`flex-1 py-3 px-4 text-sm font-bold whitespace-nowrap ${activeTab === 'businesses' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}>Бизнесы</button>
                  <button onClick={() => setActiveTab('mining')} className={`flex-1 py-3 px-4 text-sm font-bold whitespace-nowrap ${activeTab === 'mining' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}>Майнинг</button>
                  <button onClick={() => setActiveTab('assets')} className={`flex-1 py-3 px-4 text-sm font-bold whitespace-nowrap ${activeTab === 'assets' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}>Активы</button>
                  <button onClick={() => setActiveTab('security')} className={`flex-1 py-3 px-4 text-sm font-bold whitespace-nowrap ${activeTab === 'security' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}>Безоп.</button>
                  <button onClick={() => setActiveTab('logs')} className={`flex-1 py-3 px-4 text-sm font-bold whitespace-nowrap ${activeTab === 'logs' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-400'}`}>Логи</button>
                  <button onClick={() => setActiveTab('ban')} className={`flex-1 py-3 px-4 text-sm font-bold whitespace-nowrap ${activeTab === 'ban' ? 'text-red-600 border-b-2 border-red-600' : 'text-slate-400'}`}>Бан</button>
              </div>

              <div className="p-4">
                  {/* OVERVIEW TAB */}
                  {activeTab === 'overview' && (
                      <div className="space-y-4">
                          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                              <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Баланс ($)</label>
                              <div className="flex gap-2">
                                  <input 
                                    type="number" 
                                    value={editBalance} 
                                    onChange={e => setEditBalance(e.target.value)}
                                    className="flex-1 bg-white border border-slate-300 rounded p-2 text-sm text-slate-900 font-bold"
                                  />
                                  <button onClick={handleSaveBalance} className="bg-green-600 hover:bg-green-700 text-white px-3 rounded shadow-sm"><Save size={16}/></button>
                              </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                                  <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Клик Уровень</label>
                                  <div className="font-bold text-slate-800 text-lg">{foundPlayer.clickLevel}</div>
                              </div>
                              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                                  <label className="text-xs font-bold text-slate-500 uppercase block mb-1">Статус</label>
                                  <div className="font-bold text-slate-800 text-lg">{foundPlayer.isAdmin ? 'Админ' : 'Игрок'}</div>
                              </div>
                          </div>

                          {/* Identity Management */}
                          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                              <h4 className="text-xs font-bold text-slate-500 uppercase mb-2 flex items-center gap-1"><Edit size={12}/> Управление Профилем</h4>
                              <div className="space-y-2">
                                  <div className="flex gap-2 items-center">
                                      <span className="text-xs w-16 text-slate-500">Change ID:</span>
                                      <input 
                                        type="text" 
                                        value={newPlayerId} 
                                        onChange={e => setNewPlayerId(e.target.value)}
                                        className="flex-1 bg-white border border-slate-300 rounded p-1 text-sm"
                                      />
                                      <button onClick={handleUpdateId} className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-bold">OK</button>
                                  </div>
                                  <div className="flex gap-2 items-center">
                                      <span className="text-xs w-16 text-slate-500">Avatar URL:</span>
                                      <input 
                                        type="text" 
                                        value={newAvatarUrl} 
                                        onChange={e => setNewAvatarUrl(e.target.value)}
                                        placeholder="https://..."
                                        className="flex-1 bg-white border border-slate-300 rounded p-1 text-sm"
                                      />
                                      <button onClick={handleUpdateAvatar} className="bg-purple-600 text-white px-2 py-1 rounded text-xs font-bold"><Image size={14}/></button>
                                  </div>
                              </div>
                          </div>
                      </div>
                  )}

                  {/* BUSINESSES TAB */}
                  {activeTab === 'businesses' && (
                      <div className="space-y-3">
                          {foundPlayer.businesses.filter(b => b.owned).length === 0 && (
                             <div className="text-center text-slate-400 py-4">Нет активных бизнесов</div>
                          )}
                          {foundPlayer.businesses.filter(b => b.owned).map(b => (
                              <div key={b.id} className="bg-slate-50 p-3 rounded-xl border border-slate-200 shadow-sm">
                                  <div className="flex justify-between items-start mb-2">
                                      <div className="flex items-center gap-2">
                                          <Briefcase size={16} className="text-slate-400"/>
                                          <span className="font-bold text-sm text-slate-700">{b.name}</span>
                                      </div>
                                      <button onClick={() => handleDeleteBusiness(b.id)} className="text-red-500 hover:bg-red-100 p-1 rounded transition-colors" title="Удалить">
                                          <Trash2 size={16}/>
                                      </button>
                                  </div>
                                  
                                  <div className="grid grid-cols-2 gap-2 mb-2">
                                      <div>
                                          <label className="text-[10px] font-bold text-slate-400 uppercase">Название</label>
                                          <input 
                                              type="text" 
                                              defaultValue={b.customName || b.name}
                                              id={`name-${b.id}`}
                                              className="w-full bg-white border border-slate-300 rounded p-1 text-xs text-slate-900"
                                          />
                                      </div>
                                      <div>
                                          <label className="text-[10px] font-bold text-slate-400 uppercase">Уровень</label>
                                          <input 
                                              type="number" 
                                              defaultValue={b.level}
                                              id={`lvl-${b.id}`}
                                              className="w-full bg-white border border-slate-300 rounded p-1 text-xs text-slate-900"
                                          />
                                      </div>
                                  </div>
                                  <button 
                                      onClick={() => {
                                          const nameInput = document.getElementById(`name-${b.id}`) as HTMLInputElement;
                                          const lvlInput = document.getElementById(`lvl-${b.id}`) as HTMLInputElement;
                                          handleUpdateBusiness(b.id, parseInt(lvlInput.value), nameInput.value);
                                      }}
                                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-1.5 rounded text-xs font-bold"
                                  >
                                      Сохранить изменения
                                  </button>
                              </div>
                          ))}
                      </div>
                  )}

                  {/* ASSETS TAB */}
                  {activeTab === 'assets' && (
                      <div className="space-y-3">
                          <div className="flex items-center justify-between mb-2">
                              <span className="text-xs font-bold text-slate-500 uppercase">Управление Магазином</span>
                              <span className="text-xs font-bold text-slate-400">Найдено: {GAME_ASSETS.length}</span>
                          </div>
                          
                          <div className="grid grid-cols-1 gap-2 max-h-[400px] overflow-y-auto">
                              {GAME_ASSETS.map(asset => {
                                  const isOwned = foundPlayer.ownedAssetIds.includes(asset.id);
                                  return (
                                      <div key={asset.id} className={`flex justify-between items-center p-2 rounded-lg border ${isOwned ? 'bg-green-50 border-green-200' : 'bg-white border-slate-200'}`}>
                                          <div className="flex items-center gap-3">
                                              <div className="w-10 h-10 rounded bg-slate-200 overflow-hidden">
                                                  <img src={asset.image} className="w-full h-full object-cover" />
                                              </div>
                                              <div>
                                                  <div className="text-xs font-bold text-slate-800">{asset.name}</div>
                                                  <div className="text-[10px] text-slate-500 uppercase">{asset.category}</div>
                                              </div>
                                          </div>
                                          <button 
                                              onClick={() => handleToggleAsset(asset.id)}
                                              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-colors ${isOwned ? 'bg-red-100 text-red-600 hover:bg-red-200' : 'bg-green-100 text-green-600 hover:bg-green-200'}`}
                                          >
                                              {isOwned ? 'Удалить' : 'Добавить'}
                                          </button>
                                      </div>
                                  );
                              })}
                          </div>
                      </div>
                  )}

                  {/* MINING TAB */}
                  {activeTab === 'mining' && (
                      <div className="space-y-3">
                          <div className="flex items-center gap-2 text-slate-500 mb-2">
                              <Server size={18}/>
                              <span className="font-bold text-sm">Управление Фермой</span>
                          </div>

                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-3">
                               <div className="grid grid-cols-2 gap-3">
                                   <div>
                                       <label className="text-[10px] font-bold text-slate-400 uppercase">BTC Balance</label>
                                       <input 
                                          type="number" 
                                          value={foundPlayer.miningFarm.btcBalance} 
                                          onChange={e => handleUpdateMining('btcBalance', e.target.value)}
                                          className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900 font-bold"
                                       />
                                   </div>
                                   <div>
                                       <label className="text-[10px] font-bold text-slate-400 uppercase">Долг за свет ($)</label>
                                       <input 
                                          type="number" 
                                          value={foundPlayer.miningFarm.energyDebt} 
                                          onChange={e => handleUpdateMining('energyDebt', e.target.value)}
                                          className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900 font-bold text-red-600"
                                       />
                                   </div>
                                   <div>
                                       <label className="text-[10px] font-bold text-slate-400 uppercase">Кол-во Карт</label>
                                       <input 
                                          type="number" 
                                          value={foundPlayer.miningFarm.gpuCount} 
                                          onChange={e => handleUpdateMining('gpuCount', e.target.value)}
                                          className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900"
                                       />
                                   </div>
                                   <div>
                                       <label className="text-[10px] font-bold text-slate-400 uppercase">Уровень Карт</label>
                                       <input 
                                          type="number" 
                                          value={foundPlayer.miningFarm.gpuLevel} 
                                          onChange={e => handleUpdateMining('gpuLevel', e.target.value)}
                                          className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900"
                                       />
                                   </div>
                               </div>
                               <div>
                                   <label className="text-[10px] font-bold text-slate-400 uppercase">Макс. Слотов</label>
                                   <input 
                                      type="number" 
                                      value={foundPlayer.miningFarm.maxSlots} 
                                      onChange={e => handleUpdateMining('maxSlots', e.target.value)}
                                      className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900"
                                   />
                               </div>
                               <div className="text-[10px] text-slate-400 text-center">Изменения применяются автоматически</div>
                          </div>
                      </div>
                  )}

                  {/* LOGS TAB */}
                  {activeTab === 'logs' && (
                      <div className="space-y-4">
                          <button onClick={downloadLogs} className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-bold w-full justify-center">
                              <Download size={16}/> Скачать Логи (.txt)
                          </button>
                          <div className="bg-slate-900 text-green-400 font-mono text-[10px] p-3 rounded-lg h-60 overflow-y-auto border border-slate-700">
                              {foundPlayer.logs.slice().reverse().map((log, i) => (
                                  <div key={i} className="mb-1 border-b border-white/10 pb-1">{log}</div>
                              ))}
                              {foundPlayer.logs.length === 0 && <div className="text-slate-500 italic">Логов нет</div>}
                          </div>
                      </div>
                  )}

                  {/* SECURITY TAB */}
                   {activeTab === 'security' && (
                      <div className="space-y-4">
                           <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                               <h4 className="font-bold text-sm mb-2 flex items-center gap-2"><Key size={16} /> Сменить пароль</h4>
                               <div className="flex gap-2">
                                   <input 
                                     type="text"
                                     value={newPassword}
                                     onChange={e => setNewPassword(e.target.value)}
                                     placeholder="Новый пароль" 
                                     className="flex-1 bg-white border border-slate-300 p-2 rounded text-sm text-slate-900"
                                   />
                                   <button onClick={handleChangePassword} className="bg-red-600 text-white px-3 rounded text-sm font-bold">OK</button>
                               </div>
                           </div>

                           <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                               <h4 className="font-bold text-sm mb-2 flex items-center gap-2"><Network size={16} /> Управление IP</h4>
                               <div className="grid grid-cols-1 gap-2 text-xs mb-3">
                                   <div className="flex justify-between border-b pb-1">
                                       <span className="text-slate-500">Reg IP (Device):</span>
                                       <span className="font-mono font-bold text-slate-800">{foundPlayer.registrationIp}</span>
                                   </div>
                                   <div className="flex justify-between border-b pb-1">
                                       <span className="text-slate-500">Last Login:</span>
                                       <span className="font-mono font-bold text-slate-800">{foundPlayer.lastLoginIp}</span>
                                   </div>
                               </div>
                               
                               <div className="flex flex-col gap-2">
                                   <button onClick={handleSearchAlts} className="bg-blue-600 text-white py-2 rounded text-xs font-bold w-full shadow-sm">
                                       Найти другие аккаунты (Multi-acc check)
                                   </button>
                                   <button onClick={handleBanIp} className="bg-slate-800 text-white py-2 rounded text-xs font-bold w-full border border-slate-700 hover:bg-slate-900 shadow-sm">
                                       ЗАБАНИТЬ REAL IP (Device Ban)
                                   </button>
                               </div>
                           </div>
                      </div>
                   )}

                  {/* BAN TAB */}
                  {activeTab === 'ban' && (
                      <div className="space-y-4">
                          {foundPlayer.bannedUntil ? (
                               <div className="bg-red-50 border border-red-200 p-4 rounded-xl text-center">
                                   <Ban size={32} className="mx-auto text-red-500 mb-2"/>
                                   <div className="font-bold text-red-700">ПОЛЬЗОВАТЕЛЬ ЗАБАНЕН</div>
                                   <div className="text-sm text-red-600 mt-1">
                                       {foundPlayer.bannedUntil === -1 ? 'Навсегда' : `До: ${new Date(foundPlayer.bannedUntil).toLocaleString()}`}
                                   </div>
                                   {foundPlayer.banReason && <div className="text-xs text-slate-500 mt-2">Причина: {foundPlayer.banReason}</div>}
                                   <button onClick={handleUnban} className="mt-4 bg-white border border-red-300 text-red-600 px-4 py-2 rounded font-bold w-full hover:bg-red-50">Разбанить</button>
                               </div>
                          ) : (
                              <>
                                <div>
                                    <label className="text-xs font-bold text-slate-400 uppercase">Причина</label>
                                    <input type="text" value={banReason} onChange={e => setBanReason(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900" placeholder="Нарушение правил..."/>
                                </div>
                                <div>
                                    <label className="flex items-center gap-2 mb-2 cursor-pointer bg-slate-50 p-2 rounded border border-slate-200">
                                        <input type="checkbox" checked={isPermaBan} onChange={e => setIsPermaBan(e.target.checked)} />
                                        <span className="text-sm font-bold text-slate-700">Бан Навсегда</span>
                                    </label>
                                    {!isPermaBan && (
                                        <input type="number" value={banDuration} onChange={e => setBanDuration(e.target.value)} className="w-full bg-white border border-slate-300 rounded p-2 text-sm text-slate-900" placeholder="Время (минуты)"/>
                                    )}
                                </div>
                                <button onClick={handleBan} className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 rounded-lg shadow-sm">Выдать Бан</button>
                              </>
                          )}
                      </div>
                  )}
              </div>
          </div>
      ) : (
          <div className="text-center text-slate-400 py-10 bg-white rounded-xl border border-slate-200 border-dashed mb-6">
              Игрок не выбран
          </div>
      )}

      {/* --- GLOBAL SETTINGS (PROMO + MUSIC) --- */}
      <div className="grid md:grid-cols-2 gap-4">
          {/* PROMO */}
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <h3 className="font-bold text-slate-700 mb-4">Создать Промокод</h3>
              <div className="flex flex-col gap-2 mb-2">
                  <div className="grid grid-cols-3 gap-2">
                      <input type="text" placeholder="Код" value={promoCode} onChange={e => setPromoCode(e.target.value)} className="bg-white border border-slate-300 p-2 rounded text-sm text-slate-900" />
                      <input type="number" placeholder="$ Награда" value={promoReward} onChange={e => setPromoReward(e.target.value)} className="bg-white border border-slate-300 p-2 rounded text-sm text-slate-900" />
                      <input type="number" placeholder="Лимит" value={promoMax} onChange={e => setPromoMax(e.target.value)} className="bg-white border border-slate-300 p-2 rounded text-sm text-slate-900" />
                  </div>
                  <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Действует до (необязательно)</label>
                      <input 
                        type="datetime-local" 
                        value={promoDate} 
                        onChange={e => setPromoDate(e.target.value)} 
                        className="w-full bg-white border border-slate-300 p-2 rounded text-sm text-slate-900"
                      />
                  </div>
              </div>
              <button onClick={handleCreatePromo} className="w-full bg-slate-800 text-white py-2 rounded font-bold text-sm hover:bg-slate-700">Создать</button>
              
              <div className="mt-4 space-y-1 max-h-32 overflow-y-auto">
                  <label className="text-xs font-bold text-slate-400">АКТИВНЫЕ КОДЫ</label>
                  {db.promoCodes.map(pc => (
                      <div key={pc.id} className="flex justify-between items-center text-xs bg-slate-50 p-2 rounded border border-slate-200">
                          <div>
                              <span className="block"><b className="text-slate-800">{pc.code}</b> ({formatCurrency(pc.reward)})</span>
                              {pc.expiresAt && <span className="text-[9px] text-red-400">До: {new Date(pc.expiresAt).toLocaleString()}</span>}
                          </div>
                          <div className="flex items-center gap-2">
                              <span className="text-slate-500">{pc.usedByPlayerIds.length}/{pc.maxActivations}</span>
                              <button onClick={() => handleDeletePromo(pc.id)} className="text-red-500 hover:bg-red-100 p-1 rounded">
                                  <Trash2 size={14}/>
                              </button>
                          </div>
                      </div>
                  ))}
                  {db.promoCodes.length === 0 && <div className="text-slate-400 text-[10px] italic">Нет активных кодов</div>}
              </div>
          </div>

          {/* MUSIC CONTROL */}
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <h3 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><Radio size={20}/> Глобальное Радио</h3>
              
              {/* Enable Switch */}
              <div className="flex items-center justify-between mb-4 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-sm font-bold text-slate-600">Авто-включение для всех</span>
                  <div className="flex gap-2">
                      <button 
                          onClick={() => handleMusicUpdate('isMusicEnabled', true)}
                          className={`px-3 py-1 rounded text-xs font-bold ${globalConfig.isMusicEnabled ? 'bg-green-600 text-white' : 'bg-slate-200 text-slate-500'}`}
                      >ВКЛ</button>
                      <button 
                          onClick={() => handleMusicUpdate('isMusicEnabled', false)}
                          className={`px-3 py-1 rounded text-xs font-bold ${!globalConfig.isMusicEnabled ? 'bg-red-600 text-white' : 'bg-slate-200 text-slate-500'}`}
                      >ВЫКЛ</button>
                  </div>
              </div>

              {/* Add Track */}
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 mb-4">
                  <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Добавить Трек</h4>
                  <div className="space-y-2">
                      <input 
                          type="text" 
                          placeholder="Название трека" 
                          value={newTrackName}
                          onChange={e => setNewTrackName(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded p-2 text-sm"
                      />
                      <div className="flex gap-2">
                          <input 
                              type="text" 
                              placeholder="URL (.mp3)" 
                              value={newTrackUrl}
                              onChange={e => setNewTrackUrl(e.target.value)}
                              className="flex-1 bg-white border border-slate-300 rounded p-2 text-sm"
                          />
                          <button onClick={handleAddTrack} className="bg-blue-600 text-white px-3 rounded font-bold hover:bg-blue-700"><PlusCircle size={18}/></button>
                      </div>
                  </div>
              </div>

              {/* Track Selector */}
              <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase">Список треков</label>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                      {Object.keys(TRACK_URLS).map(key => (
                          <div key={key} className="flex justify-between items-center px-3 py-2 rounded-lg bg-slate-50 border border-slate-100 hover:bg-blue-50 cursor-pointer" onClick={() => handleMusicUpdate('activeTrack', key)}>
                              <div className="flex items-center gap-2">
                                  {globalConfig.activeTrack === key ? <Music size={14} className="text-blue-600 animate-pulse"/> : <Radio size={14} className="text-slate-400"/>}
                                  <span className={`text-xs font-bold ${globalConfig.activeTrack === key ? 'text-blue-700' : 'text-slate-600'}`}>{key} (Default)</span>
                              </div>
                          </div>
                      ))}
                      {globalConfig.customTracks?.map(track => (
                          <div key={track.id} className={`flex flex-col gap-1 px-3 py-2 rounded-lg bg-slate-50 border border-slate-100 hover:bg-blue-50 ${track.isHidden ? 'opacity-50' : ''}`}>
                              <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2 cursor-pointer flex-1 overflow-hidden" onClick={() => handleMusicUpdate('activeTrack', track.id)}>
                                    {globalConfig.activeTrack === track.id ? <Music size={14} className="text-blue-600 animate-pulse flex-shrink-0"/> : <Link size={14} className="text-slate-400 flex-shrink-0"/>}
                                    <span className={`text-xs font-bold truncate ${globalConfig.activeTrack === track.id ? 'text-blue-700' : 'text-slate-600'}`}>{track.name}</span>
                                    {track.isHidden && <span className="text-[9px] text-red-500 font-bold ml-1">(Hidden)</span>}
                                </div>
                                <div className="flex items-center gap-1">
                                    <button onClick={(e) => handleToggleVisibility(track.id, e)} className="text-slate-400 hover:text-blue-500 p-1 bg-white rounded border border-slate-200" title={track.isHidden ? "Показать" : "Скрыть"}>
                                        {track.isHidden ? <EyeOff size={12} /> : <Eye size={12} />}
                                    </button>
                                    <button onClick={(e) => handleDeleteTrack(track.id, e)} className="text-slate-400 hover:text-red-500 p-1 bg-white rounded border border-slate-200" title="Удалить">
                                        <Trash2 size={12}/>
                                    </button>
                                </div>
                              </div>
                              {/* Display URL for admin to identify link */}
                              <div className="text-[9px] text-slate-400 truncate pl-5 font-mono">
                                  {track.url}
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      </div>
      </div>
    </div>
  );
};

export default AdminPanel;