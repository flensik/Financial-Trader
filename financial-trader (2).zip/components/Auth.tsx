
import React, { useState } from 'react';
import { GameService, hashString, sanitizeInput } from '../services/gameDb';
import { User, KeyRound, LogIn, UserPlus, Check, X } from 'lucide-react';
import { getAvatarSrc } from '../utils/avatars';
import { Player } from '../types';

interface Props {
  onLogin: (playerId: string) => void;
  christmasVibe?: boolean;
}

const Auth: React.FC<Props> = ({ onLogin, christmasVibe = true }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  
  // Pending authentication state
  const [pendingUser, setPendingUser] = useState<Player | null>(null);

  const handleInputChange = (setter: (val: string) => void) => (e: React.ChangeEvent<HTMLInputElement>) => {
      // Strictly enforces A-Z 0-9 by stripping anything else automatically
      const val = e.target.value;
      setter(sanitizeInput(val));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanUser = sanitizeInput(username);
    const cleanPass = sanitizeInput(password);
    const cleanConfirm = sanitizeInput(confirmPassword);

    if (!cleanUser || !cleanPass) {
        setError('Заполните все поля');
        return;
    }

    if (cleanPass.length < 4) {
        setError('Пароль слишком короткий (минимум 4 символа)');
        return;
    }

    const hash = hashString(cleanPass);

    if (isLogin) {
        const user = GameService.authenticate(cleanUser, hash);
        if (user) {
            // Step 2: Show Avatar Confirmation
            setPendingUser(user);
        } else {
            setError('Неверный логин или пароль');
        }
    } else {
        if (cleanPass !== cleanConfirm) {
            setError('Пароли не совпадают');
            return;
        }
        
        try {
            const newUser = GameService.registerUser(cleanUser, hash);
            if (newUser) {
                // Auto-confirm for new registration? Or show the check? 
                // Let's just log them in directly for new signups to reduce friction
                onLogin(newUser.id);
            } else {
                setError('Пользователь с таким именем уже существует');
            }
        } catch (err) {
            console.error(err);
            setError('Ошибка регистрации');
        }
    }
  };

  const confirmLogin = () => {
      if (pendingUser) {
          onLogin(pendingUser.id);
      }
  };

  const cancelLogin = () => {
      setPendingUser(null);
      setError('');
  };

  if (pendingUser) {
      return (
        <div className="h-full w-full flex items-center justify-center p-6 relative overflow-hidden bg-slate-50 transition-colors">
            {/* Winter Background */}
            <div 
                className="absolute inset-0 z-0 bg-cover bg-center opacity-60"
                style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1544885935-98dd03d09034?q=80&w=2070&auto=format&fit=crop")' }}
            ></div>
            <div className="absolute inset-0 bg-white/40 backdrop-blur-[2px] z-0"></div>

            <div className="relative z-10 w-full max-w-sm glass-panel p-8 rounded-2xl shadow-xl animate-fade-in border border-white text-center">
                <h2 className="text-xl font-bold text-slate-800 mb-4">Это ваш аккаунт?</h2>
                
                <div className="flex justify-center mb-4">
                    <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white shadow-lg bg-white" onContextMenu={(e) => e.preventDefault()}>
                        <img 
                            src={getAvatarSrc(pendingUser.avatarId)} 
                            alt="Avatar" 
                            className="w-full h-full object-cover pointer-events-none select-none"
                        />
                    </div>
                </div>
                
                <div className="text-2xl font-black text-slate-800 mb-6">{pendingUser.username}</div>

                <div className="flex gap-3">
                    <button 
                        onClick={cancelLogin}
                        className="flex-1 bg-red-100 text-red-600 font-bold py-3 rounded-xl hover:bg-red-200 transition-colors flex items-center justify-center gap-2"
                    >
                        <X size={20} /> Нет
                    </button>
                    <button 
                        onClick={confirmLogin}
                        className="flex-1 bg-green-500 text-white font-bold py-3 rounded-xl hover:bg-green-600 shadow-lg shadow-green-200 transition-all flex items-center justify-center gap-2"
                    >
                        <Check size={20} /> Да
                    </button>
                </div>
            </div>
        </div>
      );
  }

  return (
    <div className="h-full w-full flex items-center justify-center p-6 relative overflow-hidden bg-slate-50 transition-colors">
        {/* Winter Background */}
        <div 
            className="absolute inset-0 z-0 bg-cover bg-center opacity-60"
            style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1544885935-98dd03d09034?q=80&w=2070&auto=format&fit=crop")' }}
        ></div>
        <div className="absolute inset-0 bg-white/40 backdrop-blur-[2px] z-0"></div>

        <div className="relative z-10 w-full max-w-sm glass-panel p-8 rounded-2xl shadow-xl animate-fade-in border border-white">
            
            {/* Christmas Garland */}
            {christmasVibe && (
                <div className="garland-container -mt-4 mb-4">
                    <div className="bulb red"></div>
                    <div className="bulb gold"></div>
                    <div className="bulb green"></div>
                    <div className="bulb blue"></div>
                    <div className="bulb red"></div>
                    <div className="bulb gold"></div>
                </div>
            )}

            <div className="text-center mb-8">
                <h1 className="text-3xl font-bold text-slate-800 drop-shadow-sm">
                    Financial Trader
                </h1>
                <p className="text-slate-500 text-sm mt-2 font-medium">
                    {isLogin ? 'Вход в систему' : 'Новая регистрация'}
                </p>
            </div>

            {error && (
                <div className="bg-red-50 border border-red-200 text-red-600 text-sm p-3 rounded-xl mb-4 text-center font-bold">
                    {error}
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 pl-1 uppercase tracking-wider">Логин</label>
                    <div className="relative">
                        <User className="absolute left-3 top-3 text-slate-400" size={18} />
                        <input 
                            type="text" 
                            value={username}
                            onChange={handleInputChange(setUsername)}
                            className="w-full bg-white/80 border border-slate-200 rounded-xl p-3 pl-10 text-slate-800 focus:border-teal-500 focus:ring-2 focus:ring-teal-100 outline-none transition-all placeholder:text-slate-400"
                            placeholder="username"
                            autoComplete="off"
                            autoCorrect="off"
                            autoCapitalize="none"
                            spellCheck="false"
                        />
                    </div>
                </div>

                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 pl-1 uppercase tracking-wider">Пароль</label>
                    <div className="relative">
                        <KeyRound className="absolute left-3 top-3 text-slate-400" size={18} />
                        <input 
                            type="password" 
                            value={password}
                            onChange={handleInputChange(setPassword)}
                            className="w-full bg-white/80 border border-slate-200 rounded-xl p-3 pl-10 text-slate-800 focus:border-teal-500 focus:ring-2 focus:ring-teal-100 outline-none transition-all placeholder:text-slate-400"
                            placeholder="••••••"
                            autoComplete="off"
                            autoCorrect="off"
                            autoCapitalize="none"
                            spellCheck="false"
                        />
                    </div>
                </div>

                {!isLogin && (
                    <div className="space-y-1 animate-fade-in">
                        <label className="text-xs font-bold text-slate-500 pl-1 uppercase tracking-wider">Повтор пароля</label>
                        <div className="relative">
                            <KeyRound className="absolute left-3 top-3 text-slate-400" size={18} />
                            <input 
                                type="password" 
                                value={confirmPassword}
                                onChange={handleInputChange(setConfirmPassword)}
                                className="w-full bg-white/80 border border-slate-200 rounded-xl p-3 pl-10 text-slate-800 focus:border-teal-500 focus:ring-2 focus:ring-teal-100 outline-none transition-all placeholder:text-slate-400"
                                placeholder="••••••"
                                autoComplete="off"
                                autoCorrect="off"
                                autoCapitalize="none"
                                spellCheck="false"
                            />
                        </div>
                    </div>
                )}

                <button 
                    type="submit"
                    className="w-full bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-200 transform active:scale-[0.98] transition-all mt-4 flex items-center justify-center gap-2"
                >
                    {isLogin ? <LogIn size={20} /> : <UserPlus size={20} />}
                    {isLogin ? 'Войти' : 'Создать аккаунт'}
                </button>
            </form>

            <div className="mt-6 text-center">
                <button 
                    onClick={() => { setIsLogin(!isLogin); setError(''); setUsername(''); setPassword(''); }}
                    className="text-sm text-slate-500 hover:text-teal-600 transition-colors font-medium underline decoration-dashed underline-offset-4"
                >
                    {isLogin ? 'Нет аккаунта? Зарегистрироваться' : 'Уже есть аккаунт? Войти'}
                </button>
            </div>
        </div>
    </div>
  );
};

export default Auth;
