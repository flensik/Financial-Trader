import React, { useState } from 'react';
import { Player, Language } from '../types';
import { formatCurrency } from './Formatters';
import { Briefcase, Receipt, ArrowUp, PenLine, Check, Trash2, Store, Car, Factory, Hammer, Rocket, Building2 } from 'lucide-react';
import { GameService } from '../services/gameDb';
import ConfirmationModal from './ConfirmationModal';
import { t } from '../utils/translations';

interface Props {
  player: Player;
  onUpdate: (p: Player) => void;
  christmasVibe?: boolean;
  lang?: Language;
}

const getIcon = (name: string, size: number = 24) => {
    // Consistent Icon Style
    const props = { size, className: "text-white" };
    switch(name) {
        case 'Store': return <Store {...props} />;
        case 'Car': return <Car {...props} />;
        case 'Factory': return <Factory {...props} />;
        case 'Hammer': return <Hammer {...props} />;
        case 'Rocket': return <Rocket {...props} />;
        default: return <Building2 {...props} />;
    }
}

// Background colors for the icon containers to ensure "same style"
const BG_COLORS: Record<string, string> = {
    'b1': 'bg-blue-500',
    'b2': 'bg-orange-500',
    'b3': 'bg-slate-600',
    'b4': 'bg-yellow-600',
    'b5': 'bg-purple-600',
};

const BusinessTab: React.FC<Props> = ({ player, onUpdate, christmasVibe = true, lang = 'ru' }) => {
  const dbConfig = GameService.loadDatabase().config;
  const taxRate = dbConfig.taxRate;
  
  const [pendingBusId, setPendingBusId] = useState<string | null>(null);
  const [pendingSellId, setPendingSellId] = useState<string | null>(null);
  
  // Renaming State
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  
  // Rename Confirmation
  const [pendingRename, setPendingRename] = useState<{id: string, name: string, cost: number} | null>(null);

  const getTimestamp = () => new Date().toISOString().replace('T', ' ').substring(0, 19);

  const handleBuyClick = (businessId: string, cost: number) => {
      if (player.balance < cost) {
          alert('Недостаточно денег!');
          return;
      }
      setPendingBusId(businessId);
  };

  const confirmPurchase = () => {
    if (!pendingBusId) return;
    const businessId = pendingBusId;
    let logMessage = '';
    
    const updatedBusinesses = player.businesses.map(b => {
        if (b.id === businessId) {
            const cost = b.owned ? b.baseCost * Math.pow(1.5, b.level) : b.baseCost;
            if (player.balance >= cost) {
                player.balance -= cost;
                
                // Prepare Log
                const actionType = b.owned ? 'Улучшил' : 'Купил';
                logMessage = `[${getTimestamp()}] ${actionType} бизнес '${b.customName || b.name}' до УР ${b.level + 1} за ${formatCurrency(cost)}`;
                
                return { 
                    ...b, 
                    owned: true, 
                    level: b.level + 1
                };
            }
        }
        return b;
    });

    // Update with logs if purchase was successful
    if (logMessage) {
        onUpdate({ 
            ...player, 
            businesses: updatedBusinesses,
            logs: [...player.logs, logMessage].slice(-500) 
        });
    } else {
        // Fallback for insufficient funds (though button is disabled)
        onUpdate({ ...player, businesses: updatedBusinesses });
    }
    
    setPendingBusId(null);
  };

  const confirmSell = () => {
      if (!pendingSellId) return;
      let logMessage = '';

      const updatedBusinesses = player.businesses.map(b => {
          if (b.id === pendingSellId && b.owned) {
               // Sell logic: Return 50% of base cost
               const sellPrice = b.baseCost * 0.5;
               player.balance += sellPrice;
               
               logMessage = `[${getTimestamp()}] Продал бизнес '${b.customName || b.name}' за ${formatCurrency(sellPrice)}`;

               return { ...b, owned: false, level: 0, customName: undefined };
          }
          return b;
      });

      if (logMessage) {
          onUpdate({ 
              ...player, 
              businesses: updatedBusinesses,
              logs: [...player.logs, logMessage].slice(-500)
          });
      } else {
          onUpdate({ ...player, businesses: updatedBusinesses });
      }

      setPendingSellId(null);
  };

  const startRenaming = (id: string, currentName: string) => {
      setRenamingId(id);
      setNewName(currentName || '');
  };

  const requestRename = (id: string) => {
      const b = player.businesses.find(x => x.id === id);
      if (!b) return;
      
      const oldName = b.customName || b.name;
      const finalName = newName.trim();
      
      if (finalName && finalName !== oldName) {
          const totalSpent = GameService.calculateTotalBusinessCost(b);
          const renameCost = Math.floor(totalSpent / 7);
          setPendingRename({ id, name: finalName, cost: renameCost });
      } else {
          setRenamingId(null);
      }
  };

  const confirmRename = () => {
      if (!pendingRename) return;
      
      if (player.balance < pendingRename.cost) {
          alert('Недостаточно средств для переименования');
          setPendingRename(null);
          setRenamingId(null);
          return;
      }

      let logMessage = '';
      const updatedBusinesses = player.businesses.map(b => {
          if (b.id === pendingRename.id) {
              const oldName = b.customName || b.name;
              logMessage = `[${getTimestamp()}] Смена бренда '${oldName}' -> '${pendingRename.name}'. Расход: ${formatCurrency(pendingRename.cost)}`;
              return { ...b, customName: pendingRename.name };
          }
          return b;
      });
      
      onUpdate({ 
          ...player, 
          balance: player.balance - pendingRename.cost,
          businesses: updatedBusinesses,
          logs: [...player.logs, logMessage].slice(-500)
      });

      setPendingRename(null);
      setRenamingId(null);
  };

  const getPendingDetails = () => {
      if (!pendingBusId) return { title: '', msg: '', bus: null };
      const b = player.businesses.find(x => x.id === pendingBusId);
      if (!b) return { title: '', msg: '', bus: null };
      const cost = b.owned ? b.baseCost * Math.pow(1.5, b.level) : b.baseCost;
      const title = b.owned ? 'Улучшить бизнес?' : 'Купить бизнес?';
      const msg = `Вы уверены, что хотите потратить ${formatCurrency(cost)}?`;
      return { title, msg, bus: b };
  };

  const getSellDetails = () => {
      if (!pendingSellId) return { title: '', msg: '' };
      const b = player.businesses.find(x => x.id === pendingSellId);
      if (!b) return { title: '', msg: '' };
      return {
          title: 'Продать бизнес?',
          msg: `Вы получите ${formatCurrency(b.baseCost * 0.5)}. Все улучшения будут потеряны.`
      };
  };

  const buyDetails = getPendingDetails();
  const sellDetails = getSellDetails();

  return (
    <div className="flex flex-col h-full p-5 overflow-y-auto pb-24 relative animate-fade-in text-slate-800">
       <ConfirmationModal 
          isOpen={!!pendingBusId}
          title={buyDetails.title}
          message={buyDetails.msg}
          onConfirm={confirmPurchase}
          onCancel={() => setPendingBusId(null)}
       />
       
       <ConfirmationModal 
          isOpen={!!pendingSellId}
          title={sellDetails.title}
          message={sellDetails.msg}
          onConfirm={confirmSell}
          onCancel={() => setPendingSellId(null)}
          isDangerous={true}
          confirmText="Продать"
       />

       <ConfirmationModal 
          isOpen={!!pendingRename}
          title="Смена бренда"
          message={`Стоимость ребрендинга (1/7 от инвестиций): ${formatCurrency(pendingRename?.cost || 0)}. Продолжить?`}
          onConfirm={confirmRename}
          onCancel={() => { setPendingRename(null); setRenamingId(null); }}
          confirmText="Оплатить"
       />

       {/* Background Image fixed */}
       <div 
        className="absolute inset-0 z-0 bg-cover bg-center fixed"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop")' }}
      ></div>
      <div className="absolute inset-0 bg-slate-50/90 z-0 fixed backdrop-blur-sm"></div>

      <div className="relative z-10">
        <div className="flex items-end justify-between mb-8">
            <div>
                 {christmasVibe && (
                     <div className="garland-container justify-start mb-1 scale-75 origin-left -ml-2">
                        <div className="bulb blue"></div>
                        <div className="bulb red"></div>
                        <div className="bulb gold"></div>
                        <div className="bulb green"></div>
                     </div>
                 )}
                 <h1 className="text-3xl font-black text-slate-900 leading-none">{t('header.business', lang)}</h1>
                 <p className="text-slate-500 text-xs font-bold uppercase mt-1">Управление активами</p>
            </div>
            <div className="bg-white/80 backdrop-blur-md px-3 py-1.5 rounded-xl text-slate-600 text-xs font-bold shadow-sm border border-slate-200 flex items-center gap-1.5">
                <Receipt size={14} className="text-red-500"/> 
                <span>{t('biz.tax', lang)}: {(taxRate * 100).toFixed(0)}%</span>
            </div>
        </div>
        
        <div className="space-y-5">
            {player.businesses.map((bus) => {
                const nextCost = bus.owned ? bus.baseCost * Math.pow(1.5, bus.level) : bus.baseCost;
                const grossIncome = bus.owned ? bus.baseIncome * Math.pow(1.07, bus.level) : 0; 
                const taxAmount = grossIncome * taxRate;
                const netIncome = grossIncome - taxAmount;
                const canAfford = player.balance >= nextCost;
                const bgColor = BG_COLORS[bus.id] || 'bg-slate-400';

                return (
                    <div key={bus.id} className="bg-white rounded-[20px] p-4 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.08)] border border-slate-100 relative overflow-hidden group transition-transform active:scale-[0.99]">
                        {bus.owned && (
                             <div className="absolute top-0 right-0 bg-green-500 text-white text-[9px] font-bold px-3 py-1 rounded-bl-xl z-20 shadow-sm">
                                {t('biz.owned', lang)}
                             </div>
                        )}

                        <div className="flex gap-4">
                            <div className={`w-20 h-20 rounded-2xl overflow-hidden shadow-md flex-shrink-0 flex items-center justify-center ${bgColor} relative`}>
                                {/* Consistent Icon Style */}
                                {getIcon(bus.icon, 36)}
                                <div className="absolute inset-0 bg-white/10"></div>
                            </div>

                            <div className="flex-1 flex flex-col justify-between py-0.5">
                                <div>
                                    {/* Name Section with Rename support */}
                                    {renamingId === bus.id ? (
                                        <div className="flex gap-2 items-center mb-1">
                                            <input 
                                                type="text" 
                                                value={newName} 
                                                onChange={e => setNewName(e.target.value)}
                                                className="bg-slate-900 text-white font-bold p-1.5 rounded text-sm w-full outline-none border border-slate-700 placeholder-slate-500"
                                                autoFocus
                                                placeholder="Введите название..."
                                            />
                                            <button onClick={() => requestRename(bus.id)} className="bg-green-500 hover:bg-green-600 text-white p-1.5 rounded">
                                                <Check size={16}/>
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="flex items-center gap-2">
                                            <h3 className="font-extrabold text-slate-800 text-lg leading-tight truncate">{bus.customName || bus.name}</h3>
                                            {bus.owned && (
                                                <button onClick={() => startRenaming(bus.id, bus.customName || bus.name)} className="text-slate-400 hover:text-slate-600 p-1">
                                                    <PenLine size={12}/>
                                                </button>
                                            )}
                                        </div>
                                    )}
                                    
                                    {bus.customName && renamingId !== bus.id && <div className="text-[10px] text-slate-400">({bus.name})</div>}
                                    
                                    <div className="flex items-center gap-2 mt-1">
                                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wide">{bus.type}</span>
                                        {bus.owned && <span className="bg-slate-100 text-slate-600 text-[10px] px-1.5 py-0.5 rounded font-bold border border-slate-200">LVL {bus.level}</span>}
                                    </div>
                                </div>

                                <div className="flex justify-between items-end mt-2">
                                     {bus.owned ? (
                                        <div>
                                            <div className="text-green-600 font-bold text-sm leading-none flex items-center gap-1">
                                                +{formatCurrency(netIncome)}<span className="text-[10px] text-slate-400 font-normal">{t('biz.income', lang)}</span>
                                            </div>
                                            <div className="text-[9px] text-red-400 font-medium mt-0.5">
                                                Tax: -{formatCurrency(taxAmount)}
                                            </div>
                                        </div>
                                     ) : (
                                         <div className="text-xs text-slate-400 font-medium italic">Не приобретено</div>
                                     )}
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-2 mt-4">
                            <button
                                onClick={() => handleBuyClick(bus.id, nextCost)}
                                className={`flex-1 py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                                    canAfford 
                                    ? 'bg-slate-900 text-white shadow-lg shadow-slate-300 hover:bg-slate-800 active:translate-y-1' 
                                    : 'bg-slate-100 text-slate-400 cursor-pointer border border-slate-200'
                                }`}
                            >
                                <span>{bus.owned ? t('biz.upgrade', lang) : t('biz.buy', lang)}</span>
                                <span className={`text-xs ${canAfford ? 'text-slate-300' : 'text-slate-400'}`}>
                                    ({formatCurrency(nextCost)})
                                </span>
                                {bus.owned && <ArrowUp size={14} className={canAfford ? 'text-green-400' : ''}/>}
                            </button>
                            
                            {bus.owned && (
                                <button 
                                    onClick={() => setPendingSellId(bus.id)}
                                    className="px-3 rounded-xl bg-red-50 text-red-500 hover:bg-red-100 border border-red-100"
                                    title="Продать бизнес"
                                >
                                    <Trash2 size={16} />
                                </button>
                            )}
                        </div>
                    </div>
                );
            })}
        </div>
      </div>
    </div>
  );
};

export default BusinessTab;
