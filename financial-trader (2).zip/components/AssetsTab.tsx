import React, { useState } from 'react';
import { Player, GameAsset, AssetCategory } from '../types';
import { GAME_ASSETS, GameService } from '../services/gameDb';
import { formatCurrency } from './Formatters';
import { Home, Car, Diamond, Crown, Check, Lock, ShoppingBag, Ship, Plane, Bike, Watch, Gem, Palette, Coins, Key } from 'lucide-react';
import ConfirmationModal from './ConfirmationModal';

interface Props {
  player: Player;
  onUpdate: (p: Player) => void;
}

const AssetsTab: React.FC<Props> = ({ player, onUpdate }) => {
  const [activeCategory, setActiveCategory] = useState<AssetCategory>('property');
  const [transportFilter, setTransportFilter] = useState<'all' | 'land' | 'water' | 'air'>('all');
  const [buyingAsset, setBuyingAsset] = useState<GameAsset | null>(null);

  const assets = GAME_ASSETS.filter(a => {
      if (a.category !== activeCategory) return false;
      if (activeCategory === 'transport' && transportFilter !== 'all') {
          return a.subCategory === transportFilter;
      }
      return true;
  });

  const handleBuy = (asset: GameAsset) => {
      setBuyingAsset(asset);
  };

  const confirmBuy = () => {
      if (!buyingAsset) return;
      
      const res = GameService.buyAsset(player.id, buyingAsset.id);
      if (res.success) {
          // Manually update local state to avoid full reload delay
          const updatedPlayer = {
              ...player,
              balance: player.balance - buyingAsset.price,
              ownedAssetIds: [...player.ownedAssetIds, buyingAsset.id],
              activeTitleId: buyingAsset.category === 'title' ? buyingAsset.id : player.activeTitleId
          };
          onUpdate(updatedPlayer);
      } else {
          alert(res.msg);
      }
      setBuyingAsset(null);
  };

  const handleEquipTitle = (assetId: string) => {
      const res = GameService.setActiveTitle(player.id, assetId);
      if (res.success) {
          onUpdate({ ...player, activeTitleId: assetId });
      }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-800 p-0 overflow-hidden animate-fade-in relative">
        <ConfirmationModal 
            isOpen={!!buyingAsset}
            title="Подтверждение покупки"
            message={`Купить "${buyingAsset?.name}" за ${formatCurrency(buyingAsset?.price || 0)}?`}
            onConfirm={confirmBuy}
            onCancel={() => setBuyingAsset(null)}
            confirmText="Купить"
        />

        {/* Header */}
        <div className="p-6 bg-white border-b border-slate-200 z-10 sticky top-0 shadow-sm">
            <div className="flex justify-between items-end mb-4">
                <div>
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                        <ShoppingBag className="text-blue-600" /> Lifestyle
                    </h2>
                    <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">
                        Статус решает всё
                    </p>
                </div>
                <div className="text-right">
                    <div className="text-xs text-slate-500 font-bold uppercase">Баланс</div>
                    <div className="text-xl font-mono text-green-600 font-bold">{formatCurrency(player.balance)}</div>
                </div>
            </div>

            {/* Category Nav */}
            <div className="flex bg-slate-100 p-1 rounded-xl overflow-x-auto no-scrollbar gap-1">
                <CategoryButton 
                    active={activeCategory === 'property'} 
                    onClick={() => setActiveCategory('property')} 
                    icon={<Home size={16}/>} 
                    label="Жилье" 
                />
                <CategoryButton 
                    active={activeCategory === 'transport'} 
                    onClick={() => setActiveCategory('transport')} 
                    icon={<Car size={16}/>} 
                    label="Транспорт" 
                />
                <CategoryButton 
                    active={activeCategory === 'luxury'} 
                    onClick={() => setActiveCategory('luxury')} 
                    icon={<Diamond size={16}/>} 
                    label="Роскошь" 
                />
                <CategoryButton 
                    active={activeCategory === 'nft'} 
                    onClick={() => setActiveCategory('nft')} 
                    icon={<Coins size={16}/>} 
                    label="NFT" 
                />
                <CategoryButton 
                    active={activeCategory === 'title'} 
                    onClick={() => setActiveCategory('title')} 
                    icon={<Crown size={16}/>} 
                    label="Титулы" 
                />
            </div>

            {/* Sub-Filters for Transport */}
            {activeCategory === 'transport' && (
                <div className="flex mt-3 gap-2 animate-fade-in overflow-x-auto no-scrollbar">
                    <button onClick={() => setTransportFilter('all')} className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${transportFilter === 'all' ? 'bg-slate-800 text-white' : 'bg-slate-200 text-slate-500'}`}>Все</button>
                    <button onClick={() => setTransportFilter('land')} className={`px-3 py-1 rounded-full text-xs font-bold transition-all flex items-center gap-1 ${transportFilter === 'land' ? 'bg-orange-500 text-white' : 'bg-slate-200 text-slate-500'}`}><Car size={12}/> Земля</button>
                    <button onClick={() => setTransportFilter('water')} className={`px-3 py-1 rounded-full text-xs font-bold transition-all flex items-center gap-1 ${transportFilter === 'water' ? 'bg-blue-500 text-white' : 'bg-slate-200 text-slate-500'}`}><Ship size={12}/> Вода</button>
                    <button onClick={() => setTransportFilter('air')} className={`px-3 py-1 rounded-full text-xs font-bold transition-all flex items-center gap-1 ${transportFilter === 'air' ? 'bg-purple-500 text-white' : 'bg-slate-200 text-slate-500'}`}><Plane size={12}/> Воздух</button>
                </div>
            )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 pb-24 space-y-4 bg-slate-50">
            {assets.length === 0 && (
                <div className="text-center text-slate-400 py-10">В этой категории пока пусто</div>
            )}
            
            {assets.map(asset => {
                const isOwned = player.ownedAssetIds.includes(asset.id);
                const canAfford = player.balance >= asset.price;
                const isActiveTitle = player.activeTitleId === asset.id;

                let BadgeIcon = null;
                let badgeColor = 'bg-slate-500';
                
                if (asset.category === 'transport') {
                    if (asset.subCategory === 'land') { BadgeIcon = Car; badgeColor = 'bg-orange-500'; }
                    if (asset.subCategory === 'water') { BadgeIcon = Ship; badgeColor = 'bg-blue-500'; }
                    if (asset.subCategory === 'air') { BadgeIcon = Plane; badgeColor = 'bg-purple-500'; }
                } else if (asset.category === 'luxury') {
                    if (asset.subCategory === 'watch') { BadgeIcon = Watch; badgeColor = 'bg-slate-600'; }
                    if (asset.subCategory === 'jewelry') { BadgeIcon = Gem; badgeColor = 'bg-pink-500'; }
                    if (asset.subCategory === 'art') { BadgeIcon = Palette; badgeColor = 'bg-indigo-500'; }
                } else if (asset.category === 'nft') {
                    BadgeIcon = Coins; badgeColor = 'bg-blue-600';
                }

                return (
                    <div key={asset.id} className="relative group overflow-hidden rounded-2xl bg-white border border-slate-200 shadow-sm transition-all hover:shadow-lg active:scale-[0.99]">
                        {/* Image */}
                        <div className="h-48 w-full overflow-hidden relative bg-slate-100">
                            <img src={asset.image} alt={asset.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
                            
                            {/* Badges */}
                            <div className="absolute top-3 left-3 flex flex-col gap-1">
                                {BadgeIcon && (
                                    <div className={`${badgeColor} text-white text-[10px] font-bold p-1.5 rounded-lg shadow-sm w-fit`}>
                                        <BadgeIcon size={14} />
                                    </div>
                                )}
                            </div>

                            {isOwned && (
                                <div className="absolute top-3 right-3 bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded shadow-lg z-20 flex items-center gap-1">
                                    <Check size={12} /> OWNED
                                </div>
                            )}
                            
                            {!isOwned && !canAfford && (
                                <div className="absolute inset-0 bg-white/50 backdrop-blur-[1px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                    <Lock size={32} className="text-slate-400" />
                                </div>
                            )}
                        </div>

                        {/* Info */}
                        <div className="p-4">
                            <div className="flex justify-between items-start mb-1">
                                <div>
                                    <h3 className="text-lg font-black text-slate-800 leading-tight">{asset.name}</h3>
                                    {asset.category === 'title' && (
                                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-500 mt-1 inline-block" style={{ color: asset.titleColor }}>
                                            Цвет: {player.username}
                                        </span>
                                    )}
                                </div>
                                {!isOwned && (
                                    <div className="font-mono font-bold text-green-600 text-lg">
                                        {formatCurrency(asset.price)}
                                    </div>
                                )}
                            </div>
                            
                            <p className="text-slate-500 text-xs mb-4 line-clamp-2 min-h-[2.5em]">{asset.description}</p>

                            {isOwned ? (
                                asset.category === 'title' ? (
                                    <button 
                                        onClick={() => handleEquipTitle(asset.id)}
                                        disabled={isActiveTitle}
                                        className={`w-full py-2.5 rounded-xl font-bold text-sm transition-all ${isActiveTitle ? 'bg-green-100 text-green-600 border border-green-200' : 'bg-slate-900 hover:bg-slate-800 text-white shadow-lg shadow-slate-300'}`}
                                    >
                                        {isActiveTitle ? 'Используется' : 'Надеть'}
                                    </button>
                                ) : (
                                    <div className="w-full py-2.5 bg-slate-100 rounded-xl text-center text-slate-400 text-xs font-bold border border-slate-200 flex items-center justify-center gap-2">
                                        <Check size={14}/> Куплено
                                    </div>
                                )
                            ) : (
                                <button 
                                    onClick={() => handleBuy(asset)}
                                    disabled={!canAfford}
                                    className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                                        canAfford 
                                        ? 'bg-slate-900 hover:bg-slate-800 text-white shadow-lg shadow-slate-300 active:translate-y-0.5' 
                                        : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                                    }`}
                                >
                                    {!canAfford && <Lock size={14}/>}
                                    Купить
                                </button>
                            )}
                        </div>
                    </div>
                );
            })}
            
            {/* Space Filler */}
            <div className="h-8"></div>
        </div>
    </div>
  );
};

const CategoryButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
    <button 
        onClick={onClick}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex-1 justify-center border ${
            active 
            ? 'bg-white border-blue-200 text-blue-600 shadow-sm' 
            : 'bg-transparent border-transparent text-slate-500 hover:bg-slate-200'
        }`}
    >
        {icon}
        {label}
    </button>
);

export default AssetsTab;