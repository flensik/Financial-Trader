import React from 'react';

const SnowOverlay: React.FC = () => {
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[100]">
      <div className="snowflake" style={{ left: '5%', animationDelay: '0s, 0s', fontSize: '1.5em' }}>❄</div>
      <div className="snowflake" style={{ left: '15%', animationDelay: '2s, 1s', fontSize: '1em' }}>❅</div>
      <div className="snowflake" style={{ left: '25%', animationDelay: '4s, 2s', fontSize: '0.8em' }}>❆</div>
      <div className="snowflake" style={{ left: '35%', animationDelay: '1s, 1.5s', fontSize: '1.2em' }}>❄</div>
      <div className="snowflake" style={{ left: '45%', animationDelay: '6s, 0.5s', fontSize: '0.9em' }}>❅</div>
      <div className="snowflake" style={{ left: '55%', animationDelay: '3s, 2.5s', fontSize: '1.4em' }}>❆</div>
      <div className="snowflake" style={{ left: '65%', animationDelay: '5s, 1s', fontSize: '1.1em' }}>❄</div>
      <div className="snowflake" style={{ left: '75%', animationDelay: '2.5s, 0.2s', fontSize: '0.8em' }}>❅</div>
      <div className="snowflake" style={{ left: '85%', animationDelay: '7s, 3s', fontSize: '1.3em' }}>❆</div>
      <div className="snowflake" style={{ left: '95%', animationDelay: '0.5s, 1.5s', fontSize: '1em' }}>❄</div>
    </div>
  );
};

export default SnowOverlay;