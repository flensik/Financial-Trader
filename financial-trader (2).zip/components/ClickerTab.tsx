import React, { useState } from 'react';
import { Player, Language } from '../types';
import { GameService } from '../services/gameDb';
import { formatCurrency } from './Formatters';
import { MousePointer2, Zap, ArrowUpRight, Wallet } from 'lucide-react';
import { t } from '../utils/translations';

interface Props {
  player: Player;
  onUpdate: (p: Player) => void;
  christmasVibe?: boolean;
  lang?: Language;
}

const ClickerTab: React.FC<Props> = ({ player, onUpdate, christmasVibe = true, lang = 'ru' }) => {
  const [clickScale, setClickScale] = useState(1);
  const [floatingText, setFloatingText] = useState<{id: number, val: number, x: number, y: number}[]>([]);

  const getTimestamp = () => new Date().toISOString().replace('T', ' ').substring(0, 19);

  const handleClick = (e: React.MouseEvent) => {
    // Visual feedback
    setClickScale(0.9);
    setTimeout(() => setClickScale(1), 80);

    // Logic
    const clickValue = GameService.calculateClickValue(player);
    let newBalance = player.balance + clickValue;
    let newExp = player.clickExp + 1;
    let newLevel = player.clickLevel;
    let newMaxExp = player.clickExpMax;
    let logMessage = '';

    if (newExp >= player.clickExpMax) {
        newLevel += 1;
        newExp = 0;
        newMaxExp = Math.floor(player.clickExpMax * 1.5);
        logMessage = `[${getTimestamp()}] Новый уровень! Достигнут уровень ${newLevel}`;
    }

    // Text Particle
    const offsetX = (Math.random() - 0.5) * 40;
    const offsetY = (Math.random() - 0.5) * 40;
    const newText = { id: Date.now(), val: clickValue, x: e.clientX + offsetX, y: e.clientY + offsetY - 50 };
    
    setFloatingText(prev => [...prev, newText]);
    setTimeout(() => {
        setFloatingText(prev => prev.filter(t => t.id !== newText.id));
    }, 8000); // Wait for animation to finish

    if (logMessage) {
        onUpdate({
            ...player,
            balance: newBalance,
            clickExp: newExp,
            clickLevel: newLevel,
            clickExpMax: newMaxExp,
            logs: [...player.logs, logMessage].slice(-500)
        });
    } else {
        onUpdate({
            ...player,
            balance: newBalance,
            clickExp: newExp,
            clickLevel: newLevel,
            clickExpMax: newMaxExp
        });
    }
  };

  const incomePerHour = GameService.calculatePassiveIncome(player) * 3600;
  const progressPercent = (player.clickExp / player.clickExpMax) * 100;

  return (
    <div className="flex flex-col h-full p-5 relative overflow-y-auto pb-24 animate-fade-in text-slate-800">
      
      {/* Header with Garland */}
      <div className="relative z-10 flex justify-between items-center mt-2 mb-6">
        <div>
            {christmasVibe && (
                <div className="garland-container justify-start mb-1 scale-75 origin-left -ml-2">
                    <div className="bulb red"></div>
                    <div className="bulb gold"></div>
                    <div className="bulb green"></div>
                    <div className="bulb blue"></div>
                </div>
            )}
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">{t('header.main', lang)}</h1>
            <p className="text-xs text-slate-500 font-semibold uppercase tracking-wide">Financial Trader</p>
        </div>
        <div className="w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center">
            <div className="text-lg">👑</div>
        </div>
      </div>

      {/* Balance Card - Premium Dark */}
      <div className="relative z-10 glass-card-dark rounded-[24px] p-6 mb-8 transform transition-transform hover:scale-[1.02] duration-300 flex-shrink-0">
        <div className="flex justify-between items-start mb-6">
             <div className="bg-white/10 p-2 rounded-xl backdrop-blur-md border border-white/10">
                <Wallet className="text-teal-300" size={24} />
             </div>
             <div className="text-right">
                <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">{t('clicker.bank', lang)}</div>
                <div className="flex items-center justify-end gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                    <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                </div>
             </div>
        </div>
        
        <div className="mb-6">
            <span className="text-slate-400 text-sm font-medium">{t('clicker.balance', lang)}</span>
            <div className="text-[40px] leading-tight font-bold text-white tracking-tight mt-1 truncate">
                {formatCurrency(player.balance)}
            </div>
        </div>

        <div className="flex items-center gap-3 bg-white/5 p-3 rounded-2xl border border-white/5 backdrop-blur-sm">
            <div className="bg-green-500/20 p-2 rounded-xl">
                <Zap size={18} className="text-green-400" />
            </div>
            <div>
                <div className="text-green-400 text-sm font-bold flex items-center gap-1">
                    +{formatCurrency(incomePerHour)} <ArrowUpRight size={14}/>
                </div>
                <div className="text-[10px] text-slate-400 font-medium">{t('clicker.income', lang)}</div>
            </div>
        </div>
        
        {/* Decorative Circles */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/20 rounded-full blur-[40px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/20 rounded-full blur-[30px] pointer-events-none"></div>
      </div>

      {/* Level Progress */}
      <div className="relative z-10 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm mb-6 flex-shrink-0">
        <div className="flex justify-between items-end mb-2">
            <div>
                <span className="text-xs font-bold text-slate-400 uppercase">{t('clicker.level', lang)} {player.clickLevel}</span>
                <div className="text-slate-900 font-bold text-sm">Опыт Магната</div>
            </div>
            <div className="text-right">
                 <div className="text-teal-600 font-bold text-sm">+{formatCurrency(GameService.calculateClickValue(player))}</div>
                 <div className="text-[10px] text-slate-400 font-medium">за клик</div>
            </div>
        </div>
        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
            <div 
                className="h-full bg-gradient-to-r from-teal-400 to-blue-500 rounded-full transition-all duration-500 ease-out shadow-[0_0_10px_rgba(45,212,191,0.4)]"
                style={{ width: `${progressPercent}%` }}
            ></div>
        </div>
        <div className="text-right mt-1 text-[10px] text-slate-400 font-mono font-bold">
            {player.clickExp} / {player.clickExpMax} XP
        </div>
      </div>

      {/* Main Clicker Button */}
      <div className="flex-1 flex flex-col items-center justify-center relative z-10 min-h-[300px]">
        <div className="relative">
             {/* Glow Effect */}
            <div className="absolute inset-0 bg-teal-400/30 rounded-full blur-[40px] animate-pulse"></div>
            
            <button 
                onClick={handleClick}
                style={{ transform: `scale(${clickScale})` }}
                className="relative w-64 h-64 rounded-full border-[8px] border-white bg-gradient-to-br from-[#f8fafc] to-[#e2e8f0] shadow-[0_20px_50px_-12px_rgba(0,0,0,0.15),inset_0_-10px_20px_rgba(0,0,0,0.05)] flex flex-col items-center justify-center active:scale-95 transition-transform duration-100 cursor-pointer overflow-hidden group"
            >
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-white/80 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-teal-50/50 to-transparent"></div>
                
                <MousePointer2 size={64} className="text-slate-800 drop-shadow-lg relative z-10 group-hover:text-teal-600 transition-colors" />
                <span className="text-xs font-bold text-slate-400 mt-2 uppercase tracking-widest relative z-10 group-hover:text-teal-500">{t('clicker.taphere', lang)}</span>
            </button>
        </div>

        {/* Floating Text Particles */}
        {floatingText.map(t => (
            <div 
                key={t.id}
                className="absolute pointer-events-none font-bold text-2xl z-50 flex items-center gap-1"
                style={{ 
                    left: t.x, 
                    top: t.y, 
                    animation: 'float 1s ease-out forwards, fadeOut 1s ease-in forwards',
                    color: '#059669',
                    textShadow: '0 2px 10px rgba(255,255,255,0.8)'
                }}
            >
                +{formatCurrency(t.val)}
            </div>
        ))}
        
        <style>{`
            @keyframes fadeOut {
                0% { opacity: 1; transform: translateY(0) scale(1); }
                100% { opacity: 0; transform: translateY(-80px) scale(1.2); }
            }
        `}</style>
      </div>
    </div>
  );
};

export default ClickerTab;
