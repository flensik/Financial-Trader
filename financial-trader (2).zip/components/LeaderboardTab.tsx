import React, { useState } from 'react';
import { GAME_ASSETS, GameService } from '../services/gameDb';
import { formatCompact, formatCurrency, formatTime } from './Formatters';
import { Trophy, Medal, User, TrendingUp, Wallet, X, Briefcase, Server, Clock, Crown, Star } from 'lucide-react';
import { Language, Player, GameAsset } from '../types';
import { t } from '../utils/translations';
import { getAvatarSrc } from '../utils/avatars';

interface Props {
    lang?: Language;
}

// Render the special effect around the avatar
const TitleEffect: React.FC<{ effectType: GameAsset['effectType'], color: string }> = ({ effectType, color }) => {
    if (!effectType) return null;

    if (effectType === 'orbit') {
        return (
            <div className="absolute inset-[-8px] animate-spin-slow pointer-events-none">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-3 h-3 bg-red-500 rounded-full shadow-[0_0_10px_red]"></div>
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 w-2 h-2 bg-red-400 rounded-full shadow-[0_0_5px_red]"></div>
            </div>
        );
    }
    if (effectType === 'pulse') {
        return (
            <div className="absolute inset-[-4px] rounded-full border-2 animate-pulse opacity-70" style={{ borderColor: color, boxShadow: `0 0 15px ${color}` }}></div>
        );
    }
    if (effectType === 'shine') {
        return (
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/30 to-transparent opacity-50 animate-pulse"></div>
        );
    }
    return null;
};

const LeaderboardTab: React.FC<Props> = ({ lang = 'ru' }) => {
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  
  // Always sort by "assets" logic (Net Worth) for the Forbes look
  const leaders = GameService.getLeaderboard('assets'); 

  const getTitle = (p: Player) => {
      if (p.activeTitleId) {
          const asset = GAME_ASSETS.find(a => a.id === p.activeTitleId);
          if (asset) return asset;
      }
      return null;
  };

  return (
    <div className="flex flex-col h-full bg-[#f8fafc] text-slate-900 relative animate-fade-in font-serif overflow-hidden">
        
        {/* Forbes-style Header (Light) */}
        <div className="pt-8 pb-4 px-6 border-b-4 border-black bg-white relative z-10 shadow-sm">
            <div className="flex justify-between items-end">
                <div className="relative z-10">
                    <div className="text-[10px] font-sans font-black tracking-[0.2em] text-slate-400 uppercase mb-1">World's Richest</div>
                    <h1 className="text-4xl font-serif font-black text-black tracking-tight leading-none">THE LIST</h1>
                    <div className="text-xs font-sans text-slate-500 font-bold mt-2">REAL-TIME RANKING</div>
                </div>
                <div className="text-right">
                    <div className="bg-black text-white text-xs font-sans font-bold px-2 py-1 uppercase tracking-wider">
                        {new Date().getFullYear()} Edition
                    </div>
                </div>
            </div>
        </div>

        {/* Table Header */}
        <div className="flex items-center px-4 py-3 bg-slate-100 border-b border-slate-200 text-[10px] uppercase font-sans font-bold text-slate-500 tracking-wider sticky top-0 z-20 shadow-sm">
            <div className="w-12 text-center">Rank</div>
            <div className="flex-1 pl-2">Name & Source</div>
            <div className="w-28 text-right">Net Worth</div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto pb-24 bg-white">
            {leaders.length === 0 && (
                <div className="text-center text-slate-400 py-20 font-sans italic">Data is compiling...</div>
            )}
            
            {leaders.map((entry, index) => {
                const p = entry.player;
                const netWorth = entry.netWorth;
                const title = getTitle(p);
                const rank = index + 1;
                
                // Top 3 Styling
                const isTop3 = rank <= 3;
                const rankColor = rank === 1 ? 'text-yellow-600' : rank === 2 ? 'text-slate-400' : rank === 3 ? 'text-amber-700' : 'text-slate-900';

                return (
                    <div 
                        key={p.id} 
                        onClick={() => setSelectedPlayer(p)}
                        className={`group flex items-center px-4 py-4 border-b border-slate-100 transition-all cursor-pointer ${isTop3 ? 'bg-slate-50 hover:bg-slate-100' : 'hover:bg-slate-50'}`}
                    >
                        {/* Rank */}
                        <div className={`w-12 text-center font-serif text-2xl font-bold ${rankColor}`}>
                            {rank}.
                        </div>

                        {/* Profile */}
                        <div className="flex-1 flex items-center gap-3 pl-2 overflow-hidden">
                            <div className="w-12 h-12 flex-shrink-0 relative">
                                <div className="w-full h-full rounded-full bg-slate-200 overflow-hidden border border-slate-100 relative shadow-sm z-10">
                                    <img src={getAvatarSrc(p.avatarId)} alt="" className="w-full h-full object-cover" />
                                </div>
                                {title && (
                                    <>
                                        <div className="absolute inset-0 border-[2px] rounded-full z-20 opacity-80" style={{ borderColor: title.titleColor || '#fbbf24' }}></div>
                                        <TitleEffect effectType={title.effectType} color={title.titleColor || '#fbbf24'} />
                                    </>
                                )}
                            </div>
                            <div className="min-w-0">
                                <div className="font-sans font-bold text-base text-slate-900 truncate flex items-center gap-1">
                                    {p.username}
                                    {p.isAdmin && <Crown size={14} className="text-red-600 fill-current"/>}
                                    {rank === 1 && <Star size={14} className="text-yellow-500 fill-current"/>}
                                </div>
                                {title ? (
                                    <div className="text-[10px] font-bold uppercase tracking-wide truncate mt-0.5" style={{ color: title.titleColor || '#64748b' }}>
                                        {title.name}
                                    </div>
                                ) : (
                                    <div className="text-[10px] text-slate-400 font-sans font-bold uppercase tracking-wide mt-0.5">Self-Made</div>
                                )}
                            </div>
                        </div>

                        {/* Net Worth */}
                        <div className="w-28 text-right">
                            <div className="font-mono text-green-700 font-bold text-sm tracking-tight">
                                ${formatCompact(netWorth)}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>

        {/* Modern Profile Modal (Light Theme) */}
        {selectedPlayer && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in font-sans" onClick={() => setSelectedPlayer(null)}>
                <div className="bg-white w-full max-w-sm rounded-none shadow-2xl relative overflow-hidden" onClick={e => e.stopPropagation()}>
                    
                    {/* Magazine Cover Header */}
                    <div className="h-32 bg-slate-900 relative">
                        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                        <button onClick={() => setSelectedPlayer(null)} className="absolute top-4 right-4 text-white hover:text-red-500 bg-white/10 rounded-full p-2 transition-colors z-20">
                            <X size={20} />
                        </button>
                        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
                    </div>

                    <div className="px-6 relative pb-8 -mt-12">
                        {/* Avatar */}
                        <div className="flex justify-center mb-4 relative">
                            <div className="w-28 h-28 relative">
                                <div className="w-full h-full rounded-full border-4 border-white bg-slate-200 shadow-xl overflow-hidden relative z-10">
                                    <img src={getAvatarSrc(selectedPlayer.avatarId)} className="w-full h-full object-cover" />
                                </div>
                                {getTitle(selectedPlayer) && (
                                    <TitleEffect effectType={getTitle(selectedPlayer)?.effectType} color={getTitle(selectedPlayer)?.titleColor || '#fbbf24'} />
                                )}
                            </div>
                        </div>

                        <div className="text-center mb-6">
                            <h3 className="text-3xl font-serif font-black text-slate-900 mb-1">{selectedPlayer.username}</h3>
                            <div className="text-xs text-slate-400 font-mono uppercase tracking-widest mb-3">ID: {selectedPlayer.id}</div>
                            {getTitle(selectedPlayer) && (
                                <span className="px-3 py-1 bg-slate-900 text-white text-xs font-bold uppercase tracking-widest inline-block" style={{ backgroundColor: getTitle(selectedPlayer)?.titleColor }}>
                                    {getTitle(selectedPlayer)?.name}
                                </span>
                            )}
                        </div>

                        <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="border-t-2 border-black pt-2">
                                <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-1">Cash & Liquid</div>
                                <div className="text-green-700 font-mono font-bold text-xl">{formatCompact(selectedPlayer.balance)}</div>
                            </div>
                            <div className="border-t-2 border-slate-200 pt-2">
                                <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-1">Experience</div>
                                <div className="text-slate-900 font-bold flex items-center gap-1">
                                    <Clock size={16} className="text-slate-400"/> {formatTime(selectedPlayer.playtime || 0)}
                                </div>
                            </div>
                        </div>

                        {/* Assets Showcase */}
                        <div className="bg-slate-50 p-4 border border-slate-100">
                            <h4 className="text-xs font-black text-slate-900 uppercase mb-3 flex items-center gap-2 border-b border-slate-200 pb-2">
                                <Briefcase size={14} /> Key Assets
                            </h4>
                            
                            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                                {selectedPlayer.businesses.filter(b => b.owned).length === 0 && selectedPlayer.ownedAssetIds.length === 0 ? (
                                    <div className="text-slate-400 text-xs italic text-center py-4">No major assets reported.</div>
                                ) : (
                                    <>
                                        {/* Shops */}
                                        {selectedPlayer.businesses.filter(b => b.owned).map(b => (
                                            <div key={b.id} className="flex justify-between items-center text-sm py-1 border-b border-slate-200 last:border-0">
                                                <span className="text-slate-700 font-serif font-bold">{b.customName || b.name}</span>
                                                <span className="text-[9px] text-slate-500 font-sans font-bold uppercase">Lvl {b.level}</span>
                                            </div>
                                        ))}
                                        {/* Luxury */}
                                        {selectedPlayer.ownedAssetIds.map(id => {
                                            const asset = GAME_ASSETS.find(a => a.id === id);
                                            if(!asset) return null;
                                            return (
                                                <div key={asset.id} className="flex justify-between items-center text-sm py-1 border-b border-slate-200 last:border-0">
                                                    <span className="text-slate-700 font-medium">{asset.name}</span>
                                                    <span className="text-[9px] text-slate-400 font-sans font-bold uppercase">{asset.category}</span>
                                                </div>
                                            );
                                        })}
                                    </>
                                )}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default LeaderboardTab;