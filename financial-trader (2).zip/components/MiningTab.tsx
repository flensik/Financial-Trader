import React, { useState } from 'react';
import { Player, Language } from '../types';
import { GameService } from '../services/gameDb';
import { formatCurrency } from './Formatters';
import { Server, Cpu, Zap, Activity, Plus, Bitcoin, TrendingUp, Info } from 'lucide-react';
import ConfirmationModal from './ConfirmationModal';
import { t } from '../utils/translations';

interface Props {
  player: Player;
  onUpdate: (p: Player) => void;
  christmasVibe?: boolean;
  lang?: Language;
}

const MiningTab: React.FC<Props> = ({ player, onUpdate, christmasVibe = true, lang = 'ru' }) => {
  const farm = player.miningFarm;
  const { btcIncome, energyCost } = GameService.calculateMiningPerformance(player);
  
  const btcInvestment = player.investments.find(i => i.symbol === 'BTC');
  const currentBtcPrice = btcInvestment ? btcInvestment.currentPrice : 40000;
  
  const slotPrice = 25000 * Math.pow(2.2, (farm.maxSlots - 2)); 
  const gpuPrice = 5000 * Math.pow(1.5, farm.gpuCount);
  const upgradePrice = 10000 * Math.pow(3, farm.gpuLevel);

  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    type: 'slot' | 'gpu' | 'upgrade' | null;
  }>({ isOpen: false, type: null });

  const [sellAmount, setSellAmount] = useState<string>('');

  const getTimestamp = () => new Date().toISOString().replace('T', ' ').substring(0, 19);

  const handleBuySlot = () => {
    if (farm.maxSlots >= 10) return; // MAX 10 SLOTS

    if (player.balance >= slotPrice) {
        const logMsg = `[${getTimestamp()}] Майнинг: Расширил ферму до ${farm.maxSlots + 1} слотов за ${formatCurrency(slotPrice)}`;
        onUpdate({
            ...player,
            balance: player.balance - slotPrice,
            miningFarm: { ...farm, maxSlots: farm.maxSlots + 1 },
            logs: [...player.logs, logMsg].slice(-500)
        });
    }
    setConfirmState({ isOpen: false, type: null });
  };

  const handleBuyGpu = () => {
      if (farm.gpuCount < farm.maxSlots && player.balance >= gpuPrice) {
          const logMsg = `[${getTimestamp()}] Майнинг: Купил GPU #${farm.gpuCount + 1} за ${formatCurrency(gpuPrice)}`;
          onUpdate({
              ...player,
              balance: player.balance - gpuPrice,
              miningFarm: { ...farm, gpuCount: farm.gpuCount + 1 },
              logs: [...player.logs, logMsg].slice(-500)
          });
      }
      setConfirmState({ isOpen: false, type: null });
  };

  const handleUpgradeGpu = () => {
      if (player.balance >= upgradePrice) {
          const logMsg = `[${getTimestamp()}] Майнинг: Улучшил Чипы до УР ${farm.gpuLevel + 1} за ${formatCurrency(upgradePrice)}`;
          onUpdate({
              ...player,
              balance: player.balance - upgradePrice,
              miningFarm: { ...farm, gpuLevel: farm.gpuLevel + 1 },
              logs: [...player.logs, logMsg].slice(-500)
          });
      }
      setConfirmState({ isOpen: false, type: null });
  };

  const handleSellCrypto = (all: boolean = false) => {
      let amountToSell = 0;
      if (all) {
          amountToSell = farm.btcBalance;
      } else {
          amountToSell = parseFloat(sellAmount);
      }

      if (isNaN(amountToSell) || amountToSell <= 0 || amountToSell > farm.btcBalance) return;

      const grossProfit = amountToSell * currentBtcPrice;
      let debtToPay = farm.energyDebt;
      
      const netProfit = grossProfit - debtToPay;

      let newBalance = player.balance;
      let newDebt = 0;

      if (netProfit >= 0) {
          newBalance += netProfit;
          newDebt = 0; 
      } else {
          newBalance += netProfit; // Deducts from balance if negative
          newDebt = 0;
      }
      
      const logMsg = `[${getTimestamp()}] Майнинг: Продал ${amountToSell.toFixed(8)} BTC. Прибыль: ${formatCurrency(grossProfit)}. Оплачен долг: ${formatCurrency(debtToPay)}`;

      onUpdate({
          ...player,
          balance: newBalance,
          miningFarm: { 
              ...farm, 
              btcBalance: farm.btcBalance - amountToSell,
              energyDebt: newDebt 
          },
          logs: [...player.logs, logMsg].slice(-500)
      });
      setSellAmount('');
  };

  let confirmTitle = '';
  let confirmMessage = '';
  let confirmAction = () => {};

  if (confirmState.type === 'slot') {
      confirmTitle = 'Купить слот?';
      confirmMessage = `Стоимость расширения стойки: ${formatCurrency(slotPrice)}`;
      confirmAction = handleBuySlot;
  } else if (confirmState.type === 'gpu') {
      confirmTitle = 'Купить видеокарту?';
      confirmMessage = `Стоимость новой GPU: ${formatCurrency(gpuPrice)}`;
      confirmAction = handleBuyGpu;
  } else if (confirmState.type === 'upgrade') {
      confirmTitle = 'Улучшить технологии?';
      confirmMessage = `Стоимость улучшения чипов: ${formatCurrency(upgradePrice)}`;
      confirmAction = handleUpgradeGpu;
  }

  const grossBalanceValue = farm.btcBalance * currentBtcPrice;
  const netBalanceValue = grossBalanceValue - farm.energyDebt;

  return (
    <div className="flex flex-col h-full bg-slate-50 text-slate-800 p-4 font-sans overflow-y-auto pb-24 animate-fade-in relative">
        <ConfirmationModal 
            isOpen={confirmState.isOpen}
            title={confirmTitle}
            message={confirmMessage}
            onConfirm={confirmAction}
            onCancel={() => setConfirmState({ isOpen: false, type: null })}
        />

        <div className="absolute inset-0 z-0 bg-white/50 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-50"></div>
        
        <div className="relative z-10 flex items-center justify-between mb-6 pt-2">
            <div>
                {christmasVibe && (
                    <div className="garland-container justify-start mb-1 scale-75 origin-left -ml-2">
                        <div className="bulb gold"></div>
                        <div className="bulb green"></div>
                        <div className="bulb red"></div>
                        <div className="bulb blue"></div>
                    </div>
                )}
                <h2 className="text-3xl font-black text-slate-800 tracking-tight flex items-center gap-2">
                    <Server className="text-blue-600" />
                    {t('header.mining', lang)}
                </h2>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1 pl-1 flex items-center gap-1">
                    Обновление курса: 30 сек <TrendingUp size={10}/>
                </div>
            </div>
            <div className="bg-white px-3 py-1 rounded-full shadow-sm border border-slate-200 text-xs font-bold text-slate-500">
                Слотов: {farm.gpuCount}/{farm.maxSlots} (Max 10)
            </div>
        </div>

        {/* Wallet Section */}
        <div className="relative z-10 bg-white rounded-2xl p-5 shadow-xl shadow-orange-100/50 border border-orange-100 mb-6">
            <div className="flex justify-between items-start mb-4">
                <div>
                    <div className="text-slate-400 text-xs font-bold uppercase mb-1 flex items-center gap-1">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Bitcoin.svg/200px-Bitcoin.svg.png" alt="BTC" className="w-4 h-4"/> {t('mine.wallet', lang)}
                    </div>
                    <div className="text-3xl font-mono font-bold text-slate-800">
                        {farm.btcBalance.toFixed(8)} <span className="text-sm text-slate-400">BTC</span>
                    </div>
                    <div className="flex flex-col mt-2 gap-1">
                        <div className="text-xs text-green-600 font-bold">
                            {t('mine.mined', lang)}: {formatCurrency(grossBalanceValue)}
                        </div>
                         <div className="text-xs text-red-500 font-bold">
                            {t('mine.debt', lang)}: -{formatCurrency(farm.energyDebt)}
                        </div>
                        <div className="text-sm font-black text-slate-800 border-t border-slate-100 pt-1 mt-1">
                            {t('mine.net', lang)}: {formatCurrency(netBalanceValue)}
                        </div>
                    </div>
                </div>
                <div className="text-right">
                    <div className="bg-orange-50 text-orange-600 px-2 py-1 rounded-lg text-xs font-bold border border-orange-100">
                        1 BTC = {formatCurrency(currentBtcPrice)}
                    </div>
                </div>
            </div>

            <div className="bg-blue-50 p-3 rounded-xl border border-blue-100 mb-3 flex gap-2 items-start">
                 <Info size={16} className="text-blue-500 mt-0.5 flex-shrink-0"/>
                 <p className="text-[10px] text-blue-700 leading-tight">
                    Расходы на электроэнергию теперь зависят только от количества карт. Вывод средств автоматически погашает долг.
                 </p>
            </div>

            <div className="flex gap-2 items-center bg-slate-50 p-2 rounded-xl border border-slate-100">
                <input 
                    type="number" 
                    placeholder="0.00000000" 
                    value={sellAmount}
                    onChange={(e) => setSellAmount(e.target.value)}
                    className="flex-1 bg-transparent text-sm font-bold outline-none px-2 text-slate-700"
                    step="0.00000001"
                />
                <button 
                    onClick={() => handleSellCrypto(false)}
                    className="px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-xs font-bold transition-transform active:scale-95"
                >
                    {t('mine.sell', lang)}
                </button>
                <button 
                    onClick={() => handleSellCrypto(true)}
                    className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-600 rounded-lg text-xs font-bold transition-transform active:scale-95"
                >
                    {t('mine.all', lang)}
                </button>
            </div>
        </div>

        {/* Status Monitor */}
        <div className="relative z-10 grid grid-cols-2 gap-3 mb-6">
            <div className="bg-white border border-slate-100 p-4 rounded-2xl shadow-sm">
                <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-400 uppercase">
                    <Activity size={14} className="text-green-500" /> Hashrate
                </div>
                <div className="text-lg font-bold text-slate-800 break-words leading-tight">
                    {btcIncome.toFixed(8)} <span className="text-xs text-slate-400">btc/s</span>
                </div>
            </div>
            <div className="bg-white border border-slate-100 p-4 rounded-2xl shadow-sm">
                <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-400 uppercase">
                    <Zap size={14} className="text-red-500" /> Energy Cost
                </div>
                <div className="text-lg font-bold text-red-500">-{formatCurrency(energyCost)}<span className="text-xs opacity-70">/s</span></div>
            </div>
        </div>

        {/* Rack */}
        <div className="relative z-10 bg-slate-100 rounded-2xl p-4 mb-6 shadow-inner">
            <div className="flex flex-wrap gap-2 justify-center">
                {Array.from({ length: farm.maxSlots }).map((_, i) => (
                    <div 
                        key={i} 
                        className={`w-12 h-20 rounded-lg flex items-center justify-center relative transition-all duration-500 ${
                            i < farm.gpuCount 
                            ? 'bg-white shadow-md border-b-4 border-green-500' 
                            : 'bg-slate-200 border-2 border-dashed border-slate-300'
                        }`}
                    >
                        {i < farm.gpuCount ? (
                            <div className="flex flex-col items-center">
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500 mb-2 animate-pulse"></div>
                                <Cpu size={20} className="text-slate-700" />
                                <div className="mt-2 w-8 h-1 bg-slate-100 rounded overflow-hidden">
                                     <div className="h-full bg-blue-500 w-[80%]"></div>
                                </div>
                            </div>
                        ) : (
                            <div className="text-slate-400 text-[10px] font-bold">{i+1}</div>
                        )}
                    </div>
                ))}
                
                {farm.maxSlots < 10 && (
                    <button 
                        onClick={() => {
                            if (player.balance < slotPrice) { alert('Недостаточно денег!'); return; }
                            setConfirmState({ isOpen: true, type: 'slot' });
                        }}
                        className="w-12 h-20 rounded-lg border-2 border-dashed border-blue-300 bg-blue-50 flex items-center justify-center hover:bg-blue-100 active:scale-95 transition-all"
                        title="Купить слот"
                    >
                        <Plus size={20} className="text-blue-500"/>
                    </button>
                )}
            </div>
        </div>

        {/* Controls */}
        <div className="relative z-10 space-y-4">
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-slate-800">{t('mine.gpu', lang)}</h3>
                    <p className="text-xs text-slate-400 font-medium">ASIC Miner S{9 + farm.gpuLevel}</p>
                </div>
                <button 
                    onClick={() => {
                        if (farm.gpuCount >= farm.maxSlots) return;
                        if (player.balance < gpuPrice) { alert('Недостаточно денег!'); return; }
                        setConfirmState({ isOpen: true, type: 'gpu' });
                    }}
                    disabled={farm.gpuCount >= farm.maxSlots}
                    className="bg-slate-900 hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-400 text-white px-5 py-2.5 rounded-xl font-bold text-sm transition-all active:scale-95 shadow-lg shadow-slate-200"
                >
                    {formatCurrency(gpuPrice)}
                </button>
            </div>

            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-slate-800">{t('mine.chips', lang)} (Lvl {farm.gpuLevel})</h3>
                    <p className="text-[10px] text-green-600 font-bold bg-green-50 inline-block px-1.5 rounded">Доход +15%</p>
                </div>
                <button 
                    onClick={() => {
                        if (player.balance < upgradePrice) { alert('Недостаточно денег!'); return; }
                        setConfirmState({ isOpen: true, type: 'upgrade' });
                    }}
                    className="bg-blue-600 hover:bg-blue-500 disabled:bg-slate-200 disabled:text-slate-400 text-white px-5 py-2.5 rounded-xl font-bold text-sm transition-all active:scale-95 shadow-lg shadow-blue-200"
                >
                    {formatCurrency(upgradePrice)}
                </button>
            </div>
        </div>
    </div>
  );
};

export default MiningTab;