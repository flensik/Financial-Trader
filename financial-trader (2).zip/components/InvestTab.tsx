import React, { useState, useMemo } from 'react';
import { Player, Investment, Candle, Language } from '../types';
import { formatCurrency } from './Formatters';
import { TrendingUp, TrendingDown, Wallet, LayoutGrid } from 'lucide-react';
import { t } from '../utils/translations';

interface Props {
  player: Player;
  onUpdate: (p: Player) => void;
  lang?: Language;
}

const ASSET_IMAGES: Record<string, string> = {
    'c1': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Bitcoin.svg/200px-Bitcoin.svg.png', // BTC
    'c2': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Ethereum-icon-purple.svg/200px-Ethereum-icon-purple.svg.png', // ETH
    'c3': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Solana_cryptocurrency_two.jpg/200px-Solana_cryptocurrency_two.jpg', // SOL (Alternative)
    's1': 'https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg', // Apple
    's2': 'https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg', // Google
    's3': 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg', // Amazon
    's4': 'https://upload.wikimedia.org/wikipedia/commons/e/e8/Tesla_logo.png', // Tesla
    's5': 'https://upload.wikimedia.org/wikipedia/commons/2/21/Nvidia_logo.svg', // Nvidia
    's6': 'https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg', // Microsoft
    's7': 'https://upload.wikimedia.org/wikipedia/commons/7/7b/Meta_Platforms_Inc._logo.svg', // Meta
    's8': 'https://upload.wikimedia.org/wikipedia/commons/0/08/Netflix_2015_logo.svg', // Netflix
};

// --- Custom SVG Candlestick Chart ---
// Stable, fast, and crash-proof compared to complex library integrations
const SimpleCandleChart = ({ data, height = 120 }: { data: Candle[], height?: number }) => {
    const padding = 5;
    const widthPerCandle = 100 / Math.max(1, data.length);
    
    const { min, max } = useMemo(() => {
        let minVal = Infinity;
        let maxVal = -Infinity;
        data.forEach(d => {
            if (d.low < minVal) minVal = d.low;
            if (d.high > maxVal) maxVal = d.high;
        });
        // Add padding
        const range = maxVal - minVal;
        return { 
            min: minVal - range * 0.05, 
            max: maxVal + range * 0.05 
        };
    }, [data]);

    const getY = (val: number) => {
        const range = max - min;
        if (range === 0) return height / 2;
        // Invert Y because SVG 0 is top
        return height - ((val - min) / range) * height;
    };

    return (
        <div className="w-full h-full bg-slate-900 rounded border border-slate-700 relative overflow-hidden select-none">
             {/* Grid */}
             <div className="absolute inset-0 z-0 opacity-10" 
                  style={{ 
                      backgroundImage: 'linear-gradient(#475569 1px, transparent 1px)', 
                      backgroundSize: '100% 20px' 
                  }}>
             </div>

            <svg width="100%" height="100%" viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" className="relative z-10">
                {data.map((candle, idx) => {
                    const isUp = candle.close >= candle.open;
                    const color = isUp ? '#22c55e' : '#ef4444';
                    
                    const x = idx * widthPerCandle;
                    const candleWidth = widthPerCandle * 0.7; // 70% width, 30% gap
                    const xCenter = x + (widthPerCandle / 2);
                    
                    const yHigh = getY(candle.high);
                    const yLow = getY(candle.low);
                    const yOpen = getY(candle.open);
                    const yClose = getY(candle.close);
                    
                    const bodyTop = Math.min(yOpen, yClose);
                    const bodyHeight = Math.max(1, Math.abs(yOpen - yClose)); // Min 1px
                    
                    return (
                        <g key={idx}>
                            {/* Wick */}
                            <line 
                                x1={`${xCenter}%`} y1={yHigh} 
                                x2={`${xCenter}%`} y2={yLow} 
                                stroke={color} strokeWidth="1" vectorEffect="non-scaling-stroke"
                            />
                            {/* Body */}
                            <rect 
                                x={`${x + (widthPerCandle - candleWidth)/2}%`} 
                                y={bodyTop} 
                                width={`${candleWidth}%`} 
                                height={bodyHeight} 
                                fill={color}
                            />
                        </g>
                    );
                })}
            </svg>
        </div>
    );
};

const AssetCard: React.FC<{ asset: Investment, player: Player, onUpdate: (p: Player) => void, lang: Language }> = ({ asset, player, onUpdate, lang }) => {
    const [amountStr, setAmountStr] = useState('1');
    const isPositive = asset.changePercent >= 0;
    const imgSrc = ASSET_IMAGES[asset.id];

    const getTimestamp = () => new Date().toISOString().replace('T', ' ').substring(0, 19);

    const handleTrade = (action: 'buy' | 'sell') => {
        const amount = parseFloat(amountStr);
        if (isNaN(amount) || amount <= 0) return;

        let logMessage = '';
        
        const updatedInvestments = player.investments.map(inv => {
            if (inv.id === asset.id) {
                if (action === 'buy') {
                    const cost = amount * inv.currentPrice;
                    if (player.balance >= cost) {
                        player.balance -= cost;
                        logMessage = `[${getTimestamp()}] Рынок: Купил ${amount} ${inv.symbol} @ ${formatCurrency(inv.currentPrice)} (Всего: ${formatCurrency(cost)})`;
                        return { ...inv, ownedAmount: inv.ownedAmount + amount };
                    }
                } else if (action === 'sell') {
                    if (inv.ownedAmount >= amount) {
                        const revenue = amount * inv.currentPrice;
                        player.balance += revenue;
                        logMessage = `[${getTimestamp()}] Рынок: Продал ${amount} ${inv.symbol} @ ${formatCurrency(inv.currentPrice)} (Всего: ${formatCurrency(revenue)})`;
                        return { ...inv, ownedAmount: inv.ownedAmount - amount };
                    }
                }
            }
            return inv;
        });

        if (logMessage) {
             onUpdate({ 
                 ...player, 
                 investments: updatedInvestments,
                 logs: [...player.logs, logMessage].slice(-500)
             });
        }
    };

    const handleBuyMax = () => {
        if (asset.currentPrice <= 0) return;
        const maxCanBuy = Math.floor(player.balance / asset.currentPrice);
        if (maxCanBuy > 0) {
            setAmountStr(maxCanBuy.toString());
        }
    };

    return (
        <div className="glass-panel rounded-xl p-3 border border-white hover:bg-white/95 transition-colors shadow-lg">
            <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-slate-100 shadow-sm bg-white p-1 flex items-center justify-center">
                        {imgSrc ? (
                            <img src={imgSrc} alt={asset.symbol} className="w-full h-full object-contain" />
                        ) : (
                            <div className="font-bold text-slate-700 text-xs">
                                {asset.symbol.substring(0,2)}
                            </div>
                        )}
                    </div>
                    <div>
                        <div className="font-bold text-slate-800 text-lg leading-tight">{asset.name}</div>
                        <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wide">
                            {asset.symbol} • Owned: {asset.ownedAmount.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                        </div>
                    </div>
                </div>
                <div className="text-right">
                    <div className="font-bold text-slate-800 font-mono text-lg">{formatCurrency(asset.currentPrice)}</div>
                    <div className={`flex items-center justify-end text-xs font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                        {isPositive ? <TrendingUp size={14} className="mr-1" /> : <TrendingDown size={14} className="mr-1" />}
                        {asset.changePercent > 0 ? '+' : ''}{asset.changePercent.toFixed(2)}%
                    </div>
                </div>
            </div>

            {/* Custom SVG Candlestick Chart */}
            <div className="h-40 w-full mb-4">
                <SimpleCandleChart data={asset.history} height={160} />
            </div>

            <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 bg-slate-50 rounded-lg p-1 border border-slate-200">
                    <span className="text-xs font-bold text-slate-400 pl-2">{t('invest.qty', lang)}:</span>
                    <input 
                        type="number" 
                        min="0.00001" 
                        step="0.00001" 
                        value={amountStr}
                        onChange={(e) => setAmountStr(e.target.value)}
                        className="flex-1 bg-transparent text-sm font-bold text-slate-800 outline-none w-full"
                    />
                    <button onClick={handleBuyMax} className="px-2 py-1 bg-slate-200 text-slate-600 text-[10px] font-bold rounded hover:bg-slate-300 mr-1" title="На всё">
                        MAX
                    </button>
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={() => handleTrade('buy')}
                        className="flex-1 bg-green-600 hover:bg-green-500 py-2 rounded-lg text-sm font-bold text-white transition-all shadow-md shadow-green-200 active:scale-95"
                    >
                        {t('invest.buy', lang)}
                    </button>
                    <button 
                        onClick={() => handleTrade('sell')}
                        disabled={asset.ownedAmount <= 0}
                        className="flex-1 bg-red-600 hover:bg-red-500 disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none py-2 rounded-lg text-sm font-bold text-white transition-all shadow-md shadow-red-200 active:scale-95"
                    >
                        {t('invest.sell', lang)}
                    </button>
                </div>
            </div>
        </div>
    );
};

const InvestTab: React.FC<Props> = ({ player, onUpdate, lang = 'ru' }) => {
  const totalPortfolio = player.investments.reduce((sum, inv) => sum + (inv.ownedAmount * inv.currentPrice), 0);

  return (
    <div className="flex flex-col h-full p-4 overflow-y-auto pb-20 relative animate-fade-in text-slate-800">
       <div 
        className="absolute inset-0 z-0 bg-cover bg-center opacity-80 fixed"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1611974765270-ca12586343bb?q=80&w=2070&auto=format&fit=crop")' }}
      ></div>
      <div className="absolute inset-0 bg-slate-900/60 z-0 fixed"></div>

      <div className="relative z-10">
        <div className="bg-gradient-to-r from-slate-800/90 to-slate-900/90 backdrop-blur-md p-6 rounded-2xl mb-6 shadow-xl text-white border border-white/10">
            <div className="flex items-center gap-3 text-slate-300 mb-1">
                <Wallet size={20} />
                <span className="text-sm font-medium">{t('header.portfolio', lang)}</span>
            </div>
            <div className="text-3xl font-bold font-mono tracking-tight">{formatCurrency(totalPortfolio)}</div>
        </div>

        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2 drop-shadow-md">
            <LayoutGrid className="text-teal-400"/>
            {t('header.trade', lang)}
        </h3>

        <div className="space-y-4">
            {player.investments.map(asset => (
                <AssetCard key={asset.id} asset={asset} player={player} onUpdate={onUpdate} lang={lang} />
            ))}
        </div>
      </div>
    </div>
  );
};

export default InvestTab;
