import React, { useState, useEffect, useRef } from 'react';
import { Player, SupportTicket, AppSettings, TradeRequest, TradeSession, Business, Clan, ClanInvite, ClanRole, ClanMemberData, GameDatabase, GameAsset } from '../types';
import { GameService, hashString, GAME_ASSETS } from '../services/gameDb';
import { t } from '../utils/translations';
import { Settings, Lock, CheckCircle, AlertCircle, Ticket, LogOut, ChevronDown, ChevronUp, PieChart, Briefcase, Coins, MessageSquare, Send, X, Snowflake, Music, Volume2, Disc, User, Radio, ListMusic, Repeat, ArrowRightLeft, Check, Copy, Info, Construction, Globe, Smile, Users, Crown, UserPlus, LogIn, Shield, MicOff, UserX, ChevronRight, Edit2, Plus, Trash2, Eye, Clock } from 'lucide-react';
import { formatCurrency, formatCompact, formatTime } from './Formatters';
import { AVATARS, getAvatarSrc } from '../utils/avatars';

interface Props {
  player: Player;
  onLogout: () => void;
  onUpdate?: (p: Player) => void;
  settings: AppSettings;
  onUpdateSettings: (s: AppSettings) => void;
  christmasVibe: boolean;
  globalConfig: GameDatabase['config']; // Receive config directly from App
}

// Render the special effect around the avatar (Duplicated for standalone usage in Settings)
const TitleEffect: React.FC<{ effectType: GameAsset['effectType'], color: string }> = ({ effectType, color }) => {
    if (!effectType) return null;

    if (effectType === 'orbit') {
        return (
            <div className="absolute inset-[-8px] animate-spin-slow pointer-events-none">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-3 h-3 bg-red-500 rounded-full shadow-[0_0_10px_red]"></div>
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 w-2 h-2 bg-red-400 rounded-full shadow-[0_0_5px_red]"></div>
            </div>
        );
    }
    if (effectType === 'pulse') {
        return (
            <div className="absolute inset-[-4px] rounded-full border-2 animate-pulse opacity-70" style={{ borderColor: color, boxShadow: `0 0 15px ${color}` }}></div>
        );
    }
    if (effectType === 'shine') {
        return (
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/30 to-transparent opacity-50 animate-pulse"></div>
        );
    }
    return null;
};

const SettingsTab: React.FC<Props> = ({ player, onLogout, onUpdate, settings, onUpdateSettings, christmasVibe, globalConfig }) => {
  const [activeSection, setActiveSection] = useState<string | null>('stats');
  const lang = settings.language;
  
  // Profile View State
  const [showProfileModal, setShowProfileModal] = useState(false);

  // Password State
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<{msg: string, type: 'success'|'error'} | null>(null);

  // Promo State
  const [promoCode, setPromoCode] = useState('');
  const [promoStatus, setPromoStatus] = useState<{msg: string, type: 'success'|'error', reward?: number} | null>(null);

  // Clan State
  const [clanNameInput, setClanNameInput] = useState('');
  const [myClan, setMyClan] = useState<Clan | undefined>(undefined);
  const [clanInvites, setClanInvites] = useState<ClanInvite[]>([]);
  const [inviteUsername, setInviteUsername] = useState('');
  const [clanChatMsg, setClanChatMsg] = useState('');
  const [editClanName, setEditClanName] = useState('');
  const [editClanDesc, setEditClanDesc] = useState('');
  const [buySlotsAmount, setBuySlotsAmount] = useState('1');
  const [clanTab, setClanTab] = useState<'chat' | 'members' | 'roles' | 'settings'>('chat');
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);
  const [memberProfile, setMemberProfile] = useState<Player | null>(null);
  const [muteTime, setMuteTime] = useState('5');
  
  // Role Edit State
  const [editingRoleId, setEditingRoleId] = useState<string | null>(null);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleColor, setNewRoleColor] = useState('#000000');
  const [newRolePriority, setNewRolePriority] = useState('0');

  const clanChatEndRef = useRef<HTMLDivElement>(null);

  // Support State
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [activeTicket, setActiveTicket] = useState<SupportTicket | null>(null);
  const [newTicketTitle, setNewTicketTitle] = useState('');
  const [newTicketDesc, setNewTicketDesc] = useState('');
  const [chatMessage, setChatMessage] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
      if (activeSection === 'support') refreshTickets();
      if (activeSection === 'clans') refreshClans();
  }, [activeSection]);

  // Polling for Updates - Optimized to reduce jitter
  useEffect(() => {
      const interval = setInterval(() => {
          if (activeSection === 'support') refreshTickets();
          if (activeSection === 'clans') {
              // Only refresh data, do not reset UI state
              const freshPlayer = GameService.getPlayer(player.id);
              const currentClanId = freshPlayer ? freshPlayer.clanId : player.clanId;
              
              if (currentClanId) {
                  const c = GameService.getClan(currentClanId);
                  // JSON stringify comparison to avoid re-render if data is identical
                  setMyClan(prev => JSON.stringify(prev) !== JSON.stringify(c) ? c : prev);
              } else {
                  setMyClan(undefined);
                  const invites = GameService.getClanInvites(player.id);
                  setClanInvites(prev => JSON.stringify(prev) !== JSON.stringify(invites) ? invites : prev);
              }
          }
      }, 1000); 
      return () => clearInterval(interval);
  }, [activeSection, player.id]);

  const refreshTickets = () => {
      const t = GameService.getTickets(player.id);
      setTickets(prev => JSON.stringify(prev) !== JSON.stringify(t) ? t : prev);
      if (activeTicket) {
          const updated = t.find(tx => tx.id === activeTicket.id);
          if (updated && JSON.stringify(updated) !== JSON.stringify(activeTicket)) setActiveTicket(updated);
      }
  };

  const refreshClans = () => {
      const freshPlayer = GameService.getPlayer(player.id);
      const currentClanId = freshPlayer ? freshPlayer.clanId : player.clanId;

      if (currentClanId) {
          const c = GameService.getClan(currentClanId);
          setMyClan(c);
      } else {
          setMyClan(undefined);
          setClanInvites(GameService.getClanInvites(player.id));
      }
  };

  useEffect(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeTicket?.messages]);

  useEffect(() => {
      clanChatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [myClan?.chatHistory, clanTab]);

  const toggleSection = (id: string) => {
      setActiveSection(activeSection === id ? null : id);
  };

  const handleChangePassword = () => {
    setPasswordStatus(null);
    if (newPassword.length < 4) {
        setPasswordStatus({ msg: 'Пароль слишком короткий', type: 'error' });
        return;
    }
    if (newPassword !== confirmPassword) {
        setPasswordStatus({ msg: 'Пароли не совпадают', type: 'error' });
        return;
    }

    const hash = hashString(newPassword);
    GameService.changePassword(player.id, hash);
    setPasswordStatus({ msg: 'Пароль успешно изменен', type: 'success' });
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleRedeemPromo = () => {
      if(!promoCode.trim()) return;
      const result = GameService.redeemPromoCode(player.id, promoCode.trim());
      if (result.success) {
          setPromoStatus({ msg: result.message, type: 'success', reward: result.reward });
          setPromoCode('');
          if (onUpdate && result.reward) {
              onUpdate({ ...player, balance: player.balance + result.reward });
          }
      } else {
          setPromoStatus({ msg: result.message, type: 'error' });
      }
  };

  const handleSelectAvatar = (avatarId: string) => {
      if (onUpdate) {
          onUpdate({ ...player, avatarId: avatarId });
      }
  };

  const getTitle = (p: Player) => {
      if (p.activeTitleId) {
          const asset = GAME_ASSETS.find(a => a.id === p.activeTitleId);
          if (asset) return asset;
      }
      return null;
  };

  // --- Clan Handlers ---
  const handleCreateClan = () => {
      const res = GameService.createClan(player.id, clanNameInput);
      if (res.success && res.clanId) {
          if (onUpdate) {
              onUpdate({ 
                  ...player, 
                  balance: player.balance - 10000, 
                  clanId: res.clanId 
              });
          }
          setClanNameInput('');
          setTimeout(refreshClans, 100);
      } else {
          alert(res.msg);
      }
  };

  const handleInviteToClan = () => {
      const res = GameService.inviteToClan(player.id, inviteUsername);
      alert(res.msg);
      setInviteUsername('');
  };

  const handleAcceptInvite = (inviteId: string) => {
      const res = GameService.acceptClanInvite(inviteId);
      if (res.success) {
          const updatedPlayer = GameService.getPlayer(player.id);
          if (onUpdate && updatedPlayer) onUpdate(updatedPlayer);
          setTimeout(refreshClans, 100);
      } else {
          alert(res.msg);
      }
  };

  const handleDeclineInvite = (inviteId: string) => {
      GameService.declineClanInvite(inviteId);
      refreshClans();
  };

  const handleClanChatSend = () => {
      if (!clanChatMsg.trim()) return;
      const res = GameService.sendClanMessage(player.id, clanChatMsg);
      if (!res.success && res.msg) {
          alert(res.msg);
      }
      setClanChatMsg('');
  };

  const handleUpdateClanDetails = () => {
      if (!myClan) return;
      const res = GameService.updateClanDetails(player.id, myClan.id, editClanName, editClanDesc);
      if (res.success) {
          if (editClanName && editClanName !== myClan.name && onUpdate) {
              onUpdate({ ...player, balance: player.balance - 1500 });
          }
          alert(res.msg);
          setEditClanName('');
          setEditClanDesc('');
          refreshClans();
      } else {
          alert(res.msg);
      }
  };

  const handleBuySlots = () => {
      const amount = parseInt(buySlotsAmount);
      if (isNaN(amount) || amount < 1) return;
      const res = GameService.buyClanSlots(player.id, amount);
      if (res.success) {
          if (onUpdate) onUpdate({ ...player, balance: player.balance - (amount * 1000) });
          setBuySlotsAmount('1');
          refreshClans();
      }
      alert(res.msg);
  };

  // Member Management
  const handleMemberClick = (memberId: string) => {
      const p = GameService.getPlayer(memberId);
      if (p) {
          setMemberProfile(p);
          setSelectedMemberId(memberId);
      }
  };

  const handleKickMember = () => {
      if (!selectedMemberId) return;
      if (confirm('Выгнать участника?')) {
          const res = GameService.kickClanMember(player.id, selectedMemberId);
          alert(res.msg);
          if (res.success) {
              setSelectedMemberId(null);
              setMemberProfile(null);
              refreshClans();
          }
      }
  };

  const handleMuteMember = () => {
      if (!selectedMemberId) return;
      const mins = parseInt(muteTime) || 5;
      const res = GameService.muteClanMember(player.id, selectedMemberId, mins);
      alert(res.msg);
  };

  const handleAssignRole = (roleId: string) => {
      if (!selectedMemberId) return;
      const res = GameService.assignClanRole(player.id, selectedMemberId, roleId);
      alert(res.msg);
      refreshClans();
  };

  // Role Management
  const handleCreateRole = () => {
      if (!newRoleName) return;
      const res = GameService.createClanRole(player.id, newRoleName, newRoleColor, parseInt(newRolePriority));
      if (res.success) {
          setNewRoleName('');
          refreshClans();
      } else {
          alert(res.msg);
      }
  };

  const handleDeleteRole = (roleId: string) => {
      if (confirm('Удалить роль?')) {
          const res = GameService.deleteClanRole(player.id, roleId);
          if (res.success) refreshClans();
          else alert(res.msg);
      }
  };

  // --- Support Handlers ---
  const handleCreateTicket = () => {
      if (!newTicketTitle.trim() || !newTicketDesc.trim()) return;
      GameService.createTicket(player.id, newTicketTitle, newTicketDesc);
      setNewTicketTitle('');
      setNewTicketDesc('');
      setShowNewTicket(false);
      refreshTickets();
  };

  const handleSendMessage = () => {
      if (!activeTicket || !chatMessage.trim()) return;
      GameService.addMessageToTicket(activeTicket.id, 'user', chatMessage.trim());
      setChatMessage('');
      refreshTickets();
  };

  // Stats
  const businessesOwned = player.businesses.filter(b => b.owned).length;
  const totalInvValue = player.investments.reduce((sum, i) => sum + (i.ownedAmount * i.currentPrice), 0);

  // Render Helpers
  const liquidGlassClass = "bg-white/60 backdrop-blur-xl border border-white/40 shadow-[0_8px_32px_0_rgba(31,38,135,0.07)]";

  return (
    <div className="flex flex-col h-full p-6 animate-fade-in bg-slate-50 text-slate-800 overflow-y-auto pb-20">
       {christmasVibe && (
           <div className="garland-container justify-start mb-2 scale-75 origin-left -ml-2">
               <div className="bulb red"></div>
               <div className="bulb green"></div>
               <div className="bulb gold"></div>
           </div>
       )}
       <h2 className="text-2xl font-bold mb-6 flex items-center gap-2 text-slate-800">
            <User className="text-teal-500" />
            {t('header.profile', lang)}
        </h2>

        {/* --- STATISTICS & AVATAR SECTION --- */}
        <div className="mb-4">
            <button 
                onClick={() => toggleSection('stats')}
                className="w-full flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-blue-100 p-2 rounded-lg text-blue-600"><PieChart size={20}/></div>
                    <span className="font-bold text-slate-700">{t('settings.stats', lang)}</span>
                </div>
                {activeSection === 'stats' ? <ChevronUp size={20} className="text-slate-400"/> : <ChevronDown size={20} className="text-slate-400"/>}
            </button>
            
            {activeSection === 'stats' && (
                <div className="bg-slate-100 p-4 rounded-b-xl border-x border-b border-slate-200 -mt-2 animate-fade-in">
                    {/* ... (Existing Stats UI) ... */}
                    <div className="bg-white p-3 rounded-lg shadow-sm mb-3">
                        <div className="flex justify-between items-center mb-3">
                             <div className="flex items-center gap-3">
                                 <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-slate-200 shadow-sm relative group" onContextMenu={(e) => e.preventDefault()}>
                                     <img src={getAvatarSrc(player.avatarId)} alt="Avatar" className="w-full h-full object-cover pointer-events-none select-none" />
                                 </div>
                                 <div>
                                     <div className="text-[10px] text-slate-400 uppercase font-bold">Логин</div>
                                     <div className="font-bold text-slate-800 text-lg">{player.username}</div>
                                     <button onClick={() => setShowProfileModal(true)} className="flex items-center gap-1 text-[10px] bg-slate-800 text-white px-2 py-1 rounded hover:bg-slate-700 mt-1">
                                         <Eye size={10}/> Просмотр профиля
                                     </button>
                                 </div>
                             </div>
                             <div className="text-right">
                                 <div className="text-[10px] text-slate-400 uppercase font-bold">ID</div>
                                 <div className="font-mono text-xs text-slate-600 bg-slate-50 px-2 py-1 rounded border border-slate-100 flex items-center gap-1">
                                     {player.id} 
                                     <Copy size={10} className="cursor-pointer hover:text-blue-500" onClick={() => navigator.clipboard.writeText(player.id)}/>
                                 </div>
                             </div>
                        </div>

                        {/* Avatar Selector */}
                        <div className="mb-4">
                            <label className="text-xs font-bold text-slate-400 uppercase mb-2 block flex items-center gap-1"><Smile size={12}/> Сменить аватарку</label>
                            <div className="grid grid-cols-4 gap-2">
                                {AVATARS.map(av => (
                                    <button 
                                        key={av.id}
                                        onClick={() => handleSelectAvatar(av.id)}
                                        className={`rounded-lg overflow-hidden border-2 transition-all aspect-square relative ${player.avatarId === av.id ? 'border-blue-500 ring-2 ring-blue-200' : 'border-slate-100 opacity-70 hover:opacity-100'}`}
                                        onContextMenu={(e) => e.preventDefault()}
                                    >
                                        <img src={av.src} alt={av.name} className="w-full h-full object-cover pointer-events-none select-none" title={av.name}/>
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="border-t border-slate-100 pt-2 flex justify-between items-center">
                            <span className="text-xs text-slate-500">{t('settings.regdate', lang)}</span>
                            <span className="text-xs font-bold text-slate-700">{new Date(player.registrationDate).toLocaleDateString()}</span>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <div className="bg-white p-3 rounded-lg shadow-sm">
                            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">{t('settings.maxbal', lang)}</div>
                            <div className="font-mono text-green-600 font-bold">{formatCompact(player.maxMoney || player.balance)}</div>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm">
                            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">{t('settings.bizcount', lang)}</div>
                            <div className="font-bold text-slate-800 flex items-center gap-1">
                                {businessesOwned} <Briefcase size={12} className="text-slate-400"/>
                            </div>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm">
                            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">{t('settings.assets', lang)}</div>
                            <div className="font-mono text-blue-600 font-bold">{formatCompact(totalInvValue)}</div>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm">
                            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">{t('settings.clicks', lang)}</div>
                            <div className="font-bold text-slate-800">{player.clickLevel} LVL</div>
                        </div>
                    </div>
                </div>
            )}
        </div>

        {/* ... (Trade, Clan, Support sections omitted for brevity but remain identical) ... */}
        {/* --- TRADE SECTION --- */}
        <div className="mb-4">
             <button 
                onClick={() => toggleSection('trade')}
                className="w-full flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-green-100 p-2 rounded-lg text-green-600"><ArrowRightLeft size={20}/></div>
                    <span className="font-bold text-slate-700">{t('header.trade', lang)}</span>
                </div>
                {activeSection === 'trade' ? <ChevronUp size={20} className="text-slate-400"/> : <ChevronDown size={20} className="text-slate-400"/>}
            </button>

            {activeSection === 'trade' && (
                <div className="bg-slate-100 p-4 rounded-b-xl border-x border-b border-slate-200 -mt-2 animate-fade-in">
                    <div className="text-center p-6 bg-white rounded-xl border border-slate-200 flex flex-col items-center justify-center">
                        <div className="bg-slate-100 p-3 rounded-full mb-3">
                            <Construction size={24} className="text-slate-400" />
                        </div>
                        <h3 className="font-bold text-slate-700">{t('settings.trade_closed', lang)}</h3>
                        <p className="text-xs text-slate-500 mt-1">{t('settings.tech_works', lang)}</p>
                    </div>
                </div>
            )}
        </div>

        {/* --- CLAN SECTION (LIQUID GLASS STYLE) --- */}
        <div className="mb-4">
            <button 
                onClick={() => toggleSection('clans')}
                className="w-full flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-cyan-100 p-2 rounded-lg text-cyan-600"><Shield size={20}/></div>
                    <span className="font-bold text-slate-700">Кланы</span>
                </div>
                {activeSection === 'clans' ? <ChevronUp size={20} className="text-slate-400"/> : <ChevronDown size={20} className="text-slate-400"/>}
            </button>
            
            {activeSection === 'clans' && (
                <div className="p-2 -mt-2 animate-fade-in relative overflow-hidden rounded-b-3xl">
                    {/* ... (Existing Clan UI Code) ... */}
                    {/* Liquid Glass Background */}
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-white/50 to-purple-50/50 backdrop-blur-3xl z-0"></div>
                    <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-400/20 rounded-full blur-3xl z-0 pointer-events-none"></div>
                    
                    <div className="relative z-10">
                        {!myClan ? (
                            <>
                                <div className={`${liquidGlassClass} p-6 rounded-3xl mb-4 text-center relative overflow-hidden`}>
                                    <h3 className="font-black text-xl text-slate-800 mb-1">Создать Клан</h3>
                                    <p className="text-xs text-slate-500 mb-4 font-medium">Стоимость: {formatCurrency(10000)}</p>
                                    
                                    <div className="flex gap-2">
                                        <input 
                                            type="text" 
                                            placeholder="Название..." 
                                            value={clanNameInput}
                                            onChange={e => setClanNameInput(e.target.value)}
                                            className="flex-1 bg-white/50 border border-white rounded-xl p-3 text-sm text-slate-800 placeholder-slate-400 outline-none focus:ring-2 focus:ring-cyan-200 transition-all"
                                        />
                                        <button 
                                            onClick={handleCreateClan} 
                                            className="bg-slate-900 text-white font-bold px-6 py-2 rounded-xl shadow-lg hover:bg-slate-800 transition-transform active:scale-95"
                                        >
                                            <Plus size={20}/>
                                        </button>
                                    </div>
                                </div>

                                {clanInvites.length > 0 && (
                                    <div className="space-y-2">
                                        <h4 className="text-xs font-bold text-slate-400 uppercase pl-2">Приглашения</h4>
                                        {clanInvites.map(inv => (
                                            <div key={inv.id} className={`${liquidGlassClass} p-4 rounded-2xl flex justify-between items-center`}>
                                                <div>
                                                    <div className="font-bold text-sm text-slate-800">{inv.clanName}</div>
                                                    <div className="text-[10px] text-slate-500">{new Date(inv.timestamp).toLocaleDateString()}</div>
                                                </div>
                                                <div className="flex gap-2">
                                                    <button onClick={() => handleAcceptInvite(inv.id)} className="bg-green-500 text-white p-2 rounded-xl shadow-md hover:bg-green-600 transition-colors"><Check size={16}/></button>
                                                    <button onClick={() => handleDeclineInvite(inv.id)} className="bg-red-500 text-white p-2 rounded-xl shadow-md hover:bg-red-600 transition-colors"><X size={16}/></button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </>
                        ) : (
                            <div className="flex flex-col gap-3">
                                {/* Clan Header */}
                                <div className={`${liquidGlassClass} p-5 rounded-3xl relative overflow-hidden`}>
                                    <div className="absolute top-0 right-0 p-4 opacity-10">
                                        <Shield size={64} />
                                    </div>
                                    <div className="relative z-10">
                                        <h3 className="font-black text-2xl text-slate-900 leading-none mb-1">{myClan.name}</h3>
                                        <p className="text-xs text-slate-500 font-medium mb-3 max-w-[80%] line-clamp-2">{myClan.description}</p>
                                        <div className="flex items-center gap-2">
                                            <span className="text-[10px] bg-white/80 px-2 py-1 rounded-lg border border-white/50 text-slate-600 font-bold shadow-sm">
                                                {myClan.memberIds.length} / {myClan.maxMembers} Members
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                {/* Tabs */}
                                <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
                                    <button onClick={() => setClanTab('chat')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${clanTab === 'chat' ? 'bg-slate-900 text-white shadow-md' : 'bg-white/40 text-slate-600'}`}>Чат</button>
                                    <button onClick={() => setClanTab('members')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${clanTab === 'members' ? 'bg-slate-900 text-white shadow-md' : 'bg-white/40 text-slate-600'}`}>Участники</button>
                                    <button onClick={() => setClanTab('roles')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${clanTab === 'roles' ? 'bg-slate-900 text-white shadow-md' : 'bg-white/40 text-slate-600'}`}>Роли</button>
                                    <button onClick={() => setClanTab('settings')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${clanTab === 'settings' ? 'bg-slate-900 text-white shadow-md' : 'bg-white/40 text-slate-600'}`}>Настройки</button>
                                </div>

                                {/* TAB CONTENT */}
                                <div className={`${liquidGlassClass} p-1 rounded-3xl min-h-[300px] flex flex-col`}>
                                    
                                    {/* CHAT TAB */}
                                    {clanTab === 'chat' && (
                                        <div className="flex flex-col h-[300px]">
                                            <div className="flex-1 overflow-y-auto p-3 space-y-3">
                                                {myClan.chatHistory.map(msg => (
                                                    <div key={msg.id} className={`flex flex-col ${msg.senderId === player.id ? 'items-end' : 'items-start'}`}>
                                                        <div className="flex items-center gap-1.5 mb-0.5">
                                                            {msg.senderId === myClan.leaderId && <Crown size={10} className="text-yellow-500"/>}
                                                            <span className="text-[10px] font-bold text-slate-500" style={{color: msg.roleColor}}>{msg.senderName}</span>
                                                        </div>
                                                        <div className={`px-3 py-2 rounded-2xl text-xs max-w-[85%] break-words shadow-sm ${msg.senderId === player.id ? 'bg-blue-500 text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none'}`}>
                                                            {msg.text}
                                                        </div>
                                                    </div>
                                                ))}
                                                <div ref={clanChatEndRef} />
                                            </div>
                                            <div className="p-2 border-t border-slate-200/50 flex gap-2">
                                                <input 
                                                    className="flex-1 bg-white/60 border-none rounded-xl px-4 py-2 text-sm text-slate-800 outline-none placeholder-slate-400 focus:bg-white transition-all"
                                                    placeholder="Сообщение..."
                                                    value={clanChatMsg}
                                                    onChange={e => setClanChatMsg(e.target.value)}
                                                    onKeyDown={e => e.key === 'Enter' && handleClanChatSend()}
                                                />
                                                <button onClick={handleClanChatSend} className="bg-blue-500 text-white p-2 rounded-xl shadow-md hover:bg-blue-600 transition-transform active:scale-95">
                                                    <Send size={18}/>
                                                </button>
                                            </div>
                                        </div>
                                    )}

                                    {/* MEMBERS TAB */}
                                    {clanTab === 'members' && (
                                        <div className="p-2 space-y-2 h-[300px] overflow-y-auto">
                                            {Object.values(myClan.members).map((m: ClanMemberData) => {
                                                const pRole = myClan.roles.find(r => r.id === m.roleId);
                                                const pData = GameService.getPlayer(m.id); // Sync lookup
                                                return (
                                                    <div key={m.id} className="bg-white/50 p-3 rounded-xl flex justify-between items-center hover:bg-white transition-colors cursor-pointer border border-transparent hover:border-slate-100" onClick={() => handleMemberClick(m.id)}>
                                                        <div className="flex items-center gap-3">
                                                            <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden">
                                                                <img src={getAvatarSrc(pData?.avatarId)} className="w-full h-full object-cover"/>
                                                            </div>
                                                            <div>
                                                                <div className="text-xs font-bold text-slate-800">{pData?.username}</div>
                                                                <div className="text-[10px]" style={{color: pRole?.color || '#94a3b8'}}>{pRole?.name}</div>
                                                            </div>
                                                        </div>
                                                        <ChevronRight size={16} className="text-slate-300"/>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    )}

                                    {/* ROLES TAB (Leader Only) */}
                                    {clanTab === 'roles' && (
                                        <div className="p-3 space-y-3 h-[300px] overflow-y-auto">
                                            {myClan.leaderId === player.id ? (
                                                <>
                                                    <div className="bg-white/50 p-3 rounded-xl border border-white space-y-2">
                                                        <h4 className="text-xs font-bold text-slate-500 uppercase">Создать Роль</h4>
                                                        <div className="flex gap-2">
                                                            <input type="text" placeholder="Название" value={newRoleName} onChange={e => setNewRoleName(e.target.value)} className="flex-1 bg-white p-1.5 rounded-lg text-xs border border-slate-200 outline-none"/>
                                                            <input type="color" value={newRoleColor} onChange={e => setNewRoleColor(e.target.value)} className="w-8 h-8 rounded cursor-pointer border-none bg-transparent"/>
                                                        </div>
                                                        <div className="flex gap-2 items-center">
                                                            <input type="number" placeholder="Приоритет (0-99)" value={newRolePriority} onChange={e => setNewRolePriority(e.target.value)} className="w-20 bg-white p-1.5 rounded-lg text-xs border border-slate-200 outline-none"/>
                                                            <button onClick={handleCreateRole} className="bg-slate-900 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex-1">Создать</button>
                                                        </div>
                                                    </div>
                                                    <div className="space-y-2">
                                                        {myClan.roles.map(r => (
                                                            <div key={r.id} className="bg-white p-2 rounded-xl flex justify-between items-center border border-slate-100">
                                                                <div className="flex items-center gap-2">
                                                                    <div className="w-3 h-3 rounded-full" style={{backgroundColor: r.color}}></div>
                                                                    <span className="text-xs font-bold text-slate-700">{r.name}</span>
                                                                    <span className="text-[9px] bg-slate-100 px-1 rounded text-slate-500">P:{r.priority}</span>
                                                                </div>
                                                                {r.id !== 'leader' && r.id !== 'member' && (
                                                                    <button onClick={() => handleDeleteRole(r.id)} className="text-red-400 hover:text-red-600"><Trash2 size={14}/></button>
                                                                )}
                                                            </div>
                                                        ))}
                                                    </div>
                                                </>
                                            ) : (
                                                <div className="text-center text-slate-400 text-xs py-10">Только лидер может управлять ролями</div>
                                            )}
                                        </div>
                                    )}

                                    {/* SETTINGS TAB */}
                                    {clanTab === 'settings' && (
                                        <div className="p-3 space-y-3 h-[300px] overflow-y-auto">
                                            {myClan.leaderId === player.id ? (
                                                <>
                                                    <div className="bg-white/50 p-3 rounded-xl space-y-2">
                                                        <label className="text-xs font-bold text-slate-500 uppercase">Инфо Клана</label>
                                                        <input type="text" placeholder="Новое название (1500$)" value={editClanName} onChange={e => setEditClanName(e.target.value)} className="w-full bg-white p-2 rounded-lg text-xs border border-slate-200 outline-none"/>
                                                        <input type="text" placeholder="Описание" value={editClanDesc} onChange={e => setEditClanDesc(e.target.value)} className="w-full bg-white p-2 rounded-lg text-xs border border-slate-200 outline-none"/>
                                                        <button onClick={handleUpdateClanDetails} className="w-full bg-blue-500 text-white py-2 rounded-lg text-xs font-bold">Сохранить</button>
                                                    </div>

                                                    <div className="bg-white/50 p-3 rounded-xl space-y-2">
                                                        <label className="text-xs font-bold text-slate-500 uppercase">Управление</label>
                                                        <div className="flex gap-2">
                                                            <input type="text" placeholder="Логин для приглашения" value={inviteUsername} onChange={e => setInviteUsername(e.target.value)} className="flex-1 bg-white p-2 rounded-lg text-xs border border-slate-200 outline-none"/>
                                                            <button onClick={handleInviteToClan} className="bg-green-500 text-white px-3 rounded-lg"><UserPlus size={16}/></button>
                                                        </div>
                                                        <div className="flex gap-2">
                                                            <input type="number" placeholder="Слотов" value={buySlotsAmount} onChange={e => setBuySlotsAmount(e.target.value)} className="flex-1 bg-white p-2 rounded-lg text-xs border border-slate-200 outline-none"/>
                                                            <button onClick={handleBuySlots} className="bg-orange-500 text-white px-3 rounded-lg text-xs font-bold">Купить</button>
                                                        </div>
                                                    </div>
                                                </>
                                            ) : (
                                                <div className="text-center text-slate-400 text-xs py-10">Настройки доступны только лидеру</div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>

        {/* ... (Support Ticket UI - Unchanged) ... */}
        {/* --- SUPPORT SECTION --- */}
        <div className="mb-4">
            <button 
                onClick={() => toggleSection('support')}
                className="w-full flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-purple-100 p-2 rounded-lg text-purple-600"><MessageSquare size={20}/></div>
                    <span className="font-bold text-slate-700">{t('settings.support', lang)}</span>
                </div>
                {activeSection === 'support' ? <ChevronUp size={20} className="text-slate-400"/> : <ChevronDown size={20} className="text-slate-400"/>}
            </button>
            
            {activeSection === 'support' && (
                <div className="bg-slate-100 p-4 rounded-b-xl border-x border-b border-slate-200 -mt-2 animate-fade-in">
                    {!activeTicket && !showNewTicket && (
                        <>
                            <button onClick={() => setShowNewTicket(true)} className="w-full bg-purple-600 text-white py-2 rounded-lg font-bold mb-4 shadow-sm hover:bg-purple-700">
                                + Создать обращение
                            </button>
                            <div className="space-y-2">
                                {tickets.length === 0 && <div className="text-center text-slate-400 py-4 text-xs">Нет обращений</div>}
                                {tickets.map(t => (
                                    <div key={t.id} onClick={() => setActiveTicket(t)} className="bg-white p-3 rounded-lg shadow-sm border border-slate-200 cursor-pointer hover:border-purple-300">
                                        <div className="flex justify-between items-start mb-1">
                                            <span className="font-bold text-sm text-slate-800">{t.title}</span>
                                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                                                t.status === 'resolved' ? 'bg-green-100 text-green-700' :
                                                t.status === 'closed' ? 'bg-slate-200 text-slate-500' :
                                                t.status === 'investigating' ? 'bg-orange-100 text-orange-700' :
                                                'bg-blue-100 text-blue-700'
                                            }`}>
                                                {t.status === 'pending' ? 'На рассмотрении' : 
                                                 t.status === 'investigating' ? 'В работе' : 
                                                 t.status === 'resolved' ? 'Решено' : 'Закрыто'}
                                            </span>
                                        </div>
                                        <p className="text-xs text-slate-500 truncate">{t.description}</p>
                                    </div>
                                ))}
                            </div>
                        </>
                    )}

                    {showNewTicket && (
                        <div className="bg-white p-3 rounded-lg shadow-sm">
                             <h3 className="font-bold text-sm mb-3">Новое обращение</h3>
                             <input 
                                className="w-full border border-slate-600 bg-slate-800 text-white rounded p-2 text-sm mb-2 placeholder-slate-400" 
                                placeholder="Тема вопроса"
                                value={newTicketTitle}
                                onChange={e => setNewTicketTitle(e.target.value)}
                             />
                             <textarea 
                                className="w-full border border-slate-600 bg-slate-800 text-white rounded p-2 text-sm mb-2 h-24 resize-none placeholder-slate-400" 
                                placeholder="Опишите вашу проблему или вопрос..."
                                value={newTicketDesc}
                                onChange={e => setNewTicketDesc(e.target.value)}
                             />
                             <div className="flex gap-2">
                                 <button onClick={() => setShowNewTicket(false)} className="flex-1 bg-slate-200 text-slate-700 py-2 rounded text-sm font-bold">Отмена</button>
                                 <button onClick={handleCreateTicket} className="flex-1 bg-purple-600 text-white py-2 rounded text-sm font-bold">Отправить</button>
                             </div>
                        </div>
                    )}

                    {activeTicket && (
                        <div className="bg-white rounded-lg shadow-sm overflow-hidden flex flex-col h-[400px]">
                            <div className="bg-slate-50 p-3 border-b border-slate-200 flex justify-between items-center">
                                <div className="overflow-hidden">
                                    <h4 className="font-bold text-sm truncate">{activeTicket.title}</h4>
                                    <p className="text-[10px] text-slate-500 truncate">{activeTicket.id}</p>
                                </div>
                                <button onClick={() => setActiveTicket(null)} className="p-1 hover:bg-slate-200 rounded text-slate-600"><X size={16}/></button>
                            </div>
                            
                            <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-slate-50">
                                <div className="bg-purple-50 p-2 rounded-lg border border-purple-100 mb-4">
                                    <p className="text-xs text-purple-900 font-medium">{activeTicket.description}</p>
                                </div>
                                
                                {activeTicket.messages.map(m => (
                                    <div key={m.id} className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}>
                                        <div className={`max-w-[85%] p-2 rounded-lg text-xs ${
                                            m.sender === 'user' 
                                            ? 'bg-blue-500 text-white rounded-br-none' 
                                            : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none'
                                        }`}>
                                            {m.text}
                                        </div>
                                        <span className="text-[9px] text-slate-400 mt-0.5">
                                            {m.sender === 'user' ? 'Вы' : 'Поддержка'} • {new Date(m.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                        </span>
                                    </div>
                                ))}
                                <div ref={chatEndRef} />
                            </div>
                            
                            {activeTicket.status !== 'closed' && (
                                <div className="p-2 border-t border-slate-200 bg-white flex gap-2">
                                    <input 
                                        className="flex-1 bg-slate-100 text-slate-800 border-none rounded-lg px-3 text-sm outline-none"
                                        placeholder="Сообщение..."
                                        value={chatMessage}
                                        onChange={e => setChatMessage(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                                    />
                                    <button onClick={handleSendMessage} className="bg-blue-600 text-white p-2 rounded-lg"><Send size={16}/></button>
                                </div>
                            )}
                            {activeTicket.status === 'closed' && (
                                <div className="p-3 text-center text-xs text-slate-400 font-bold bg-slate-100 border-t border-slate-200">
                                    Тикет закрыт
                                </div>
                            )}
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* ... (Security, Game Settings, Promo, Logout - Same structure as previous, ensure use of new props if needed) ... */}
        {/* --- SECURITY SECTION --- */}
        <div className="mb-4">
            <button 
                onClick={() => toggleSection('security')}
                className="w-full flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-red-100 p-2 rounded-lg text-red-600"><Lock size={20}/></div>
                    <span className="font-bold text-slate-700">{t('settings.security', lang)}</span>
                </div>
                {activeSection === 'security' ? <ChevronUp size={20} className="text-slate-400"/> : <ChevronDown size={20} className="text-slate-400"/>}
            </button>
            
            {activeSection === 'security' && (
                <div className="bg-slate-100 p-4 rounded-b-xl border-x border-b border-slate-200 -mt-2 animate-fade-in space-y-3">
                    <input 
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-3 text-sm outline-none"
                        placeholder="Новый пароль"
                    />
                    <input 
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg p-3 text-sm outline-none"
                        placeholder="Повторите пароль"
                    />
                     {passwordStatus && (
                        <div className={`text-xs p-2 rounded ${passwordStatus.type === 'success' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                            {passwordStatus.msg}
                        </div>
                    )}
                    <button onClick={handleChangePassword} className="w-full bg-slate-800 text-white py-2 rounded-lg font-bold text-sm">
                        Сменить Пароль
                    </button>
                </div>
            )}
        </div>

        {/* --- GAME SETTINGS SECTION --- */}
        <div className="mb-4">
            <button 
                onClick={() => toggleSection('game_settings')}
                className="w-full flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-slate-100 p-2 rounded-lg text-slate-600"><Settings size={20}/></div>
                    <span className="font-bold text-slate-700">{t('settings.gamesettings', lang)}</span>
                </div>
                {activeSection === 'game_settings' ? <ChevronUp size={20} className="text-slate-400"/> : <ChevronDown size={20} className="text-slate-400"/>}
            </button>
            
            {activeSection === 'game_settings' && (
                <div className="bg-slate-100 p-4 rounded-b-xl border-x border-b border-slate-200 -mt-2 animate-fade-in space-y-3">
                    
                    {/* Language Settings */}
                     <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                        <div className="flex items-center gap-2 mb-3">
                             <Globe size={18} className="text-blue-500" />
                             <span className="font-bold text-sm text-slate-800">{t('settings.language', lang)}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                            <button 
                                onClick={() => onUpdateSettings({ ...settings, language: 'ru' })}
                                className={`flex items-center justify-center gap-2 py-2 rounded-lg border text-sm font-bold transition-all ${lang === 'ru' ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                            >
                                <span className="text-lg">🇷🇺</span> Русский
                            </button>
                            <button 
                                onClick={() => onUpdateSettings({ ...settings, language: 'en' })}
                                className={`flex items-center justify-center gap-2 py-2 rounded-lg border text-sm font-bold transition-all ${lang === 'en' ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                            >
                                <span className="text-lg">🇺🇸</span> English
                            </button>
                        </div>
                     </div>

                    {/* Winter Vibe Toggle */}
                    <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="bg-blue-50 p-2 rounded-lg text-blue-500">
                                <Snowflake size={18} />
                            </div>
                            <div>
                                <div className="font-bold text-slate-800 text-sm">Новогодний вайб</div>
                                <div className="text-[10px] text-slate-500">Снег и гирлянды</div>
                            </div>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                checked={settings.showChristmasVibe} 
                                onChange={(e) => onUpdateSettings({ ...settings, showChristmasVibe: e.target.checked })} 
                                className="sr-only peer" 
                            />
                            <div className="w-10 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-500"></div>
                        </label>
                    </div>

                    {/* Music Settings - Using globalConfig from props */}
                    <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-3">
                        <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-3">
                                <div className="bg-red-50 p-2 rounded-lg text-red-500">
                                    <Music size={18} />
                                </div>
                                <div>
                                    <div className="font-bold text-slate-800 text-sm">Музыка</div>
                                    <div className="text-[10px] text-slate-500">
                                        {settings.selectedTrack === 'global' || !settings.selectedTrack 
                                          ? (globalConfig.isMusicEnabled ? 'Эфир: Включен' : 'Эфир: Отключен')
                                          : 'Свой плейлист'}
                                    </div>
                                </div>
                            </div>
                            
                            {/* Master Mute Toggle */}
                            <label className="relative inline-flex items-center cursor-pointer" title="Вкл/Выкл музыку у себя">
                                <input 
                                    type="checkbox" 
                                    checked={settings.enableMusic} 
                                    onChange={(e) => onUpdateSettings({ ...settings, enableMusic: e.target.checked })} 
                                    className="sr-only peer" 
                                />
                                <div className="w-10 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-500"></div>
                            </label>
                        </div>
                        
                        {/* Source Selector & Volume */}
                        {settings.enableMusic && (
                            <div className="border-t border-slate-100 pt-3 mt-1 space-y-3 animate-fade-in">
                                
                                {/* Track Source Selector */}
                                <div className="space-y-2">
                                    <label className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1">
                                        <ListMusic size={12}/> Источник
                                    </label>
                                    <div className="grid grid-cols-1 gap-2">
                                        <button 
                                            onClick={() => onUpdateSettings({ ...settings, selectedTrack: 'global' })}
                                            className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-bold transition-all ${
                                                !settings.selectedTrack || settings.selectedTrack === 'global'
                                                ? 'bg-blue-50 border-blue-200 text-blue-700'
                                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                            }`}
                                        >
                                            <Radio size={14} className={!settings.selectedTrack || settings.selectedTrack === 'global' ? 'text-blue-500' : 'text-slate-400'}/>
                                            <div className="flex-1 text-left">
                                                Глобальное Радио 
                                                <span className="opacity-60 font-normal ml-1">
                                                    (DJ: {globalConfig.activeTrack.charAt(0).toUpperCase() + globalConfig.activeTrack.slice(1)})
                                                </span>
                                            </div>
                                            {!globalConfig.isMusicEnabled && <span className="text-[9px] bg-red-100 text-red-600 px-1 rounded">OFFAIR</span>}
                                        </button>

                                        <button 
                                            onClick={() => onUpdateSettings({ ...settings, selectedTrack: 'tropical' })}
                                            className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-bold transition-all ${
                                                settings.selectedTrack === 'tropical'
                                                ? 'bg-orange-50 border-orange-200 text-orange-700'
                                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                            }`}
                                        >
                                            <Disc size={14} className={settings.selectedTrack === 'tropical' ? 'text-orange-500' : 'text-slate-400'}/>
                                            <div className="flex-1 text-left">Tropical Soul</div>
                                        </button>

                                        <button 
                                            onClick={() => onUpdateSettings({ ...settings, selectedTrack: 'sneaky' })}
                                            className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-bold transition-all ${
                                                settings.selectedTrack === 'sneaky'
                                                ? 'bg-purple-50 border-purple-200 text-purple-700'
                                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                            }`}
                                        >
                                            <Disc size={14} className={settings.selectedTrack === 'sneaky' ? 'text-purple-500' : 'text-slate-400'}/>
                                            <div className="flex-1 text-left">Sneaky Snitch</div>
                                        </button>

                                        <button 
                                            onClick={() => onUpdateSettings({ ...settings, selectedTrack: 'ohnonono' })}
                                            className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-bold transition-all ${
                                                settings.selectedTrack === 'ohnonono'
                                                ? 'bg-pink-50 border-pink-200 text-pink-700'
                                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                            }`}
                                        >
                                            <Disc size={14} className={settings.selectedTrack === 'ohnonono' ? 'text-pink-500' : 'text-slate-400'}/>
                                            <div className="flex-1 text-left">OH NO NO NO FUNK</div>
                                        </button>

                                        <button 
                                            onClick={() => onUpdateSettings({ ...settings, selectedTrack: 'babylaugh' })}
                                            className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-bold transition-all ${
                                                settings.selectedTrack === 'babylaugh'
                                                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                                                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                            }`}
                                        >
                                            <Disc size={14} className={settings.selectedTrack === 'babylaugh' ? 'text-indigo-500' : 'text-slate-400'}/>
                                            <div className="flex-1 text-left">BABY LAUGH FUNK</div>
                                        </button>
                                        
                                        {/* Custom Tracks from DB - Filtered */}
                                        {globalConfig.customTracks?.filter(t => !t.isHidden).map(track => (
                                            <button 
                                                key={track.id}
                                                onClick={() => onUpdateSettings({ ...settings, selectedTrack: track.id })}
                                                className={`flex items-center gap-2 p-2 rounded-lg border text-xs font-bold transition-all ${
                                                    settings.selectedTrack === track.id
                                                    ? 'bg-purple-50 border-purple-200 text-purple-700'
                                                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                                                }`}
                                            >
                                                <Disc size={14} className={settings.selectedTrack === track.id ? 'text-purple-500' : 'text-slate-400'}/>
                                                <div className="flex-1 text-left truncate">{track.name}</div>
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                {/* Volume Slider */}
                                <div className="flex items-center gap-3 pt-2">
                                    <Volume2 size={16} className="text-slate-400" />
                                    <input 
                                        type="range" 
                                        min="0" 
                                        max="1" 
                                        step="0.05"
                                        value={settings.musicVolume} 
                                        onChange={(e) => onUpdateSettings({ ...settings, musicVolume: parseFloat(e.target.value) })}
                                        className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-red-500"
                                    />
                                    <span className="text-xs font-bold text-slate-400 w-8 text-right">
                                        {(settings.musicVolume * 100).toFixed(0)}%
                                    </span>
                                </div>
                            </div>
                        )}
                    </div>

                </div>
            )}
        </div>

        {/* --- PROMO SECTION --- */}
        <div className="mb-8">
            <button 
                onClick={() => toggleSection('promo')}
                className="w-full flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm"
            >
                <div className="flex items-center gap-3">
                    <div className="bg-yellow-100 p-2 rounded-lg text-yellow-600"><Ticket size={20}/></div>
                    <span className="font-bold text-slate-700">{t('settings.promo', lang)}</span>
                </div>
                {activeSection === 'promo' ? <ChevronUp size={20} className="text-slate-400"/> : <ChevronDown size={20} className="text-slate-400"/>}
            </button>
            
            {activeSection === 'promo' && (
                <div className="bg-slate-100 p-4 rounded-b-xl border-x border-b border-slate-200 -mt-2 animate-fade-in">
                    <div className="flex gap-2">
                        <input 
                            type="text" 
                            value={promoCode}
                            onChange={e => setPromoCode(e.target.value)}
                            placeholder="Введите код"
                            className="flex-1 bg-white border border-slate-200 rounded-lg p-3 text-slate-800 outline-none"
                        />
                        <button onClick={handleRedeemPromo} className="bg-teal-600 text-white px-4 rounded-lg font-bold">OK</button>
                    </div>
                    {promoStatus && (
                        <div className={`mt-3 text-sm flex items-center gap-2 p-3 rounded-lg font-medium animate-fade-in ${promoStatus.type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'}`}>
                            {promoStatus.type === 'success' ? <CheckCircle size={16}/> : <AlertCircle size={16}/>}
                            {promoStatus.msg} {promoStatus.reward && <b>(+${promoStatus.reward})</b>}
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* Logout Section */}
        <button 
            onClick={onLogout}
            className="mt-auto w-full bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 font-bold py-3 rounded-lg transition-all flex items-center justify-center gap-2"
        >
            <LogOut size={18} />
            {t('settings.logout', lang)}
        </button>

        {/* --- Profile View Modal --- */}
        {showProfileModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in font-sans" onClick={() => setShowProfileModal(false)}>
                <div className="bg-white w-full max-w-sm rounded-none shadow-2xl relative overflow-hidden" onClick={e => e.stopPropagation()}>
                    
                    {/* Magazine Cover Header */}
                    <div className="h-32 bg-slate-900 relative">
                        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                        <button onClick={() => setShowProfileModal(false)} className="absolute top-4 right-4 text-white hover:text-red-500 bg-white/10 rounded-full p-2 transition-colors z-20">
                            <X size={20} />
                        </button>
                        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
                    </div>

                    <div className="px-6 relative pb-8 -mt-12">
                        {/* Avatar */}
                        <div className="flex justify-center mb-4 relative">
                            <div className="w-28 h-28 relative">
                                <div className="w-full h-full rounded-full border-4 border-white bg-slate-200 shadow-xl overflow-hidden relative z-10">
                                    <img src={getAvatarSrc(player.avatarId)} className="w-full h-full object-cover" />
                                </div>
                                {getTitle(player) && (
                                    <TitleEffect effectType={getTitle(player)?.effectType} color={getTitle(player)?.titleColor || '#fbbf24'} />
                                )}
                            </div>
                        </div>

                        <div className="text-center mb-6">
                            <h3 className="text-3xl font-serif font-black text-slate-900 mb-1">{player.username}</h3>
                            <div className="text-xs text-slate-400 font-mono uppercase tracking-widest mb-3">ID: {player.id}</div>
                            {getTitle(player) && (
                                <span className="px-3 py-1 bg-slate-900 text-white text-xs font-bold uppercase tracking-widest inline-block" style={{ backgroundColor: getTitle(player)?.titleColor }}>
                                    {getTitle(player)?.name}
                                </span>
                            )}
                        </div>

                        <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="border-t-2 border-black pt-2">
                                <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-1">Cash & Liquid</div>
                                <div className="text-green-700 font-mono font-bold text-xl">{formatCompact(player.balance)}</div>
                            </div>
                            <div className="border-t-2 border-slate-200 pt-2">
                                <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-1">Experience</div>
                                <div className="text-slate-900 font-bold flex items-center gap-1">
                                    <Clock size={16} className="text-slate-400"/> {formatTime(player.playtime || 0)}
                                </div>
                            </div>
                        </div>

                        {/* Assets Showcase */}
                        <div className="bg-slate-50 p-4 border border-slate-100">
                            <h4 className="text-xs font-black text-slate-900 uppercase mb-3 flex items-center gap-2 border-b border-slate-200 pb-2">
                                <Briefcase size={14} /> Key Assets
                            </h4>
                            
                            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                                {player.businesses.filter(b => b.owned).length === 0 && player.ownedAssetIds.length === 0 ? (
                                    <div className="text-slate-400 text-xs italic text-center py-4">No major assets reported.</div>
                                ) : (
                                    <>
                                        {/* Shops */}
                                        {player.businesses.filter(b => b.owned).map(b => (
                                            <div key={b.id} className="flex justify-between items-center text-sm py-1 border-b border-slate-200 last:border-0">
                                                <span className="text-slate-700 font-serif font-bold">{b.customName || b.name}</span>
                                                <span className="text-[9px] text-slate-500 font-sans font-bold uppercase">Lvl {b.level}</span>
                                            </div>
                                        ))}
                                        {/* Luxury */}
                                        {player.ownedAssetIds.map(id => {
                                            const asset = GAME_ASSETS.find(a => a.id === id);
                                            if(!asset) return null;
                                            return (
                                                <div key={asset.id} className="flex justify-between items-center text-sm py-1 border-b border-slate-200 last:border-0">
                                                    <span className="text-slate-700 font-medium">{asset.name}</span>
                                                    <span className="text-[9px] text-slate-400 font-sans font-bold uppercase">{asset.category}</span>
                                                </div>
                                            );
                                        })}
                                    </>
                                )}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default SettingsTab;