
import { Language } from '../types';

type TranslationKeys = {
    [key: string]: {
        ru: string;
        en: string;
    }
};

export const dict: TranslationKeys = {
    // Navigation
    'nav.tap': { ru: 'Тап', en: 'Tap' },
    'nav.business': { ru: 'Бизнес', en: 'Business' },
    'nav.farm': { ru: 'Ферма', en: 'Farm' },
    'nav.market': { ru: 'Рынок', en: 'Market' },
    'nav.shop': { ru: 'Магазин', en: 'Shop' }, 
    'nav.top': { ru: 'Топ', en: 'Top' },
    'nav.admin': { ru: 'Админ', en: 'Admin' },
    'nav.menu': { ru: 'Меню', en: 'Menu' },
    'nav.profile': { ru: 'Профиль', en: 'Profile' },

    // Headers
    'header.main': { ru: 'Главная', en: 'Dashboard' },
    'header.business': { ru: 'Бизнесы', en: 'Businesses' },
    'header.assets': { ru: 'Магазин', en: 'Shop' },
    'header.mining': { ru: 'Майнинг BTC', en: 'BTC Mining' },
    'header.portfolio': { ru: 'Портфель', en: 'Portfolio' },
    'header.trade': { ru: 'Торговля (Обновление 30с)', en: 'Trading (Updates 30s)' },
    'header.leaderboard': { ru: 'Топ Игроков', en: 'Leaderboard' },
    'header.profile': { ru: 'Профиль', en: 'Profile' },

    // Clicker
    'clicker.balance': { ru: 'Общий Баланс', en: 'Total Balance' },
    'clicker.income': { ru: 'Доход в час', en: 'Income / hr' },
    'clicker.level': { ru: 'Уровень', en: 'Level' },
    'clicker.taphere': { ru: 'Tap here', en: 'Tap here' },
    'clicker.bank': { ru: 'Швейцарский Банк', en: 'Swiss Bank' },

    // Business
    'biz.tax': { ru: 'Налог', en: 'Tax' },
    'biz.buy': { ru: 'Купить Бизнес', en: 'Buy Business' },
    'biz.upgrade': { ru: 'Улучшить', en: 'Upgrade' },
    'biz.owned': { ru: 'OWNED', en: 'OWNED' },
    'biz.income': { ru: '/s', en: '/s' },

    // Mining
    'mine.wallet': { ru: 'Bitcoin Wallet', en: 'Bitcoin Wallet' },
    'mine.mined': { ru: 'Намайнено', en: 'Mined' },
    'mine.debt': { ru: 'Долг за свет', en: 'Energy Debt' },
    'mine.net': { ru: 'Чистая прибыль', en: 'Net Profit' },
    'mine.sell': { ru: 'Продать', en: 'Sell' },
    'mine.all': { ru: 'Всё', en: 'All' },
    'mine.gpu': { ru: 'Видеокарта', en: 'Graphics Card' },
    'mine.chips': { ru: 'Чипы', en: 'Chips' },

    // Invest
    'invest.buy': { ru: 'Купить', en: 'Buy' },
    'invest.sell': { ru: 'Продать', en: 'Sell' },
    'invest.qty': { ru: 'Кол-во', en: 'Qty' },

    // Leaderboard
    'leader.balance': { ru: 'Лидеры по балансу', en: 'Balance Leaders' },
    'leader.assets': { ru: 'Лидеры по активам', en: 'Asset Leaders' },
    'leader.empty': { ru: 'Список пуст', en: 'List is empty' },

    // Settings / Profile
    'settings.stats': { ru: 'Статистика', en: 'Statistics' },
    'settings.regdate': { ru: 'Дата регистрации', en: 'Registration Date' },
    'settings.maxbal': { ru: 'Макс. Баланс', en: 'Max Balance' },
    'settings.bizcount': { ru: 'Бизнесов', en: 'Businesses' },
    'settings.assets': { ru: 'Активы', en: 'Assets' },
    'settings.clicks': { ru: 'Клики', en: 'Clicks' },
    'settings.support': { ru: 'Поддержка', en: 'Support' },
    'settings.security': { ru: 'Безопасность', en: 'Security' },
    'settings.gamesettings': { ru: 'Настройки игры', en: 'Game Settings' },
    'settings.logout': { ru: 'Выйти из аккаунта', en: 'Log Out' },
    'settings.promo': { ru: 'Промокоды', en: 'Promo Codes' },
    'settings.language': { ru: 'Язык', en: 'Language' },
    'settings.trade_closed': { ru: 'Трейды временно закрыты', en: 'Trades temporarily closed' },
    'settings.tech_works': { ru: 'Ведутся технические работы', en: 'Maintenance in progress' },
};

export const t = (key: string, lang: Language | string = 'ru'): string => {
    const safeLang = (lang === 'en' || lang === 'ru') ? (lang as Language) : 'ru';
    return dict[key]?.[safeLang] || key;
};
