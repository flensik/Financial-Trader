
export interface AvatarItem {
    id: string;
    name: string;
    src: string;
}

// Ссылки обновлены. 
// Примечание: Для корректного отображения нужны прямые ссылки на изображения (обычно заканчиваются на .jpg/.png).
// Ссылки вида ibb.co/XYZ - это веб-страницы. Если картинки не грузятся, замените их на прямые ссылки (Direct Link).
export const AVATARS: AvatarItem[] = [
    { 
        id: 'red_guy', 
        name: 'Извините', 
        src: 'https://i.ibb.co/CK4svrMv/image.jpg' // Попытка использовать прямую структуру, если не сработает - верните исходную ссылку на страницу
    },
    { 
        id: 'blue_bird', 
        name: 'Вряд-ли', 
        src: 'https://i.ibb.co/svsmHkkc/image.jpg'
    },
    { 
        id: 'golden_brain', 
        name: 'Brain', 
        src: 'https://i.ibb.co/nqbptWXj/image.jpg'
    },
    { 
        id: 'among_us', 
        name: 'Among Us', 
        src: 'https://i.ibb.co/fVt5ppCr/image.jpg'
    },
    { 
        id: 'temshik', 
        name: 'Temshik', 
        src: 'https://i.ibb.co/HDPdJV9z/image.jpg'
    },
    { 
        id: 'slippers', 
        name: 'Тiпiчкi', 
        src: 'https://i.ibb.co/ns2VfHN7/image.jpg'
    },
    { 
        id: 'bald_guy', 
        name: 'Привет', 
        src: 'https://i.ibb.co/cKqLnyjd/image.jpg'
    },
    { 
        id: 'vdv_cat', 
        name: 'ВДВ Котан', 
        src: 'https://i.ibb.co/RkD0vbF1/image.jpg'
    },
    {
        id: 'default',
        name: 'Default',
        src: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'
    }
];

export const getAvatarSrc = (id?: string): string => {
    // Fallback logic inside component usually, but here helps consistency
    if (!id) return AVATARS.find(a => a.id === 'default')!.src;
    
    // Try to find exact match
    const found = AVATARS.find(a => a.id === id);
    if (found) return found.src;

    // If using the raw link provided in prompt directly as ID (legacy/custom check)
    if (id.startsWith('http')) return id;

    return AVATARS.find(a => a.id === 'default')!.src;
};
