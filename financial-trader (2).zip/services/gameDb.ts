import { Player, GameDatabase, Business, Investment, PromoCode, MiningFarm, Candle, SupportTicket, TicketStatus, ChatMessage, TradeRequest, TradeSession, TradeOffer, Clan, ClanInvite, ClanMessage, ClanRole, ClanMemberData, GameAsset } from '../types';
import { formatCurrency } from '../components/Formatters'; // Importing formatter for logs

const DB_KEY = 'financial_trader_db_v13'; // Bumped DB key for Music Config
const SESSION_KEY = 'financial_trader_session';
const DEVICE_IP_KEY = 'financial_trader_device_ip'; // Stores the simulated "Real IP" of this browser

// --- GAME ASSETS DATABASE (STATIC) ---
// IMAGES UPDATED TO DIRECT HIGH QUALITY UNSPLASH PHOTOS
export const GAME_ASSETS: GameAsset[] = [
    // --- REAL ESTATE ---
    {
        id: 'prop_garage',
        name: 'Гараж',
        category: 'property',
        price: 15000,
        image: 'https://images.unsplash.com/photo-1534567228790-27a942eb9b30?q=80&w=1000&auto=format&fit=crop',
        description: 'Старый гараж на окраине города. Пахнет маслом и бензином.'
    },
    {
        id: 'prop_container',
        name: 'Жилой Контейнер',
        category: 'property',
        price: 45000,
        image: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?q=80&w=1000&auto=format&fit=crop',
        description: 'Модно, молодежно, дешево. Экологичный выбор.'
    },
    {
        id: 'prop_apt_small',
        name: 'Студия',
        category: 'property',
        price: 120000,
        image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?q=80&w=1000&auto=format&fit=crop',
        description: 'Уютная студия 20кв.м. в спальном районе.'
    },
    {
        id: 'prop_apt_lux',
        name: 'Апартаменты в Сити',
        category: 'property',
        price: 850000,
        image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1000&auto=format&fit=crop',
        description: 'Панорамные окна, консьерж и вид на успех.'
    },
    {
        id: 'prop_house_suburb',
        name: 'Дом в пригороде',
        category: 'property',
        price: 1500000,
        image: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=1000&auto=format&fit=crop',
        description: 'Зеленый газон, белый забор, идеальные соседи.'
    },
    {
        id: 'prop_hangar',
        name: 'Частный Ангар',
        category: 'property',
        price: 2500000,
        image: 'https://images.unsplash.com/photo-1533068994695-452297e5d6dd?q=80&w=1000&auto=format&fit=crop',
        description: 'Просторный дом для вашей авиации и техники.'
    },
    {
        id: 'prop_villa',
        name: 'Вилла в Испании',
        category: 'property',
        price: 5000000,
        image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=1000&auto=format&fit=crop',
        description: 'Бассейн, пальмы и вечное солнце.'
    },
    {
        id: 'prop_wharf',
        name: 'Частный Причал',
        category: 'property',
        price: 8000000,
        image: 'https://images.unsplash.com/photo-1605218427368-35b81a3dd31c?q=80&w=1000&auto=format&fit=crop',
        description: 'Личная парковка для супер-яхты на Лазурном берегу.'
    },
    {
        id: 'prop_mansion',
        name: 'Поместье в LA',
        category: 'property',
        price: 25000000,
        image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=1000&auto=format&fit=crop',
        description: 'Кинотеатр, спортзал, 15 спален и охрана.'
    },
    {
        id: 'prop_island',
        name: 'Частный Остров',
        category: 'property',
        price: 150000000,
        image: 'https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?q=80&w=1000&auto=format&fit=crop',
        description: 'Ваше собственное государство посреди океана.'
    },

    // --- TRANSPORT (Land) ---
    {
        id: 'veh_bike',
        name: 'BMX',
        category: 'transport',
        subCategory: 'land',
        price: 500,
        image: 'https://images.unsplash.com/photo-1545065436-1234d3527232?q=80&w=1000&auto=format&fit=crop',
        description: 'Два колеса, одна скорость, полная свобода.'
    },
    {
        id: 'veh_civic',
        name: 'JDM Legend',
        category: 'transport',
        subCategory: 'land',
        price: 15000,
        image: 'https://images.unsplash.com/photo-1533473359331-0135ef1bcfb0?q=80&w=1000&auto=format&fit=crop',
        description: 'Легендарный японский седан для тюнинга.'
    },
    {
        id: 'veh_mustang',
        name: 'Muscle Car',
        category: 'transport',
        subCategory: 'land',
        price: 45000,
        image: 'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?q=80&w=1000&auto=format&fit=crop',
        description: 'Классическая американская мощь и рев мотора.'
    },
    {
        id: 'veh_gclass',
        name: 'G-Wagon',
        category: 'transport',
        subCategory: 'land',
        price: 180000,
        image: 'https://images.unsplash.com/photo-1520050206274-28438430ec24?q=80&w=1000&auto=format&fit=crop',
        description: 'Квадратиш. Практиш. Гут. Черный гелик.'
    },
    {
        id: 'veh_ferrari',
        name: 'Ferrari 488',
        category: 'transport',
        subCategory: 'land',
        price: 350000,
        image: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?q=80&w=1000&auto=format&fit=crop',
        description: 'Итальянская страсть в красном цвете.'
    },
    {
        id: 'veh_rolls',
        name: 'Rolls-Royce',
        category: 'transport',
        subCategory: 'land',
        price: 600000,
        image: 'https://images.unsplash.com/photo-1631295868223-63265b40d9e4?q=80&w=1000&auto=format&fit=crop',
        description: 'Вершина автомобильного комфорта и статуса.'
    },
    {
        id: 'veh_bugatti',
        name: 'Bugatti Chiron',
        category: 'transport',
        subCategory: 'land',
        price: 3500000,
        image: 'https://images.unsplash.com/photo-1566008885218-90abf9200ddb?q=80&w=1000&auto=format&fit=crop',
        description: 'Гиперкар, быстрее которого только ракета.'
    },

    // --- TRANSPORT (Water) ---
    {
        id: 'veh_jetski',
        name: 'Гидроцикл',
        category: 'transport',
        subCategory: 'water',
        price: 12000,
        image: 'https://images.unsplash.com/photo-1574621100236-d25a64a169f5?q=80&w=1000&auto=format&fit=crop',
        description: 'Для адреналина и веселья на пляже.'
    },
    {
        id: 'veh_boat',
        name: 'Спорт-Катер',
        category: 'transport',
        subCategory: 'water',
        price: 85000,
        image: 'https://images.unsplash.com/photo-1564182842519-8a3b2af3e228?q=80&w=1000&auto=format&fit=crop',
        description: 'Скоростные прогулки по волнам.'
    },
    {
        id: 'veh_yacht_s',
        name: 'Яхта Azimut',
        category: 'transport',
        subCategory: 'water',
        price: 1500000,
        image: 'https://images.unsplash.com/photo-1569263979104-865ab7cd8d13?q=80&w=1000&auto=format&fit=crop',
        description: 'Идеальна для вечеринок в открытом море.'
    },
    {
        id: 'veh_yacht_xl',
        name: 'Мега-Яхта "Eclipse"',
        category: 'transport',
        subCategory: 'water',
        price: 50000000,
        image: 'https://images.unsplash.com/photo-1605281317010-fe5ffe79ba02?q=80&w=1000&auto=format&fit=crop',
        description: 'Плавучий дворец с вертолетной площадкой.'
    },

    // --- TRANSPORT (Air) ---
    {
        id: 'veh_cessna',
        name: 'Cessna 172',
        category: 'transport',
        subCategory: 'air',
        price: 150000,
        image: 'https://images.unsplash.com/photo-1559627755-42217e4f1a25?q=80&w=1000&auto=format&fit=crop',
        description: 'Классика малой авиации для личных полетов.'
    },
    {
        id: 'veh_heli',
        name: 'Вертолет R44',
        category: 'transport',
        subCategory: 'air',
        price: 450000,
        image: 'https://images.unsplash.com/photo-1540962351504-03099e0a754b?q=80&w=1000&auto=format&fit=crop',
        description: 'Ваше личное воздушное такси без пробок.'
    },
    {
        id: 'veh_jet_lear',
        name: 'Learjet 75',
        category: 'transport',
        subCategory: 'air',
        price: 13000000,
        image: 'https://images.unsplash.com/photo-1583070161414-03732d80d226?q=80&w=1000&auto=format&fit=crop',
        description: 'Бизнес-поездки со скоростью звука.'
    },
    {
        id: 'veh_g650',
        name: 'Gulfstream G650',
        category: 'transport',
        subCategory: 'air',
        price: 65000000,
        image: 'https://images.unsplash.com/photo-1570697992928-193a0279a63c?q=80&w=1000&auto=format&fit=crop',
        description: 'Золотой стандарт мировой бизнес-авиации.'
    },

    // --- LUXURY ---
    {
        id: 'lux_rolex',
        name: 'Rolex Submariner',
        category: 'luxury',
        subCategory: 'watch',
        price: 15000,
        image: 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?q=80&w=1000&auto=format&fit=crop',
        description: 'Культовые дайверские часы. Статус на запястье.'
    },
    {
        id: 'lux_patek',
        name: 'Patek Philippe',
        category: 'luxury',
        subCategory: 'watch',
        price: 120000,
        image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?q=80&w=1000&auto=format&fit=crop',
        description: 'Вы не владеете ими, вы храните их для потомков.'
    },
    {
        id: 'lux_diamond',
        name: 'Розовый Бриллиант',
        category: 'luxury',
        subCategory: 'jewelry',
        price: 3000000,
        image: 'https://images.unsplash.com/photo-1615655406736-b37c4fabf923?q=80&w=1000&auto=format&fit=crop',
        description: 'Редчайший драгоценный камень планеты.'
    },
    {
        id: 'lux_egg',
        name: 'Искусство Фаберже',
        category: 'luxury',
        subCategory: 'art',
        price: 10000000,
        image: 'https://images.unsplash.com/photo-1588611832264-77a8360cb5c6?q=80&w=1000&auto=format&fit=crop',
        description: 'Императорская роскошь и история.'
    },

    // --- NFT ---
    {
        id: 'nft_punk',
        name: 'CryptoPunk #3100',
        category: 'nft',
        price: 500000,
        image: 'https://i.seadn.io/gae/BdxvLseXcfl57BiuQcQYdJ64v-aI8din7WPk0Pgo3qQFhAUH-B6i-dCqqc_mCkRIzULmwzwecnohLhrcH8A9mpWIZqA7ygc52Sr81hE?auto=format&dpr=1&w=1000',
        description: 'Легендарный пиксельный панк.'
    },
    {
        id: 'nft_ape',
        name: 'Bored Ape Yacht Club',
        category: 'nft',
        price: 1200000,
        image: 'https://i.seadn.io/gae/Ju9CkWtV-1Okvf45wo8UctR-M9He2PjILP0oOvxE89AyiPPGtrR3gysu1Zgy0hjd2xKIgjJJtWIc0ybj4Vd7wv8t3pxDGHoJBzDB?auto=format&dpr=1&w=1000',
        description: 'Скучающая обезьяна, которая стоит состояние.'
    },
    {
        id: 'nft_rock',
        name: 'EtherRock',
        category: 'nft',
        price: 2500000,
        image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/EtherRock_78.png/600px-EtherRock_78.png',
        description: 'Просто картинка камня. Серьезно, это камень.'
    },

    // --- TITLES ---
    {
        id: 'title_beginner',
        name: 'Новичок',
        category: 'title',
        price: 1000,
        image: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png',
        description: 'Начало пути.',
        titleColor: '#94a3b8' // Slate 400
    },
    {
        id: 'title_hustler',
        name: 'Темщик',
        category: 'title',
        price: 25000,
        image: 'https://cdn-icons-png.flaticon.com/512/4140/4140048.png',
        description: 'Знает, где поднять бабла.',
        titleColor: '#10b981' // Emerald 500
    },
    {
        id: 'title_boss',
        name: 'Босс',
        category: 'title',
        price: 500000,
        image: 'https://cdn-icons-png.flaticon.com/512/1754/1754205.png',
        description: 'Люди работают на вас.',
        titleColor: '#3b82f6', // Blue 500
        effectType: 'shine'
    },
    {
        id: 'title_magnate',
        name: 'Магнат',
        category: 'title',
        price: 10000000,
        image: 'https://cdn-icons-png.flaticon.com/512/3135/3135768.png',
        description: 'Владелец заводов, газет, пароходов.',
        titleColor: '#8b5cf6', // Violet 500
        effectType: 'pulse'
    },
    {
        id: 'title_king',
        name: 'КОРОЛЬ МИРА',
        category: 'title',
        price: 1000000000,
        image: 'https://cdn-icons-png.flaticon.com/512/2583/2583344.png',
        description: 'Абсолютная власть и богатство.',
        titleColor: '#ef4444', // Red 500 (Самый крутой)
        effectType: 'orbit'
    }
];

// --- Utilities ---

// Strips EVERYTHING that is not A-Z or 0-9
export const sanitizeInput = (str: string): string => {
    return str.replace(/[^a-zA-Z0-9]/g, '');
};

export const isValidInput = (str: string): boolean => {
    return /^[a-zA-Z0-9]+$/.test(str) && str.length > 0;
};

export const hashString = (str: string): string => {
  let hash = 0;
  if (str.length === 0) return hash.toString();
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; 
  }
  return hash.toString();
};

const utf8_to_b64 = (str: string): string => {
  try {
      const bytes = new TextEncoder().encode(str);
      const binString = Array.from(bytes, (byte) => String.fromCharCode(byte)).join("");
      return btoa(binString);
  } catch (e) {
      console.error("Encoding error", e);
      return "";
  }
};

const b64_to_utf8 = (str: string): string => {
  try {
      const binString = atob(str);
      const bytes = Uint8Array.from(binString, (m) => m.codePointAt(0)!);
      return new TextDecoder().decode(bytes);
  } catch (e) {
      console.error("Decoding error", e);
      return "";
  }
};

const encryptData = (data: GameDatabase): string => {
  try {
    return utf8_to_b64(JSON.stringify(data));
  } catch (e) {
    console.error("Encryption failed", e);
    return "";
  }
};

const decryptData = (str: string): GameDatabase | null => {
  try {
    const json = b64_to_utf8(str);
    if (!json) return null;
    return JSON.parse(json);
  } catch (e) {
    console.error("Decryption failed", e);
    return null;
  }
};

// --- IP Management ---

const generateRandomIp = (): string => {
    return Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.');
};

// Gets the persistent IP for this specific browser/device
const getClientIp = (): string => {
    let ip = localStorage.getItem(DEVICE_IP_KEY);
    if (!ip) {
        ip = generateRandomIp();
        localStorage.setItem(DEVICE_IP_KEY, ip);
    }
    return ip;
};

// --- Generators ---

const generateInitialBusinesses = (): Business[] => [
  { id: 'b1', name: 'Киоск', type: 'retail', baseCost: 1000, baseIncome: 2, level: 0, owned: false, icon: 'Store' },
  { id: 'b2', name: 'Такси', type: 'transport', baseCost: 15000, baseIncome: 25, level: 0, owned: false, icon: 'Car' },
  { id: 'b3', name: 'Завод', type: 'industry', baseCost: 150000, baseIncome: 200, level: 0, owned: false, icon: 'Factory' },
  { id: 'b4', name: 'Стройка', type: 'industry', baseCost: 1000000, baseIncome: 1200, level: 0, owned: false, icon: 'Hammer' },
  { id: 'b5', name: 'Космодром', type: 'service', baseCost: 50000000, baseIncome: 45000, level: 0, owned: false, icon: 'Rocket' },
];

const generateInitialCandle = (price: number): Candle => ({
    time: Date.now(),
    open: price,
    high: price,
    low: price,
    close: price
});

const generateInitialInvestments = (): Investment[] => [
  // Crypto
  { id: 'c1', symbol: 'BTC', name: 'Bitcoin', currentPrice: 42000, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(42000)] },
  { id: 'c2', symbol: 'ETH', name: 'Ethereum', currentPrice: 2800, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(2800)] },
  { id: 'c3', symbol: 'SOL', name: 'Solana', currentPrice: 110, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(110)] },
  
  // Stocks
  { id: 's1', symbol: 'AAPL', name: 'Apple Inc.', currentPrice: 185, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(185)] },
  { id: 's2', symbol: 'GOOGL', name: 'Alphabet', currentPrice: 140, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(140)] },
  { id: 's3', symbol: 'AMZN', name: 'Amazon', currentPrice: 155, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(155)] },
  { id: 's4', symbol: 'TSLA', name: 'Tesla', currentPrice: 240, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(240)] },
  { id: 's5', symbol: 'NVDA', name: 'Nvidia', currentPrice: 600, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(600)] },
  { id: 's6', symbol: 'MSFT', name: 'Microsoft', currentPrice: 400, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(400)] },
  { id: 's7', symbol: 'META', name: 'Meta', currentPrice: 380, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(380)] },
  { id: 's8', symbol: 'NFLX', name: 'Netflix', currentPrice: 560, changePercent: 0, ownedAmount: 0, history: [generateInitialCandle(560)] },
];

const initialMiningFarm: MiningFarm = {
  gpuLevel: 1,
  gpuCount: 0,
  maxSlots: 2, 
  btcBalance: 0,
  energyDebt: 0
};

const initialPlayer: Player = {
  id: 'player_100', // Start from 100
  username: 'Player1',
  passwordHash: hashString('123456'), 
  registrationIp: '192.168.0.1',
  lastLoginIp: '192.168.0.1',
  registrationDate: Date.now(),
  avatarId: 'temshik', // Default
  playtime: 0,
  logs: ['Аккаунт создан'],
  isAdmin: false,
  balance: 100, 
  maxMoney: 100,
  clickLevel: 1,
  clickExp: 0,
  clickExpMax: 500,
  bannedUntil: null,
  businesses: generateInitialBusinesses(),
  investments: generateInitialInvestments(),
  miningFarm: initialMiningFarm,
  ownedAssetIds: [],
  lastLogin: Date.now(),
  lastMarketUpdate: Date.now()
};

const adminPlayer: Player = {
  ...initialPlayer,
  id: 'player_99', // ADMIN IS 99
  username: 'admin',
  passwordHash: hashString('admin991'),
  registrationIp: '127.0.0.1',
  lastLoginIp: '127.0.0.1',
  registrationDate: Date.now(),
  avatarId: 'vdv_cat',
  playtime: 0,
  logs: ['Аккаунт Администратора инициализирован'],
  isAdmin: true,
  balance: 999999999,
  maxMoney: 999999999,
  investments: generateInitialInvestments(),
  businesses: generateInitialBusinesses(),
  ownedAssetIds: GAME_ASSETS.map(a => a.id), // Admin owns everything
  activeTitleId: 'title_king'
};

const defaultConfig = { 
  version: '3.0', 
  globalMultiplier: 1, 
  taxRate: 0.13, 
  energyCostPerGpu: 0.5,
  activeTrack: 'christmas', // Default track
  isMusicEnabled: true, // Default enabled
  customTracks: [] // Admin tracks
};

const DEFAULT_ROLES: ClanRole[] = [
    { id: 'leader', name: 'Leader', color: '#fbbf24', priority: 100, permissions: { canKick: true, canMute: true, canInvite: true, canManageRoles: true } },
    { id: 'co-leader', name: 'Co-Leader', color: '#f87171', priority: 90, permissions: { canKick: true, canMute: true, canInvite: true, canManageRoles: false } },
    { id: 'veteran', name: 'Veteran', color: '#60a5fa', priority: 50, permissions: { canKick: false, canMute: false, canInvite: true, canManageRoles: false } },
    { id: 'member', name: 'Member', color: '#94a3b8', priority: 0, permissions: { canKick: false, canMute: false, canInvite: false, canManageRoles: false } }
];

export const GameService = {
  // --- Database Operations ---

  loadDatabase(): GameDatabase {
    const stored = localStorage.getItem(DB_KEY);
    let db: GameDatabase;

    if (stored) {
      const decrypted = decryptData(stored);
      db = decrypted || {
        players: [adminPlayer, initialPlayer],
        promoCodes: [],
        bannedIps: [],
        tickets: [],
        tradeRequests: [],
        activeTrades: [],
        clans: [],
        clanInvites: [],
        config: defaultConfig,
      };
    } else {
      db = {
        players: [adminPlayer, initialPlayer],
        promoCodes: [],
        bannedIps: [],
        tickets: [],
        tradeRequests: [],
        activeTrades: [],
        clans: [],
        clanInvites: [],
        config: defaultConfig,
      };
    }

    // Migration logic
    const clientIp = getClientIp();

    if (db.tickets === undefined) db.tickets = [];
    if (db.tradeRequests === undefined) db.tradeRequests = [];
    if (db.activeTrades === undefined) db.activeTrades = [];
    if (db.clans === undefined) db.clans = [];
    if (db.clanInvites === undefined) db.clanInvites = [];
    if (db.config.customTracks === undefined) db.config.customTracks = [];

    // Clan Migration (v2 to v3 roles)
    db.clans.forEach(clan => {
        if (!clan.members) {
            clan.members = {};
            clan.memberIds.forEach(mid => {
                clan.members[mid] = {
                    id: mid,
                    roleId: mid === clan.leaderId ? 'leader' : 'member',
                    joinedAt: Date.now(),
                    mutedUntil: null
                };
            });
        }
        if (!clan.roles || clan.roles.length === 0) {
            clan.roles = [...DEFAULT_ROLES];
        }
    });

    db.players.forEach(p => {
        if (!p.miningFarm) p.miningFarm = { ...initialMiningFarm };
        if (p.miningFarm.energyDebt === undefined) p.miningFarm.energyDebt = 0;
        if (p.maxMoney === undefined) p.maxMoney = p.balance;
        if (p.banReason === undefined) p.banReason = '';
        if (p.playtime === undefined) p.playtime = 0;
        if (p.ownedAssetIds === undefined) p.ownedAssetIds = [];
        
        if ((p as any).ip) {
            if (!p.registrationIp) p.registrationIp = (p as any).ip;
            if (!p.lastLoginIp) p.lastLoginIp = (p as any).ip;
            delete (p as any).ip;
        }
        
        if (!p.registrationDate) {
            const parts = p.id.split('_');
            const idNum = Number(parts[1]);
            if (parts.length > 1 && !isNaN(idNum) && idNum > 1000000000) {
                p.registrationDate = idNum;
            } else {
                p.registrationDate = Date.now();
            }
        }

        if (!p.avatarId) {
            p.avatarId = p.isAdmin ? 'vdv_cat' : 'temshik';
        }

        if (!p.registrationIp) p.registrationIp = p.isAdmin ? '127.0.0.1' : clientIp;
        if (!p.lastLoginIp) p.lastLoginIp = p.isAdmin ? '127.0.0.1' : clientIp;

        if (p.logs === undefined) p.logs = [];
        
        const defaultInv = generateInitialInvestments();
        defaultInv.forEach(def => {
            if (!p.investments.find(existing => existing.symbol === def.symbol)) {
                p.investments.push(def);
            }
        });

        if (p.miningFarm.maxSlots === undefined) p.miningFarm.maxSlots = 2;
        
        if (p.isAdmin && p.id === 'admin_0') {
            p.id = 'player_99';
        }
    });
    
    if (db.bannedIps === undefined) db.bannedIps = [];

    if (db.config.activeTrack === undefined) db.config.activeTrack = 'christmas';
    if (db.config.isMusicEnabled === undefined) db.config.isMusicEnabled = true;

    this.saveDatabase(db);
    return db;
  },

  saveDatabase(db: GameDatabase) {
    const encrypted = encryptData(db);
    if (encrypted) {
        localStorage.setItem(DB_KEY, encrypted);
    }
  },

  // ... (existing helper methods remain the same) ...
  updateSystemConfig(updates: Partial<GameDatabase['config']>) {
      const db = this.loadDatabase();
      db.config = { ...db.config, ...updates };
      this.saveDatabase(db);
  },

  // Completely reworked to be robust
  addCustomTrack(name: string, url: string) {
      const db = this.loadDatabase();
      if (!db.config.customTracks) db.config.customTracks = [];
      
      const newTrack = {
          id: `track_${Date.now()}_${Math.floor(Math.random() * 1000)}`, // Unique ID
          name,
          url,
          isHidden: false
      };
      
      db.config.customTracks.push(newTrack);
      this.saveDatabase(db);
      return db.config; // Return updated config
  },

  deleteCustomTrack(trackId: string) {
      const db = this.loadDatabase();
      
      // Ensure the array exists
      if (!db.config.customTracks) {
          db.config.customTracks = [];
          this.saveDatabase(db);
          return db.config;
      }

      // Filter out the track
      const originalLen = db.config.customTracks.length;
      db.config.customTracks = db.config.customTracks.filter(t => t.id !== trackId);
      
      // If active track was the one deleted, reset to default
      if (db.config.activeTrack === trackId) {
          db.config.activeTrack = 'christmas';
      }

      this.saveDatabase(db);
      return db.config;
  },

  toggleTrackVisibility(trackId: string) {
      const db = this.loadDatabase();
      if (!db.config.customTracks) return db.config;
      
      const track = db.config.customTracks.find(t => t.id === trackId);
      if (track) {
          track.isHidden = !track.isHidden;
          this.saveDatabase(db);
      }
      return db.config;
  },

  logAction(playerId: string, message: string) {
      const db = this.loadDatabase();
      const p = db.players.find(pl => pl.id === playerId);
      if (p) {
          const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
          p.logs.push(`[${timestamp}] ${message}`);
          if (p.logs.length > 500) p.logs = p.logs.slice(-500); // Limit logs
          this.saveDatabase(db);
      }
  },

  // --- Session ---
  saveSession(playerId: string) { localStorage.setItem(SESSION_KEY, playerId); },
  clearSession() { localStorage.removeItem(SESSION_KEY); },
  restoreSession(): Player | null {
      const storedId = localStorage.getItem(SESSION_KEY);
      if (!storedId) return null;
      return this.getPlayer(storedId) || null;
  },

  // --- Auth ---

  registerUser(rawUsername: string, passwordHash: string): Player | null {
    const db = this.loadDatabase();
    const username = sanitizeInput(rawUsername);
    if (db.players.some(p => p.username.toLowerCase() === username.toLowerCase())) {
        return null;
    }
    const ip = getClientIp();
    const now = Date.now();
    const existingIds = db.players
        .filter(p => p.id.startsWith('player_'))
        .map(p => {
            const num = parseInt(p.id.split('_')[1]);
            return isNaN(num) ? 0 : num;
        });
    const sequentialIds = existingIds.filter(id => id < 1000000000); 
    const maxId = sequentialIds.length > 0 ? Math.max(...sequentialIds) : 99;
    const nextId = maxId < 99 ? 100 : maxId + 1;

    const newPlayer: Player = {
        id: `player_${nextId}`,
        username,
        passwordHash, 
        registrationIp: ip,
        lastLoginIp: ip,
        registrationDate: now,
        avatarId: 'temshik',
        playtime: 0,
        logs: [`Аккаунт зарегистрирован. Reg IP: ${ip}`],
        isAdmin: false,
        balance: 100,
        maxMoney: 100,
        clickLevel: 1,
        clickExp: 0,
        clickExpMax: 500,
        bannedUntil: null,
        businesses: generateInitialBusinesses(),
        investments: generateInitialInvestments(),
        miningFarm: { ...initialMiningFarm },
        ownedAssetIds: [],
        lastLogin: now,
        lastMarketUpdate: now
    };

    if (db.bannedIps.includes(ip)) {
        newPlayer.bannedUntil = -1;
        newPlayer.banReason = "Регистрация с забаненного IP";
    }

    db.players.push(newPlayer);
    this.saveDatabase(db);
    return newPlayer;
  },

  authenticate(rawUsername: string, passwordHash: string): Player | null {
    const db = this.loadDatabase();
    const username = sanitizeInput(rawUsername);
    const playerIndex = db.players.findIndex(p => 
        p.username.toLowerCase() === username.toLowerCase() && 
        p.passwordHash === passwordHash
    );
    if (playerIndex === -1) return null;
    const player = db.players[playerIndex];
    const currentIp = getClientIp();
    if (!player.isAdmin) {
        player.lastLoginIp = currentIp;
        player.lastLogin = Date.now();
        if (db.bannedIps.includes(currentIp) || db.bannedIps.includes(player.registrationIp)) {
             if (!player.bannedUntil) {
                 player.bannedUntil = -1;
                 player.banReason = "Один из ваших аккаунтов забанен";
             }
        }
    }
    this.logAction(player.id, `Вход выполнен. IP: ${currentIp}`);
    db.players[playerIndex] = player;
    this.saveDatabase(db);
    return player;
  },

  changePassword(playerId: string, newPasswordHash: string) {
    const db = this.loadDatabase();
    const idx = db.players.findIndex(p => p.id === playerId);
    if (idx !== -1) {
        db.players[idx].passwordHash = newPasswordHash;
        this.logAction(playerId, "Пароль изменен");
        this.saveDatabase(db);
    }
  },

  getPlayer(playerId: string): Player | undefined {
    const db = this.loadDatabase();
    return db.players.find((p) => p.id === playerId);
  },

  updatePlayer(player: Player) {
    const db = this.loadDatabase();
    const idx = db.players.findIndex((p) => p.id === player.id);
    if (idx !== -1) {
      db.players[idx] = player;
      this.saveDatabase(db);
    }
  },

  getLeaderboard(sortBy: 'balance' | 'assets' = 'balance'): { player: Player, netWorth: number }[] {
      const db = this.loadDatabase();
      const calculateNetWorth = (p: Player) => {
          let total = p.balance;
          // Investments
          total += p.investments.reduce((sum, inv) => sum + (inv.ownedAmount * inv.currentPrice), 0);
          // Business Value (Sunk Cost)
          total += p.businesses.reduce((sum, b) => {
              if(!b.owned) return sum;
              const r = 1.5;
              const n = b.level + 1;
              const sunk = b.baseCost * ( (Math.pow(r, n) - 1) / (r - 1) );
              return sum + sunk;
          }, 0);
          // Assets Value
          if (p.ownedAssetIds) {
              p.ownedAssetIds.forEach(id => {
                  const asset = GAME_ASSETS.find(a => a.id === id);
                  if (asset) {
                      total += asset.price; // Or netWorthBonus if defined
                  }
              });
          }
          return total;
      };
      const candidates = db.players
        .filter(p => !p.isAdmin && p.username !== 'Игрок' && p.username !== 'Player1')
        .map(p => ({
            player: p,
            netWorth: calculateNetWorth(p)
        }));
      if (sortBy === 'balance') {
          candidates.sort((a, b) => b.player.balance - a.player.balance);
      } else {
          candidates.sort((a, b) => b.netWorth - a.netWorth);
      }
      return candidates.slice(0, 50); // Increased to 50 for Forbes style list
  },

  // --- ASSET SYSTEM ---
  buyAsset(playerId: string, assetId: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const playerIndex = db.players.findIndex(p => p.id === playerId);
      if (playerIndex === -1) return { success: false, msg: 'Игрок не найден' };
      
      const player = db.players[playerIndex];
      const asset = GAME_ASSETS.find(a => a.id === assetId);
      
      if (!asset) return { success: false, msg: 'Товар не найден' };
      if (player.ownedAssetIds.includes(assetId)) return { success: false, msg: 'У вас уже есть этот предмет' };
      if (player.balance < asset.price) return { success: false, msg: 'Недостаточно денег' };
      
      player.balance -= asset.price;
      player.ownedAssetIds.push(assetId);
      
      // Auto-equip title if it's a title
      if (asset.category === 'title') {
          player.activeTitleId = asset.id;
      }
      
      this.logAction(playerId, `Купил актив: ${asset.name} за ${formatCurrency(asset.price)}`);
      this.saveDatabase(db);
      return { success: true, msg: `Вы купили: ${asset.name}!` };
  },

  setActiveTitle(playerId: string, titleId: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const player = db.players.find(p => p.id === playerId);
      if (!player) return { success: false, msg: 'Игрок не найден' };
      
      if (titleId && !player.ownedAssetIds.includes(titleId)) return { success: false, msg: 'Титул не куплен' };
      
      player.activeTitleId = titleId;
      this.saveDatabase(db);
      return { success: true, msg: 'Титул установлен' };
  },

  // ... (Keep existing Clan, Trade, Support, Promo, Logic, Admin functions same) ...
  createClan(playerId: string, clanName: string): { success: boolean, msg: string, clanId?: string } {
      const db = this.loadDatabase();
      const pIdx = db.players.findIndex(p => p.id === playerId);
      if (pIdx === -1) return { success: false, msg: 'Игрок не найден' };
      const player = db.players[pIdx];

      if (player.clanId) return { success: false, msg: 'Вы уже состоите в клане' };
      if (player.balance < 10000) return { success: false, msg: 'Недостаточно денег (нужно 10,000)' };
      if (!clanName.trim()) return { success: false, msg: 'Введите название клана' };
      
      const newClanId = `clan_${Date.now()}`;
      const newClan: Clan = {
          id: newClanId,
          name: clanName.trim(),
          description: 'Добро пожаловать в клан!',
          leaderId: playerId,
          memberIds: [playerId],
          members: {
              [playerId]: { id: playerId, roleId: 'leader', joinedAt: Date.now(), mutedUntil: null }
          },
          roles: JSON.parse(JSON.stringify(DEFAULT_ROLES)), // Deep copy defaults
          maxMembers: 10,
          chatHistory: [],
          createdAt: Date.now()
      };

      player.balance -= 10000;
      player.clanId = newClanId;
      db.clans.push(newClan);
      this.logAction(playerId, `Создал клан '${clanName}'`);
      this.saveDatabase(db);
      return { success: true, msg: 'Клан создан!', clanId: newClanId };
  },

  getClan(clanId: string): Clan | undefined {
      const db = this.loadDatabase();
      return db.clans.find(c => c.id === clanId);
  },

  updateClanDetails(playerId: string, clanId: string, newName: string, newDesc: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const clan = db.clans.find(c => c.id === clanId);
      const player = db.players.find(p => p.id === playerId);
      
      if (!clan || !player) return { success: false, msg: 'Ошибка' };
      if (clan.leaderId !== playerId) return { success: false, msg: 'Только лидер может менять настройки' };

      // Change Name Logic (Cost 1500)
      if (newName && newName !== clan.name) {
          if (player.balance < 1500) return { success: false, msg: 'Смена названия стоит 1500' };
          player.balance -= 1500;
          clan.name = newName;
      }

      // Change Description (Free)
      if (newDesc !== undefined) {
          clan.description = newDesc;
      }

      this.saveDatabase(db);
      return { success: true, msg: 'Настройки клана обновлены' };
  },

  inviteToClan(inviterId: string, targetUsername: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const inviter = db.players.find(p => p.id === inviterId);
      const target = db.players.find(p => p.username.toLowerCase() === targetUsername.toLowerCase());
      const clan = db.clans.find(c => c.id === inviter?.clanId);

      if (!inviter || !target || !clan) return { success: false, msg: 'Ошибка данных' };
      
      const inviterRole = clan.roles.find(r => r.id === clan.members[inviterId]?.roleId);
      if (!inviterRole?.permissions.canInvite && clan.leaderId !== inviterId) return { success: false, msg: 'У вас нет прав приглашать' };

      if (target.clanId) return { success: false, msg: 'Игрок уже в клане' };
      if (clan.memberIds.length >= clan.maxMembers) return { success: false, msg: 'Нет мест в клане' };
      
      // Check existing invite
      if (db.clanInvites.some(i => i.clanId === clan.id && i.toPlayerId === target.id)) {
          return { success: false, msg: 'Приглашение уже отправлено' };
      }

      const invite: ClanInvite = {
          id: `inv_${Date.now()}`,
          clanId: clan.id,
          clanName: clan.name,
          toPlayerId: target.id,
          timestamp: Date.now()
      };

      db.clanInvites.push(invite);
      this.saveDatabase(db);
      return { success: true, msg: `Приглашение отправлено игроку ${target.username}` };
  },

  getClanInvites(playerId: string): ClanInvite[] {
      const db = this.loadDatabase();
      return db.clanInvites.filter(i => i.toPlayerId === playerId);
  },

  acceptClanInvite(inviteId: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const inviteIdx = db.clanInvites.findIndex(i => i.id === inviteId);
      if (inviteIdx === -1) return { success: false, msg: 'Приглашение не найдено' };
      
      const invite = db.clanInvites[inviteIdx];
      const clan = db.clans.find(c => c.id === invite.clanId);
      const player = db.players.find(p => p.id === invite.toPlayerId);

      if (!clan || !player) {
          db.clanInvites.splice(inviteIdx, 1);
          this.saveDatabase(db);
          return { success: false, msg: 'Клан или игрок не существуют' };
      }

      if (clan.memberIds.length >= clan.maxMembers) return { success: false, msg: 'В клане нет мест' };
      if (player.clanId) return { success: false, msg: 'Вы уже в клане' };

      player.clanId = clan.id;
      clan.memberIds.push(player.id);
      clan.members[player.id] = {
          id: player.id,
          roleId: 'member',
          joinedAt: Date.now(),
          mutedUntil: null
      };

      db.clanInvites.splice(inviteIdx, 1); // Remove invite
      this.saveDatabase(db);
      return { success: true, msg: `Вы вступили в клан ${clan.name}` };
  },

  declineClanInvite(inviteId: string) {
      const db = this.loadDatabase();
      db.clanInvites = db.clanInvites.filter(i => i.id !== inviteId);
      this.saveDatabase(db);
  },

  buyClanSlots(playerId: string, amount: number): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const player = db.players.find(p => p.id === playerId);
      const clan = db.clans.find(c => c.id === player?.clanId);

      if (!player || !clan) return { success: false, msg: 'Ошибка' };
      if (clan.leaderId !== playerId) return { success: false, msg: 'Только лидер может покупать места' };
      
      if (clan.maxMembers + amount > 100) return { success: false, msg: 'Максимум 100 мест в клане' };
      
      const cost = amount * 1000;
      if (player.balance < cost) return { success: false, msg: `Нужно ${formatCurrency(cost)}` };

      player.balance -= cost;
      clan.maxMembers += amount;
      this.saveDatabase(db);
      return { success: true, msg: `Куплено ${amount} мест` };
  },

  sendClanMessage(playerId: string, text: string): { success: boolean, msg?: string } {
      const db = this.loadDatabase();
      const player = db.players.find(p => p.id === playerId);
      const clan = db.clans.find(c => c.id === player?.clanId);

      if (player && clan && text.trim()) {
          const memberData = clan.members[playerId];
          if (memberData?.mutedUntil && memberData.mutedUntil > Date.now()) {
              return { success: false, msg: `Вы в муте до ${new Date(memberData.mutedUntil).toLocaleTimeString()}` };
          }

          const role = clan.roles.find(r => r.id === memberData.roleId);

          const msg: ClanMessage = {
              id: `msg_${Date.now()}`,
              senderId: player.id,
              senderName: player.username,
              roleColor: role?.color,
              text: text.trim(),
              timestamp: Date.now()
          };
          clan.chatHistory.push(msg);
          if (clan.chatHistory.length > 50) clan.chatHistory.shift(); // Limit chat history
          this.saveDatabase(db);
          return { success: true };
      }
      return { success: false };
  },

  createClanRole(playerId: string, name: string, color: string, priority: number): {success: boolean, msg: string} {
      const db = this.loadDatabase();
      const clan = db.clans.find(c => c.id === db.players.find(p => p.id === playerId)?.clanId);
      
      if (!clan) return { success: false, msg: 'Клан не найден' };
      if (clan.leaderId !== playerId) return { success: false, msg: 'Только лидер может создавать роли' };
      
      const newRole: ClanRole = {
          id: `role_${Date.now()}`,
          name: name.substring(0, 15),
          color,
          priority: Math.min(99, Math.max(1, priority)),
          permissions: { canKick: false, canMute: false, canInvite: false, canManageRoles: false }
      };
      
      clan.roles.push(newRole);
      this.saveDatabase(db);
      return { success: true, msg: 'Роль создана' };
  },

  deleteClanRole(playerId: string, roleId: string): {success: boolean, msg: string} {
      const db = this.loadDatabase();
      const clan = db.clans.find(c => c.id === db.players.find(p => p.id === playerId)?.clanId);
      if (!clan || clan.leaderId !== playerId) return { success: false, msg: 'Ошибка прав' };
      
      if (roleId === 'leader' || roleId === 'member') return { success: false, msg: 'Нельзя удалить базовые роли' };
      
      clan.roles = clan.roles.filter(r => r.id !== roleId);
      Object.values(clan.members).forEach((m: ClanMemberData) => {
          if (m.roleId === roleId) m.roleId = 'member';
      });
      
      this.saveDatabase(db);
      return { success: true, msg: 'Роль удалена' };
  },

  assignClanRole(leaderId: string, targetId: string, roleId: string): {success: boolean, msg: string} {
      const db = this.loadDatabase();
      const clan = db.clans.find(c => c.id === db.players.find(p => p.id === leaderId)?.clanId);
      if (!clan || clan.leaderId !== leaderId) return { success: false, msg: 'Только лидер назначает роли' };
      
      if (targetId === leaderId) return { success: false, msg: 'Нельзя сменить роль лидера' };
      if (!clan.roles.find(r => r.id === roleId)) return { success: false, msg: 'Роль не найдена' };
      
      if (clan.members[targetId]) {
          clan.members[targetId].roleId = roleId;
          this.saveDatabase(db);
          return { success: true, msg: 'Роль назначена' };
      }
      return { success: false, msg: 'Игрок не в клане' };
  },

  kickClanMember(executorId: string, targetId: string): {success: boolean, msg: string} {
      const db = this.loadDatabase();
      const clan = db.clans.find(c => c.id === db.players.find(p => p.id === executorId)?.clanId);
      if (!clan) return { success: false, msg: 'Ошибка' };
      
      const executorRole = clan.roles.find(r => r.id === clan.members[executorId]?.roleId);
      const targetRole = clan.roles.find(r => r.id === clan.members[targetId]?.roleId);
      
      if (executorId !== clan.leaderId) {
          if (!executorRole?.permissions.canKick) return { success: false, msg: 'Нет прав кикать' };
          if ((targetRole?.priority || 0) >= (executorRole?.priority || 0)) return { success: false, msg: 'Нельзя кикнуть равного или выше по рангу' };
      }
      
      delete clan.members[targetId];
      clan.memberIds = clan.memberIds.filter(id => id !== targetId);
      
      const targetPlayer = db.players.find(p => p.id === targetId);
      if (targetPlayer) targetPlayer.clanId = undefined;
      
      this.saveDatabase(db);
      return { success: true, msg: 'Игрок исключен' };
  },

  muteClanMember(executorId: string, targetId: string, minutes: number): {success: boolean, msg: string} {
      const db = this.loadDatabase();
      const clan = db.clans.find(c => c.id === db.players.find(p => p.id === executorId)?.clanId);
      if (!clan) return { success: false, msg: 'Ошибка' };

      const executorRole = clan.roles.find(r => r.id === clan.members[executorId]?.roleId);
      const targetRole = clan.roles.find(r => r.id === clan.members[targetId]?.roleId);

      if (executorId !== clan.leaderId) {
          if (!executorRole?.permissions.canMute) return { success: false, msg: 'Нет прав мутить' };
          if ((targetRole?.priority || 0) >= (executorRole?.priority || 0)) return { success: false, msg: 'Нельзя замутить равного или выше по рангу' };
      }

      if (clan.members[targetId]) {
          clan.members[targetId].mutedUntil = Date.now() + (minutes * 60000);
          this.saveDatabase(db);
          return { success: true, msg: `Мут на ${minutes} мин.` };
      }
      return { success: false, msg: 'Игрок не найден' };
  },

  changePlayerId(currentId: string, newId: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      
      if (db.players.some(p => p.id === newId)) {
          return { success: false, msg: 'Этот ID уже занят' };
      }

      const pIdx = db.players.findIndex(p => p.id === currentId);
      if (pIdx === -1) return { success: false, msg: 'Игрок не найден' };

      const oldId = db.players[pIdx].id;
      
      db.players[pIdx].id = newId;

      db.tickets.forEach(t => {
          if (t.playerId === currentId) t.playerId = newId;
      });

      db.tradeRequests.forEach(r => {
          if (r.fromPlayerId === currentId) r.fromPlayerId = newId;
          if (r.toPlayerId === currentId) r.toPlayerId = newId;
      });

      db.activeTrades.forEach(t => {
          if (t.player1Id === currentId) t.player1Id = newId;
          if (t.player2Id === currentId) t.player2Id = newId;
      });

      db.clans.forEach(c => {
          if (c.leaderId === currentId) c.leaderId = newId;
          c.memberIds = c.memberIds.map(mid => mid === currentId ? newId : mid);
          if (c.members[currentId]) {
              c.members[newId] = { ...c.members[currentId], id: newId };
              delete c.members[currentId];
          }
          c.chatHistory.forEach(msg => {
              if (msg.senderId === currentId) msg.senderId = newId;
          });
      });

      db.clanInvites.forEach(inv => {
          if (inv.toPlayerId === currentId) inv.toPlayerId = newId;
      });

      db.promoCodes.forEach(pc => {
          pc.usedByPlayerIds = pc.usedByPlayerIds.map(uid => uid === currentId ? newId : uid);
      });

      this.logAction(newId, `ID изменен администратором: ${oldId} -> ${newId}`);
      this.saveDatabase(db);
      return { success: true, msg: 'ID успешно изменен везде' };
  },

  changePlayerAvatar(playerId: string, avatarUrl: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const pIdx = db.players.findIndex(p => p.id === playerId);
      if (pIdx === -1) return { success: false, msg: 'Игрок не найден' };

      db.players[pIdx].avatarId = avatarUrl;
      this.logAction(playerId, `Аватарка изменена администратором`);
      this.saveDatabase(db);
      return { success: true, msg: 'Аватарка изменена' };
  },

  sendTradeRequest(fromPlayerId: string, toUsername: string): { success: boolean, msg: string } {
      const db = this.loadDatabase();
      const sender = db.players.find(p => p.id === fromPlayerId);
      const receiver = db.players.find(p => p.username.toLowerCase() === toUsername.toLowerCase());

      if (!sender) return { success: false, msg: 'Ошибка отправителя' };
      if (!receiver) return { success: false, msg: 'Игрок не найден' };
      if (sender.id === receiver.id) return { success: false, msg: 'Нельзя торговать с собой' };

      const existing = db.tradeRequests.find(r => r.fromPlayerId === sender.id && r.toPlayerId === receiver.id && r.status === 'pending');
      if (existing) return { success: false, msg: 'Запрос уже отправлен' };

      const active = db.activeTrades.find(t => t.player1Id === sender.id || t.player2Id === sender.id || t.player1Id === receiver.id || t.player2Id === receiver.id);
      if (active) return { success: false, msg: 'Один из игроков уже в трейде' };

      const request: TradeRequest = {
          id: `req_${Date.now()}`,
          fromPlayerId: sender.id,
          fromPlayerName: sender.username,
          toPlayerId: receiver.id,
          status: 'pending',
          timestamp: Date.now()
      };
      
      db.tradeRequests.push(request);
      this.saveDatabase(db);
      return { success: true, msg: 'Запрос на обмен отправлен!' };
  },

  getIncomingRequests(playerId: string): TradeRequest[] {
      const db = this.loadDatabase();
      return db.tradeRequests.filter(r => r.toPlayerId === playerId && r.status === 'pending');
  },

  acceptTradeRequest(requestId: string): TradeSession | null {
      const db = this.loadDatabase();
      const reqIdx = db.tradeRequests.findIndex(r => r.id === requestId);
      if (reqIdx === -1) return null;

      const req = db.tradeRequests[reqIdx];
      db.tradeRequests.splice(reqIdx, 1);

      const session: TradeSession = {
          id: `trade_${Date.now()}`,
          player1Id: req.fromPlayerId,
          player2Id: req.toPlayerId,
          p1Offer: { money: 0, businessIds: [] },
          p2Offer: { money: 0, businessIds: [] },
          p1Ready: false,
          p2Ready: false,
          status: 'active',
          createdAt: Date.now()
      };
      
      db.activeTrades.push(session);
      this.saveDatabase(db);
      return session;
  },

  declineTradeRequest(requestId: string) {
      const db = this.loadDatabase();
      db.tradeRequests = db.tradeRequests.filter(r => r.id !== requestId);
      this.saveDatabase(db);
  },

  getActiveTrade(playerId: string): TradeSession | undefined {
      const db = this.loadDatabase();
      return db.activeTrades.find(t => t.status === 'active' && (t.player1Id === playerId || t.player2Id === playerId));
  },

  updateTradeOffer(tradeId: string, playerId: string, offer: Partial<TradeOffer>) {
      const db = this.loadDatabase();
      const trade = db.activeTrades.find(t => t.id === tradeId);
      if (!trade) return;

      if (trade.player1Id === playerId) {
          trade.p1Offer = { ...trade.p1Offer, ...offer };
          trade.p1Ready = false; 
          trade.p2Ready = false;
      } else if (trade.player2Id === playerId) {
          trade.p2Offer = { ...trade.p2Offer, ...offer };
          trade.p1Ready = false;
          trade.p2Ready = false;
      }
      this.saveDatabase(db);
  },

  toggleTradeReady(tradeId: string, playerId: string, isReady: boolean) {
      const db = this.loadDatabase();
      const tradeIndex = db.activeTrades.findIndex(t => t.id === tradeId);
      if (tradeIndex === -1) return;

      const trade = db.activeTrades[tradeIndex];

      if (trade.player1Id === playerId) trade.p1Ready = isReady;
      else if (trade.player2Id === playerId) trade.p2Ready = isReady;

      this.saveDatabase(db);
      
      if (trade.p1Ready && trade.p2Ready) {
          this.executeTrade(trade.id);
      }
  },

  cancelTrade(tradeId: string) {
      const db = this.loadDatabase();
      db.activeTrades = db.activeTrades.filter(t => t.id !== tradeId);
      this.saveDatabase(db);
  },

  getPartnerDetailsForTrade(trade: TradeSession, myPlayerId: string): { username: string, businesses: Business[] } | null {
      const db = this.loadDatabase();
      const partnerId = trade.player1Id === myPlayerId ? trade.player2Id : trade.player1Id;
      const partner = db.players.find(p => p.id === partnerId);
      if (!partner) return null;
      return {
          username: partner.username,
          businesses: partner.businesses
      };
  },

  executeTrade(tradeId: string) {
      const db = this.loadDatabase();
      const tradeIdx = db.activeTrades.findIndex(t => t.id === tradeId);
      if (tradeIdx === -1) return;
      
      const trade = db.activeTrades[tradeIdx];
      const p1Idx = db.players.findIndex(p => p.id === trade.player1Id);
      const p2Idx = db.players.findIndex(p => p.id === trade.player2Id);

      if (p1Idx === -1 || p2Idx === -1) {
          db.activeTrades.splice(tradeIdx, 1);
          this.saveDatabase(db);
          return;
      }

      const p1 = db.players[p1Idx];
      const p2 = db.players[p2Idx];

      const getOfferStr = (offer: TradeOffer, player: Player) => {
          const parts = [];
          if (offer.money > 0) parts.push(formatCurrency(offer.money));
          
          offer.businessIds.forEach(bid => {
              const b = player.businesses.find(x => x.id === bid);
              if(b && b.owned) {
                  const busName = b.customName || b.name;
                  parts.push(`${busName} (Lvl ${b.level})`);
              }
          });
          return parts.length > 0 ? parts.join(', ') : 'Ничего';
      };

      const p1GivesLog = getOfferStr(trade.p1Offer, p1);
      const p2GivesLog = getOfferStr(trade.p2Offer, p2);

      if (p1.balance >= trade.p1Offer.money) {
          p1.balance -= trade.p1Offer.money;
          p2.balance += trade.p1Offer.money;
      }
      if (p2.balance >= trade.p2Offer.money) {
          p2.balance -= trade.p2Offer.money;
          p1.balance += trade.p2Offer.money;
      }

      const p1GivenBusinesses = trade.p1Offer.businessIds.map(bid => {
          const bus = p1.businesses.find(b => b.id === bid);
          return bus && bus.owned ? { id: bid, level: bus.level, customName: bus.customName } : null;
      }).filter(b => b !== null) as {id: string, level: number, customName?: string}[];

      const p2GivenBusinesses = trade.p2Offer.businessIds.map(bid => {
          const bus = p2.businesses.find(b => b.id === bid);
          return bus && bus.owned ? { id: bid, level: bus.level, customName: bus.customName } : null;
      }).filter(b => b !== null) as {id: string, level: number, customName?: string}[];

      p1GivenBusinesses.forEach(item => {
          const b = p1.businesses.find(x => x.id === item.id);
          if (b) { b.owned = false; b.level = 0; b.customName = undefined; }
      });

      p2GivenBusinesses.forEach(item => {
          const b = p2.businesses.find(x => x.id === item.id);
          if (b) { b.owned = false; b.level = 0; b.customName = undefined; }
      });

      p1GivenBusinesses.forEach(item => {
          const b = p2.businesses.find(x => x.id === item.id);
          if (b) { b.owned = true; b.level = item.level; b.customName = item.customName; }
      });

      p2GivenBusinesses.forEach(item => {
          const b = p1.businesses.find(x => x.id === item.id);
          if (b) { b.owned = true; b.level = item.level; b.customName = item.customName; }
      });

      const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
      p1.logs.push(`[${timestamp}] Трейд с ${p2.username}. Вы отдали: [${p1GivesLog}]. Вы получили: [${p2GivesLog}]`);
      p2.logs.push(`[${timestamp}] Трейд с ${p1.username}. Вы отдали: [${p2GivesLog}]. Вы получили: [${p1GivesLog}]`);

      db.activeTrades.splice(tradeIdx, 1);
      
      db.players[p1Idx] = p1;
      db.players[p2Idx] = p2;
      this.saveDatabase(db);
  },

  calculateTotalBusinessCost(b: Business): number {
      if (!b.owned) return 0;
      const r = 1.5;
      const n = b.level + 1;
      const total = b.baseCost * ( (Math.pow(r, n) - 1) / (r - 1) );
      return Math.floor(total);
  },

  createTicket(playerId: string, title: string, description: string) {
      const db = this.loadDatabase();
      const player = db.players.find(p => p.id === playerId);
      if (!player) return;

      const ticket: SupportTicket = {
          id: `ticket_${Date.now()}`,
          playerId,
          playerUsername: player.username,
          title,
          description,
          status: 'pending',
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now()
      };
      db.tickets.push(ticket);
      this.saveDatabase(db);
  },

  getTickets(playerId?: string): SupportTicket[] {
      const db = this.loadDatabase();
      if (playerId) {
          return db.tickets.filter(t => t.playerId === playerId).sort((a,b) => b.updatedAt - a.updatedAt);
      }
      return db.tickets.sort((a,b) => b.updatedAt - a.updatedAt);
  },

  addMessageToTicket(ticketId: string, sender: 'user' | 'admin', text: string) {
      const db = this.loadDatabase();
      const ticket = db.tickets.find(t => t.id === ticketId);
      if (ticket) {
          ticket.messages.push({
              id: `msg_${Date.now()}_${Math.random()}`,
              sender,
              text,
              timestamp: Date.now()
          });
          ticket.updatedAt = Date.now();
          this.saveDatabase(db);
      }
  },

  updateTicketStatus(ticketId: string, status: TicketStatus) {
      const db = this.loadDatabase();
      const ticket = db.tickets.find(t => t.id === ticketId);
      if (ticket) {
          ticket.status = status;
          ticket.updatedAt = Date.now();
          this.saveDatabase(db);
      }
  },

  deleteTicket(ticketId: string) {
      const db = this.loadDatabase();
      db.tickets = db.tickets.filter(t => t.id !== ticketId);
      this.saveDatabase(db);
  },

  createPromoCode(code: string, reward: number, maxActivations: number, expiresAt: number | null) {
      const db = this.loadDatabase();
      const newPromo: PromoCode = {
          id: `promo_${Date.now()}`,
          code,
          reward,
          maxActivations,
          usedByPlayerIds: [],
          expiresAt: expiresAt
      };
      db.promoCodes.push(newPromo);
      this.saveDatabase(db);
  },

  redeemPromoCode(playerId: string, code: string): { success: boolean, message: string, reward?: number } {
      const db = this.loadDatabase();
      const promoIndex = db.promoCodes.findIndex(p => p.code === code);
      
      if (promoIndex === -1) return { success: false, message: 'Промокод не найден' };
      
      const promo = db.promoCodes[promoIndex];
      
      if (promo.expiresAt && Date.now() > promo.expiresAt) return { success: false, message: 'Срок действия истек' };
      if (promo.usedByPlayerIds.length >= promo.maxActivations) return { success: false, message: 'Лимит активаций исчерпан' };
      if (promo.usedByPlayerIds.includes(playerId)) return { success: false, message: 'Вы уже активировали этот код' };

      promo.usedByPlayerIds.push(playerId);
      
      const playerIndex = db.players.findIndex(p => p.id === playerId);
      let reward = 0;
      if (playerIndex !== -1) {
          reward = promo.reward;
          db.players[playerIndex].balance += reward;
          this.logAction(playerId, `Активирован промокод ${code} (Награда: $${reward})`);
      }

      this.saveDatabase(db);
      return { success: true, message: 'Промокод активирован!', reward };
  },

  deletePromoCode(id: string) {
      const db = this.loadDatabase();
      db.promoCodes = db.promoCodes.filter(p => p.id !== id);
      this.saveDatabase(db);
  },

  getAllPromoCodes(): PromoCode[] {
      const db = this.loadDatabase();
      return db.promoCodes;
  },

  calculateClickValue(player: Player): number {
    return 1 * Math.pow(1.15, player.clickLevel - 1); 
  },

  calculatePassiveIncome(player: Player): number {
    const { net } = this.calculateBusinessIncome(player);
    return net;
  },

  calculateBusinessIncome(player: Player): { gross: number, tax: number, net: number } {
    const db = this.loadDatabase();
    const taxRate = db.config.taxRate || 0.13;
    
    const gross = player.businesses.reduce((acc, bus) => {
      if (!bus.owned) return acc;
      return acc + (bus.baseIncome * Math.pow(1.04, bus.level));
    }, 0);

    const tax = gross * taxRate;
    return { gross, tax, net: gross - tax };
  },

  calculateMiningPerformance(player: Player): { btcIncome: number, energyCost: number } {
    const db = this.loadDatabase();
    const energyRate = db.config.energyCostPerGpu || 0.5;
    const baseBtcRate = 0.00005; 
    
    const btcIncome = (player.miningFarm.gpuCount * Math.pow(1.15, player.miningFarm.gpuLevel) * baseBtcRate); 
    const energyCost = (player.miningFarm.gpuCount * energyRate);

    return { btcIncome, energyCost };
  },

  updateMarketPrices(player: Player): Player {
    const updatedInvestments = player.investments.map(inv => {
        const volatility = 4;
        const changePercent = (Math.random() - 0.5) * volatility;
        
        const prevClose = inv.currentPrice;
        const newClose = Math.max(0.1, prevClose * (1 + changePercent / 100));
        const open = prevClose;
        const maxVal = Math.max(open, newClose);
        const minVal = Math.min(open, newClose);
        const high = maxVal * (1 + Math.random() * 0.02);
        const low = minVal * (1 - Math.random() * 0.02); 

        const newCandle: Candle = {
            time: Date.now(),
            open,
            high,
            low,
            close: newClose
        };

        const newHistory = [...inv.history, newCandle].slice(-30);

        return {
            ...inv,
            currentPrice: newClose,
            changePercent: changePercent,
            history: newHistory
        };
    });

    return {
        ...player,
        investments: updatedInvestments,
        lastMarketUpdate: Date.now()
    };
  },

  banUser(targetId: string, durationMinutes: number | null, reason: string) {
    const db = this.loadDatabase();
    const player = db.players.find(p => p.id === targetId);
    if (player) {
        if (player.isAdmin) return;
        if (durationMinutes === null) {
            player.bannedUntil = -1;
        } else {
            player.bannedUntil = Date.now() + (durationMinutes * 60 * 1000);
        }
        player.banReason = reason;
        this.logAction(targetId, `ЗАБАНЕН АДМИНОМ. Причина: ${reason}`);
        this.saveDatabase(db);
    }
  },

  unbanUser(targetId: string) {
    const db = this.loadDatabase();
    const player = db.players.find(p => p.id === targetId);
    if (player) {
        player.bannedUntil = null;
        player.banReason = '';
        this.logAction(targetId, `РАЗБАНЕН АДМИНОМ`);
        this.saveDatabase(db);
    }
  },
  
  updatePlayerBalance(targetId: string, amount: number) {
    const db = this.loadDatabase();
    const player = db.players.find(p => p.id === targetId);
    if (player) {
        const oldVal = player.balance;
        player.balance = amount;
        this.logAction(targetId, `Баланс изменен админом: ${oldVal} -> ${amount}`);
        this.saveDatabase(db);
    }
  },

  findPlayerByUsername(username: string): Player | undefined {
      const db = this.loadDatabase();
      return db.players.find(p => p.username.toLowerCase() === username.toLowerCase());
  },

  banIp(ip: string) {
      const db = this.loadDatabase();
      if (!db.bannedIps.includes(ip)) {
          db.bannedIps.push(ip);
          db.players.forEach(p => {
              if ((p.lastLoginIp === ip || p.registrationIp === ip) && !p.isAdmin) {
                  p.bannedUntil = -1;
                  p.banReason = "IP Забанен";
                  p.logs.push(`[${new Date().toISOString()}] Система: Аккаунт заблокирован (Ban IP)`);
              }
          });
          this.saveDatabase(db);
      }
  },

  unbanIp(ip: string) {
      const db = this.loadDatabase();
      db.bannedIps = db.bannedIps.filter(b => b !== ip);
      this.saveDatabase(db);
  },

  isIpBanned(ip: string): boolean {
      const db = this.loadDatabase();
      return db.bannedIps.includes(ip);
  },
  
  getPlayersByIp(ip: string): Player[] {
      const db = this.loadDatabase();
      return db.players.filter(p => p.registrationIp === ip || p.lastLoginIp === ip);
  },

  findRelatedPlayers(targetPlayerId: string): Player[] {
      const db = this.loadDatabase();
      const target = db.players.find(p => p.id === targetPlayerId);
      if (!target) return [];

      const ipsToCheck = [target.registrationIp, target.lastLoginIp];
      const uniqueIps = [...new Set(ipsToCheck.filter(ip => ip))];

      return db.players.filter(p => {
          return uniqueIps.includes(p.registrationIp) || uniqueIps.includes(p.lastLoginIp);
      });
  }
};